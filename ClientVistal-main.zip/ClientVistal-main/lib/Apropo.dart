import 'package:flutter/material.dart';
import 'package:package_info/package_info.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';

class Apropo extends StatefulWidget {
  // const Apropo({ Key? key }) : super(key: key);

  @override
  _ApropoState createState() => _ApropoState();
}

class _ApropoState extends State<Apropo> {
  String version = '';
  init() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    setState(() {
      version = packageInfo.version;
      // appname = packageInfo.appName;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    init();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        centerTitle: true,
        backgroundColor: Colors.red,
        elevation: 0,
        title: Text(
          'Apropo de Vistal',
          style: TextStyle(
              // fontSize: 11,
              ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                  height: 200,
                  width: getwidth(context),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      image: DecorationImage(
                        image: AssetImage('assets/logos/pesa.png'),
                        fit: BoxFit.fill,
                      ))),
            ),
            SizedBox(
              height: 50,
            ),
            Card(
              child: ListTile(
                title: Text(APPNAME + ' version $version'),
                subtitle:
                    Text('Nous livrons avec rapidité et profetionnalisme.'),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Card(
              child: ListTile(
                title: Text('Avec plusieurs partenaires'),
                subtitle: Text('Notre service est réputé top level'),
              ),
            ),
            SizedBox(
              height: 100,
            ),
            Text(
              'Copyright Vistal',
              style: TextStyle(color: Colors.blueGrey),
            ),
          ],
        ),
      ),
    );
  }
}
