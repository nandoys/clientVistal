import 'package:flutter/cupertino.dart';

import 'package:vistalapp/Facture_pdf/model/customer.dart';
import 'package:vistalapp/Facture_pdf/model/supplier.dart';

class Invoice {
  final InvoiceInfo? info;
  final Supplier? supplier;
  final Customer? customer;
  final livraison;

  final List<InvoiceItem>? items;

  const Invoice(
      {@required this.info,
      @required this.supplier,
      @required this.customer,
      @required this.items,
      @required this.livraison});
}

class InvoiceInfo {
  final String? description;
  final String? number;
  final DateTime? date;
  // final String dueDate;
  final String? moyenpaye;

  const InvoiceInfo({
    @required this.description,
    @required this.number,
    @required this.date,
    @required this.moyenpaye,
  });
}

class InvoiceItem {
  final String? description;
  final int? quantity;
  final double? unitPrice;

  const InvoiceItem({
    @required this.description,
    @required this.quantity,
    @required this.unitPrice,
  });
}
