import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/two_separete.dart';
import 'package:vistalapp/Dashboard/articles/upstate.dart';
import 'package:vistalapp/Dashboard/articles/style.dart';
import 'package:vistalapp/Dashboard/articles/categories_button.dart';
import 'package:vistalapp/Dashboard/articles/list_buttons_categories.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/ui_list_prod.dart';

class PromotionandPortefeuille extends StatefulWidget {
  // const PromotionandPortefeuille({ Key? key }) : super(key: key);

  @override
  _PromotionandPortefeuilleState createState() =>
      _PromotionandPortefeuilleState();
}

class _PromotionandPortefeuilleState extends State<PromotionandPortefeuille> {
  List<Map> promotionels = [];
  Map urlpro = {};
  Map points = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    ///////////////////////////////////////:: url prodd
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      print('url vuuuuu');
      setState(() {
        if (!urlpro.containsKey(event.snapshot.value['idprod'].toString())) {
          setState(() {
            urlpro[event.snapshot.value['idprod'].toString()] =
                event.snapshot.value['url'].toString();
          });
        }
      });
    });
    ////////////////////////////////////////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      setState(() {
        if (event.snapshot.value['promotion'] == 'true') {
          promotionels.add({
            'nom': event.snapshot.value['nom'],
            'idcat': event.snapshot.value['idcat'],
            'idetab': event.snapshot.value['idetab'],
            'prixpromotion': event.snapshot.value['prixpromotion'],
            'url': urlpro[event.snapshot.value['nom']]
          });
        }
      });
    });
    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      if (shareget('phone') == event.snapshot.key) {
        setState(() {
          points['pointgagne'] = event.snapshot.value['pointgagne'];
          points['pointutilise'] = event.snapshot.value['pointutilise'];
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: points.isNotEmpty
            ? Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  SizedBox(
                    height: 20,
                  ),
                  option(
                    'Mon portefeuille',
                    points,
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Card(
                    child: ListTile(
                      title: Text('Avec votre portefeuille'),
                      subtitle: Text(
                          'Vous disposez d\'un moyen de vous faire livrer gratuitement si vous atteignez au moins 10 points. Les points sont gagnés par commande.Vistal crédite votre votre portefeuille d\'un point dès que votre commande est livrée.'),
                    ),
                  )
                ],
              )
            : Padding(
                padding: const EdgeInsets.only(top: 300),
                child: Center(
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
                  ),
                ),
              ),
      ),
    );
  }

  //////////////////////////////////////////////////////////////////////////////////////////////////
  option(titre, map) {
    return Column(
      children: [
        Text(
          titre.toString().toUpperCase(),
          style: TextStyle(fontSize: 15, color: Colors.blueGrey),
        ),
        Card(
          color: Colors.white,
          elevation: 4.0,
          child: Column(
            children: [
              ListTile(
                title: Text(
                  'Points gagnés',
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${map['pointgagne'].toString()}',
                      style: TextStyle(
                        color: Colors.blue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              ListTile(
                title: Text(
                  'points utilisés',
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${map['pointutilise'].toString()}',
                      style: TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              ListTile(
                title: Text(
                  'Points restants',
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${map['pointgagne'] - map['pointutilise']}',
                      style: TextStyle(
                        color: Colors.blue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              ListTile(
                title: Text(
                  'Equivalent à:',
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      map['pointgagne'] != null || map['pointutilise'] != null
                          ? '${((map['pointgagne'] - map['pointutilise']) / 10).toString().substring(0, 1)} livraison(s) gratuite(s)'
                          : '0',
                      style: TextStyle(color: Colors.blue),
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
      ],
    );
  }
}
