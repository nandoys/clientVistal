import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vistalapp/Auth_splash/Beforelog/Splash.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:vistalapp/UserProfil/UserProfil.dart';
import 'package:vistalapp/upload_image/firebase_storage_services.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import '../Apropo.dart';
import 'CallerDash.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:vistalapp/Dashboard/Circular_Menu.dart';
import 'package:flutter_restart/flutter_restart.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:simple_fontellico_progress_dialog/simple_fontico_loading.dart';
import 'package:share/share.dart';

class Mydrawer extends StatefulWidget {
  // final idpv;
  // Mydrawer({@required this.idpv});
  @override
  _MydrawerState createState() => _MydrawerState();
}

class _MydrawerState extends State<Mydrawer> {
  bool? isdarkmode;
  var getstate = GetStorage();
  Map userinfo = {'nom': '', 'prenom': ''};
  var user_url;
  bool _saving = false;
  GlobalKey _bottomNavigationKey = GlobalKey();
  // Uint8List uint8list;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // getstate.writeIfNull('dark', false);
    // setState(() {
    //   isdarkmode = getstate.read('dark');
    // });
    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      if (shareget('phone').toString() == event.snapshot.key) {
        setState(() {
          userinfo['prenom'] = event.snapshot.value['prenom'];
          userinfo['nom'] = event.snapshot.value['nom'];
        });
      }
    });
    //////////////////////////////////////////////////////////////////////////////////////////////
    // setState(() {
    //   user_phone = shareget('phone');
    // });
    Image_profil_vistal.onChildAdded.listen((event) {
      print(shareget('phone'));
      print(event.snapshot.key.toString());
      if (shareget('phone') == event.snapshot.key.toString()) {
        setState(() {
          user_url = event.snapshot.value['url'];
          shareset('urlphoto', event.snapshot.value['url']);
        });
      }
    });
    ///////////////////////////////////////////////////////////////////////////
    Image_profil_vistal.onChildChanged.listen((event) {
      if (shareget('phone') == event.snapshot.key.toString()) {
        setState(() {
          user_url = event.snapshot.value['url'];
          shareset('urlphoto', event.snapshot.value['url']);
        });
      }
    });
    // print(shareget('phone'));
  }

///////////////////////////////////////////////////////////////////////////////////////

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ModalProgressHUD(
        inAsyncCall: _saving,
        progressIndicator: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
        ),
        child: SingleChildScrollView(
          child: Container(
            color:
                dark == false || dark == null ? Colors.transparent : Darkcolor,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 35.0),
                  child: Container(
                    child: Stack(
                      children: [
                        Positioned(
                          top: 10,
                          left: 20,
                          child: Stack(
                            overflow: Overflow.visible,
                            children: [
                              sharedPreferences
                                          .getKeys()
                                          .contains('urlphoto') ||
                                      user_url != null
                                  ? Container(
                                      height: 100,
                                      width: 100,
                                      child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(100),
                                        child: CachedNetworkImage(
                                          filterQuality: FilterQuality.medium,
                                          fit: BoxFit.fill,
                                          imageUrl: sharedPreferences
                                                  .getKeys()
                                                  .contains('urlphoto')
                                              ? shareget('urlphoto')
                                              : user_url,
                                          placeholder: (BuildContext context,
                                              String url) {
                                            return Center(
                                              child: SkeletonContainer.rounded(
                                                height: 100,
                                                width: 100,
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.white, width: 1),
                                        borderRadius: BorderRadius.circular(60),
                                      ),
                                    )
                                  : Container(
                                      height: 100,
                                      width: 100,
                                      child: Icon(
                                        Icons.person,
                                        color: Colors.white,
                                        size: 100,
                                      ),
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.white, width: 1),
                                        borderRadius: BorderRadius.circular(60),
                                      ),
                                    ),
                              Positioned(
                                  top: 70,
                                  left: 60,
                                  child: Container(
                                    alignment: Alignment.center,
                                    height: 39,
                                    width: 39,
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(
                                            color: Colors.red.shade300,
                                            width: 1)),
                                    child: IconButton(
                                        icon: Icon(
                                          Icons.photo_camera,
                                          color: Colors.red,
                                        ),
                                        onPressed: () async {
                                          var image;
                                          var url;
                                          image = await pickImageandcompress(
                                              1, context);
                                          if (image != null) {
                                            var load = Showhide(
                                                context,
                                                'Changement de profil',
                                                SimpleFontelicoProgressDialog(
                                                    context: context,
                                                    barrierDimisable: false));
                                            load.show();
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                            url = await sendimage(
                                                image, 'user_profile_vistal');
                                            Image_profil_vistal.child(
                                                    shareget('phone'))
                                                .update({
                                              'url': url,
                                              'filename': image.toString()
                                            }).then((value) {
                                              load.hide();
                                            });
                                          }
                                        }),
                                  ))
                            ],
                          ),
                        ),
                        Positioned(
                          top: 120,
                          left: 20,
                          child: Column(
                            children: [
                              Text(
                                userinfo['prenom'],
                                style: TextStyle(
                                    color: Colors.white, fontSize: 19),
                              ),
                              Text(shareget('phone'),
                                  style: GoogleFonts.abel(
                                      color: Colors.white,
                                      fontSize: 15,
                                      //letterSpacing: 2,
                                      fontWeight: FontWeight.bold))
                            ],
                          ),
                        ),
                      ],
                    ),
                    height: 170,
                    width: getwidth(context),
                    decoration: BoxDecoration(color: Colors.red),
                  ),
                ),

///////////////////////////////////////////////////////////////////////////////////////////////////////////
                options('Mon profil', () {
                  push(context, UserProfil());
                }, Icons.person, Colors.red),
                options('Se Déconnecter', () async {
                  showAlertDialogOnOkCallback(
                      'Déconnexion',
                      'Vous allez vous deconnecter de $APPNAME',
                      DialogType.INFO_REVERSED,
                      context,
                      () => {
                            FirebaseAuth.instance.signOut().then((value) {
                              sharedPreferences.remove('phone');
                              sharedPreferences.remove('urlphoto');

                              getstate.write('dark', false);
                              print(getstate.read('dark'));
                              // FlutterRestart.restartApp();
                              Navigator.pushAndRemoveUntil(context,
                                  MaterialPageRoute(builder: (context) {
                                return Splash();
                              }), (route) => false);
                            })
                          });
                }, Icons.logout, Colors.red),

                Center(
                  child: Text(
                    'Votre Menu',
                    style: TextStyle(color: Colors.grey, letterSpacing: 4),
                  ),
                ),
                options('Stat', () {
                  // setState(() {
                  //   final CurvedNavigationBarState navBarState =
                  //       _bottomNavigationKey.currentState;
                  //   navBarState.setPage(0);
                  //   // _selectedIndex = 4;
                  //   Navigator.of(context).pop();
                  // });
                  pop(context);
                  pop(context);
                  push(
                      context,
                      Homepage(
                        index: 0,
                        page: null,
                        toseecat: '',
                      ));
                }, Icons.bar_chart_sharp, Colors.pinkAccent),
                options('Près de vous', () {
                  pop(context);
                  pop(context);
                  push(
                      context,
                      Homepage(
                        index: 1,
                        page: null,
                        toseecat: '',
                      ));
                }, Icons.location_on_sharp, Colors.pink),
                options('Accueil', () {
                  pop(context);
                  pop(context);
                  push(
                      context,
                      Homepage(
                        index: 2,
                        page: null,
                        toseecat: '',
                      ));
                }, Icons.home, Colors.redAccent),
                options('Mon panier', () {
                  pop(context);
                  pop(context);
                  push(
                      context,
                      Homepage(
                        index: 3,
                        page: null,
                        toseecat: '',
                      ));
                }, Icons.local_grocery_store, Colors.green),
                options(
                  'Favoris',
                  () {
                    pop(context);
                    pop(context);
                    push(
                        context,
                        Homepage(
                          index: 4,
                          page: null,
                          toseecat: '',
                        ));
                  },
                  Icons.favorite_outline,
                  Colors.red,
                ),
                options('Promotion et portefeuille', () {
                  Get.to(Homepage(
                    index: 2,
                    page: 'Not null',
                    toseecat: 'oui',
                  ));
                }, Icons.attach_money_rounded, Colors.red),
                Center(
                  child: Text(
                    'Supports',
                    style: TextStyle(color: Colors.grey, letterSpacing: 4),
                  ),
                ),
                options('Apropos', () {
                  push(context, Apropo());
                }, Icons.help, Colors.red),
                options('Contactez-nous via mail', () {
                  launchURL(mailto);
                }, Icons.mail, Colors.red),
                options('Contactez-nous via whatsapp', () {
                  launchwhatsapp(phoneto);
                }, Icons.phone, Colors.green),
                options('Conditions d\'utilisation', () {
                  //////////
                }, Icons.note, Colors.red),
                options('Partager l\'application', () async {
                  Share.share(
                      'Bonjour, Je suis utilisateur de l\'application Vistal depuis un bon moment, une application qui ouvre des opportunités en matière d\'achat et vente en ligne, je pensais que ceci pourrait vous intéresser,\n Cliquez sur ce lien pour decouvrir Vistal:\n\n https://play.google.com/store/apps/details?id=vistal.com',
                      subject: 'Jette un Oeil');
                }, Icons.share, Colors.red),
                // options('A propos', () {}, Icons.info, Colors.red),
                SizedBox(
                  height: 10,
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Copyright $APPNAME',
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  options(title, function, IconData iconData, Color coloricon) {
    return ListTile(
      onTap: function,
      // leading: Icon(Icons.notes),
      title: Text(title,
          style: TextStyle(
            color: dark == false || dark == null ? null : litetextcolors,
            fontSize: 15,
          )),
      leading: Icon(
        iconData,
        color: dark == false || dark == null ? null : litetextcolors,
      ),
    );
  }
}
