import 'package:flutter/material.dart';
import 'package:circle_wheel_scroll/circle_wheel_scroll_view.dart';
import 'package:vistalapp/Dashboard/Circular_Menu.dart';
import 'package:vistalapp/Dashboard/play_update.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Searchsclasses/SearchAllProd.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/Dashboard/Mydrawer.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:animator/animator.dart';
import 'package:fab_circular_menu/fab_circular_menu.dart';
import 'package:package_info/package_info.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:vistalapp/Dashboard/Portefeuil_Promotion.dart';
import 'package:simple_fontellico_progress_dialog/simple_fontico_loading.dart';

class Home extends StatefulWidget {
  final page;
  Home({@required this.page});
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Map userinfo = {'nom': '', 'prenom': ''};
  String version = '';
  String playversion = '';
  var cat = null;
  List<Map> allpod = [];
  Map etabnme = {};
  Map urlpro = {};
  FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    init();

    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      if (shareget('phone').toString() == event.snapshot.key.toString()) {
        setState(() {
          userinfo['prenom'] = event.snapshot.value['prenom'];
          userinfo['nom'] = event.snapshot.value['nom'];
        });
        // if (event.snapshot.key == '+243811966923' ||
        //     event.snapshot.key == '+243971458185') {
        //   Version.child(shareget('phone'))
        //       .update({'verionacruel': version.toString()});
        // }
      }
    });
    //////////////////////////////////////////////////////////////////////////////////
    Version.onChildAdded.listen((event) {
      setState(() {
        playversion = event.snapshot.value['verionacruel'].toString();
      });
      if (playversion != version && vue_update == false) {
        showDialog(
          context: context,
          builder: (_) {
            return StatefulBuilder(
                builder: (BuildContext context, StateSetter mystate) {
              return SimpleDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(20.0))),
                // contentPadding: EdgeInsets.only(top: 10.0),
                title: Text(
                  'Mise à jour disponible',
                  style: TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold),
                ),
                children: [
                  Padding(
                      padding: const EdgeInsets.all(14),
                      child: Text(
                        'Veuillez mettre à jour Vistal pour béneficier de nouvelles fonctionnalités.',
                      )),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: InkWell(
                          onTap: () {
                            pop(context);
                          },
                          child: Text(
                            'Me rappeler plustard',
                            style: TextStyle(
                                color: Colors.red, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      Container(),
                      Container(),
                      Container(),
                      Container(),
                      Container(),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: InkWell(
                          onTap: () {
                            launchURL(
                                'https://play.google.com/store/apps/details?id=vistal.com');
                          },
                          child: Text(
                            'Mettre à jour',
                            style: TextStyle(
                                color: Colors.blue,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              );
            });
          },
          //////////////////////////////////////////////////////////////////////////////////:
        );
        vue_update = true;
      }
    });
  }

  init() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    setState(() {
      version = packageInfo.version;
      print(version);
      // appname = packageInfo.appName;
    });
    // initialisation du share préferences
    ////////////////////////////////searchallprod//////////////////////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      setState(() {
        allpod.add({
          'nom': event.snapshot.value['nom'],
          'idcat': event.snapshot.value['idcat'],
          'idetab': event.snapshot.value['idetab'],
          'desc': event.snapshot.value['desc'],
          'prix': event.snapshot.value['prix'],
          'visible': event.snapshot.value['visible'],
        });
      });
    });

    ///////////////////////////////////////////// Etab name ///////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        etabnme[event.snapshot.key] = event.snapshot.value['etabname'];
      });
    });
    ////////////////////////// prod url //////////////////////////////////////
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      setState(() {
        if (!urlpro.containsKey(event.snapshot.value['idprod'])) {
          urlpro[event.snapshot.value['idprod']] = event.snapshot.value['url'];
        }
      });
    });

/////////////////////////////////////////// cloud messaging //////////////////////////////////////////////
    FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
    firebaseMessaging.getToken().then((value) =>
        Vistal_SIMPLEUSER.child(shareget('phone')).update({'tocken': value}));
    // showDialogs(context, 2);
  }

  @override
  Widget build(BuildContext context) {
    cat = widget.page;
    return Scaffold(
      backgroundColor:
          dark == false || dark == null ? Colors.transparent : Darkcolor,
      drawer: Mydrawer(),
      body: widget.page == null
          ? SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    height: 20,
                  ),
                  ///////////////////////////////////////////////////////////////////////////////:
                  InkWell(
                    onTap: () {
                      showSearch(
                          context: context,
                          delegate: DataserachALLProd(
                              list: allpod,
                              etabname: etabnme,
                              urlprod: urlpro));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: Container(
                        padding: EdgeInsets.only(left: 8),
                        alignment: Alignment.center,
                        height: 40,
                        width: getwidth(context) / 1.06,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text(
                              'Rechercher un produit ',
                              style: TextStyle(
                                  // fontWeight: FontWeight.w600,
                                  letterSpacing: 3,
                                  fontSize: 15,
                                  color: dark == false || dark == null
                                      ? Darkcolor
                                      : Colors.grey.shade100
                                  // color: Colors.grey.shade600
                                  ),
                            ),
                            Container(),
                            Container(),
                            Icon(Icons.search, color: Colors.grey),
                          ],
                        ),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.grey, width: 1)),
                      ),
                    ),
                  ),

                  SizedBox(
                    height: 100,
                  ),
                  Container(
                    child: SizedBox(
                        height: getheight(context) / 2.5,
                        child: CategoryMenu()),
                  )
                ],
              ),
            )
          : PromotionandPortefeuille(),
    );
  }
}
