import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/Etab/EtabUI.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/detail_prod_ui.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';

class ProductsTwosepa extends StatefulWidget {
  final map; //Map
  final fromfav;
  ProductsTwosepa({@required this.map, @required this.fromfav});
  @override
  _ProductsTwosepaState createState() => _ProductsTwosepaState();
}

class _ProductsTwosepaState extends State<ProductsTwosepa> {
  Map<String, String> urlpro = {};
  String profiletab = eve;

  late String etabname;
  List<Map> favorits = [];
  List<Map> panier = [];
  Map infoprod = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      if (widget.map['idetab'] == event.snapshot.value['idetab'] &&
          widget.map['idprod'] == event.snapshot.value['idprod']) {
        setState(() {
          if (!urlpro.containsKey(event.snapshot.value['idprod'])) {
            urlpro[event.snapshot.value['idprod']] =
                event.snapshot.value['url'];
          }
        });
      }
    });
    //////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_vendeur_profil_photo.onChildAdded.listen((event) {
      if (widget.map['idetab'] == event.snapshot.key) {
        setState(() {
          profiletab = event.snapshot.value['url'];
        });
      }
    });
    Vistal_Vendeur.onChildAdded.listen((event) {
      if (widget.map['idetab'] == event.snapshot.key) {
        setState(() {
          etabname = event.snapshot.value['etabname'];
        });
      }
    });
    ///////////////////////////////// favorit ///////////////////////////////////////////////////////////
    Vistal_Favorits_produits.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          favorits.add({
            'key': event.snapshot.key,
            'idetab': event.snapshot.value['idetab'],
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
          });
        });
      }
    });
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_Favorits_produits.onChildRemoved.listen((event) {
      var old = favorits.firstWhere(
        (element) =>
            element['phone'] == event.snapshot.value['phone'] &&
            element['idprod'] == event.snapshot.value['idprod'] &&
            element['idetab'] == event.snapshot.value['idetab'],
        orElse: () {
          return eve;
        },
      );
      if (old != eve) {
        setState(() {
          favorits.remove(old);
        });
      }
    });
    ///////////////////////////////////////////// panier  //////////////////////////////////////////
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone') &&
          event.snapshot.value['idetab'] == widget.map['idetab']) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab'],
            'qt': event.snapshot.value['qt'],
            'key': event.snapshot.key
          });
        });
      }
    });
    Vistal_panier.onChildChanged.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone') &&
          event.snapshot.value['idprod'] == widget.map['idprod'] &&
          event.snapshot.value['idetab'] == widget.map['idetab']) {
        setState(() {
          var old = panier.firstWhere(
            (element) =>
                element['phone'] == shareget('phone') &&
                element['idprod'] == event.snapshot.value['idprod'] &&
                element['idetab'] == event.snapshot.value['idetab'],
            orElse: () {
              return eve;
            },
          );
          if (old != eve) {
            panier.remove(old);
            panier.add({
              'phone': event.snapshot.value['phone'],
              'idprod': event.snapshot.value['idprod'],
              'idetab': event.snapshot.value['idetab'],
              'qt': event.snapshot.value['qt'],
              'key': event.snapshot.key
            });
          }
        });
      }
    });
    ////////////////////////////////////////// all prod //////////////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      if (event.snapshot.value['nom'] == widget.map['idprod'] &&
          event.snapshot.value['idetab'] == widget.map['idetab']) {
        setState(() {
          infoprod['idprod'] = event.snapshot.value['nom'];
          infoprod['prix'] = event.snapshot.value['prix'];
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        push(
            context,
            DetaiUIProd(mapinfoprod: {
              'idprod': widget.map['idprod'],
              'idetab': widget.map['idetab']
            }));
      },
      child: Container(
        decoration: BoxDecoration(
            border: Border.all(color: Colors.white, width: 2),
            borderRadius: BorderRadius.circular(15)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Center(
                child: Stack(
                  children: [
                    Container(
                      height: 400,
                      width: 400,
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.white, width: 2),
                          borderRadius: BorderRadius.circular(10)),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: widget.map['url'] != null
                            ? Hero(
                                tag: widget.map['url'],
                                child: CachedNetworkImage(
                                  filterQuality: FilterQuality.medium,
                                  fit: BoxFit.fill,
                                  imageUrl: widget.map['url'],
                                  placeholder:
                                      (BuildContext context, String url) {
                                    return Center(
                                      child: SkeletonContainer.rounded(
                                        height: 400,
                                        width: 400,
                                      ),
                                    );
                                  },
                                ),
                              )
                            : Center(
                                child: SkeletonContainer.rounded(
                                  height: 400,
                                  width: 400,
                                ),
                              ),
                      ),
                    ),
                    /////////////////////////// etab image

                    InkWell(
                      onTap: () {
                        push(context, EtabUI(idetab: widget.map['idetab']));
                      },
                      child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Container(
                            height: 30,
                            width: 30,
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.white, width: 2),
                                borderRadius: BorderRadius.circular(20)),
                            child: profiletab != eve
                                ? ClipRRect(
                                    borderRadius: BorderRadius.circular(50),
                                    child: CachedNetworkImage(
                                      filterQuality: FilterQuality.medium,
                                      fit: BoxFit.fill,
                                      imageUrl: profiletab,
                                      placeholder:
                                          (BuildContext context, String url) {
                                        return Center(
                                          child: SkeletonContainer.rounded(
                                            height: 30,
                                            width: 30,
                                          ),
                                        );
                                      },
                                    ),
                                  )
                                : SkeletonContainer.rounded(
                                    height: 30,
                                    width: 30,
                                  ),
                          )),
                    ),
                  ],
                ),
              ),
            ),
            Text(
              infoprod['idprod'] != null
                  ? '${infoprod['idprod']}'
                  : '...', // nom prod
              style: TextStyle(fontWeight: FontWeight.normal, fontSize: 16),
            ),
            SizedBox(height: 5),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.all(3.0),
                  child: Container(
                    height: 40,
                    width: 40,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey),
                        color: Colors.white54),
                    child: IconButton(
                        icon: Icon(
                          favorits.firstWhere(
                                    (element) =>
                                        element['phone'] == shareget('phone') &&
                                        element['idprod'] ==
                                            widget.map['idprod'] &&
                                        element['idetab'] ==
                                            widget.map['idetab'],
                                    orElse: () {
                                      return eve;
                                    },
                                  ) ==
                                  eve
                              ? Icons.favorite_outline
                              : Icons.favorite,
                          color: Colors.red,
                        ),
                        onPressed: () async {
                          var old = favorits.firstWhere(
                            (element) =>
                                element['phone'] == shareget('phone') &&
                                element['idprod'] == widget.map['idprod'] &&
                                element['idetab'] == widget.map['idetab'],
                            orElse: () {
                              return eve;
                            },
                          );
                          if (old == eve) {
                            Vistal_Favorits_produits.push().set({
                              'idetab': widget.map['idetab'],
                              'phone': shareget('phone'),
                              'idprod': widget.map['idprod'],
                              'date': DateTime.now().toString()
                            });
                          } else {
                            Vistal_Favorits_produits.child(old['key']).remove();
                            setState(() {
                              favorits.remove(old);
                            });
                          }
                        }),
                  ),
                ),
                Container(),
                Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Container(
                    alignment: Alignment.center,
                    height: 40,
                    width: 40,
                    decoration: BoxDecoration(
                        color: Colors.orange,
                        borderRadius: BorderRadius.circular(20)),
                    child: Text(
                      '${infoprod['prix']}\$',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 10,
                          color: Colors.black),
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(3.0),
                  child: Stack(
                    children: [
                      Container(
                        alignment: Alignment.center,
                        height: 40,
                        width: 40,
                        child: IconButton(
                            icon: Icon(
                              Icons.shopping_cart_outlined,
                              color: Colors.white,
                            ),
                            onPressed: () {
                              var old = panier.firstWhere(
                                (element) =>
                                    element['phone'] == shareget('phone') &&
                                    element['idprod'] == widget.map['idprod'] &&
                                    element['idetab'] == widget.map['idetab'],
                                orElse: () {
                                  return eve;
                                },
                              );

                              if (old == eve) {
                                Vistal_panier.push().set({
                                  'phone': shareget('phone'),
                                  'idprod': widget.map['idprod'],
                                  'idetab': widget.map['idetab'],
                                  'date': DateTime.now().toString(),
                                  'qt': '1',
                                  'prix_total': infoprod['prix'],
                                  'prix': infoprod['prix'],
                                });
                              } else {
                                // Vistal_panier.child(old['key']).update({
                                //   'qt': (int.parse(old['qt']) + 1).toString()
                                // });
                                snackshow('Article déjà ajouté dans le panier',
                                    context);
                              }
                            }),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            color: Colors.pink),
                      ),
                      // Positioned(
                      //   left: 25,
                      //   child: Container(
                      //     alignment: Alignment.center,
                      //     child: Text(
                      //       '12',
                      //       style: TextStyle(fontSize: 8, color: Colors.white),
                      //     ),
                      //     height: 20,
                      //     width: 20,
                      //     decoration: BoxDecoration(
                      //       borderRadius: BorderRadius.circular(20),
                      //       color: Colors.black,
                      //     ),
                      //   ),
                      // )
                    ],
                    overflow: Overflow.visible,
                  ),
                )
                ///////////////////////////////////////////////////////////////////////////////////////////:::::
              ],
            )
          ],
        ),
      ),
    );
  }
}
