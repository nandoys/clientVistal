import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/Two_of_staggered.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/detail_prod_ui.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';

import '../../CallerDash.dart';

class Seemore extends StatefulWidget {
  final list;
  Seemore({@required this.list});
  @override
  _SeemoreState createState() => _SeemoreState();
}

class _SeemoreState extends State<Seemore> {
  List<Map> commandes = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          commandes.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_panier.onChildRemoved.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = commandes.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'],
          orElse: () {
            return eve;
          },
        );
        setState(() {
          if (old != eve) {}
          commandes.remove(old);
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        etabname[event.snapshot.key] = event.snapshot.value['etabname'];
      });
    });
  }

  Map etabname = {};
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Color(0xFFf6f5ee),
        appBar: AppBar(
          title: Text(
            'Plus de produits',
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: false,
          backgroundColor: Colors.red,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              pop(context);
            },
          ),
          actions: [
            IconButton(
                icon: Icon(Icons.inventory_outlined),
                onPressed: () {
                  push(context, CallerCouserEtCommande());
                }),
            Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 5.0, left: 2, right: 4),
                  child: IconButton(
                      icon: Icon(Icons.local_grocery_store),
                      onPressed: () {
                        push(context,
                            Homepage(index: 3, page: 3, toseecat: null));
                      }),
                ),
                commandes.length != 0
                    ? Positioned(
                        top: 5,
                        left: 30,
                        child: Container(
                          alignment: Alignment.center,
                          child: Text(
                            '${commandes.length}',
                            style: TextStyle(color: Colors.white),
                          ),
                          height: 20,
                          width: 20,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.black),
                        ),
                      )
                    : Container()
              ],
            ),
          ],
        ),
        body: Container(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: buildProducts(),
          ),
        ),
      );

  Widget buildProducts() {
    final double spacing = 12;

    return GridView(
        // padding: EdgeInsets.all(spacing),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: spacing,
          mainAxisSpacing: spacing,
          childAspectRatio: 3 / 4,
        ),
        children: [
          for (final prod in widget.list)
            ProductsTwosepa(map: {
              'idprod': prod['idprod'],
              'idetab': prod['idetab'],
              'url': prod['url'],
            }, fromfav: false),
        ]);
  }
}
