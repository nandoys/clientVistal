import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/Etab/EtabUI.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/detail_prod_ui.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';

class ProductList extends StatefulWidget {
  final Map? map;
  ProductList({@required this.map});
  @override
  _ProductListState createState() => _ProductListState();
}

class _ProductListState extends State<ProductList> {
  Map<String, String> urlpro = {};
  String profiletab = eve, etabname = eve;
  List<Map> favorits = [];
  List<Map> commandes = [];
  Map infoprod = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      if (widget.map!['idetab'] == event.snapshot.value['idetab']! &&
          widget.map!['idprod'] == event.snapshot.value['idprod']) {
        setState(() {
          if (!urlpro.containsKey(event.snapshot.value['idprod'])) {
            urlpro[event.snapshot.value['idprod']] =
                event.snapshot.value['url'];
          }
        });
      }
    });
    ////////////////////////////////////////////
    Vistal_vendeur_profil_photo.onChildAdded.listen((event) {
      if (widget.map!['idetab'] == event.snapshot.key) {
        setState(() {
          profiletab = event.snapshot.value['url'];
        });
      }
    });
    Vistal_Vendeur.onChildAdded.listen((event) {
      if (widget.map!['idetab'] == event.snapshot.key) {
        setState(() {
          etabname = event.snapshot.value['etabname'];
        });
      }
    });
    ///////////////////////////////// favorit /////////////////////////////////////////////
    Vistal_Favorits_produits.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          favorits.add({
            'key': event.snapshot.key,
            'idetab': event.snapshot.value['idetab'],
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
          });
        });
      }
    });
    ////////////////////////////////////////////////////////////////////////////////////
    Vistal_Favorits_produits.onChildRemoved.listen((event) {
      var old = favorits.firstWhere(
        (element) =>
            element['phone'] == event.snapshot.value['phone'] &&
            element['idprod'] == event.snapshot.value['idprod'] &&
            element['idetab'] == event.snapshot.value['idetab'],
        orElse: () {
          return eve;
        },
      );
      if (old != eve) {
        setState(() {
          favorits.remove(old);
        });
      }
    });
    ///////////////////////////////////////////// commandes
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone') &&
          event.snapshot.value['livre'] == 'false') {
        setState(() {
          commandes.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab'],
          });
        });
      }
    });

    ////////////////////////////////////////// all prod //////////////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      if (event.snapshot.value['nom'] == widget.map!['idprod'] &&
          event.snapshot.value['idetab'] == widget.map!['idetab']) {
        setState(() {
          infoprod['idprod'] = event.snapshot.value['nom'];
          infoprod['prix'] = event.snapshot.value['prix'];
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Card(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5),
                      topRight: Radius.circular(5)),
                ),
                child: Stack(
                  children: [
                    InkWell(
                      onTap: () {
                        push(
                            context,
                            DetaiUIProd(mapinfoprod: {
                              'idprod': widget.map!['idprod'],
                              'idetab': widget.map!['idetab']
                            }));
                      },
                      child: urlpro[widget.map!['idprod']] != null
                          ? Container(
                              height: 50,
                              width: 50,
                              decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey),
                                  borderRadius: BorderRadius.circular(5)),
                              child: ClipRRect(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5)),
                                child: Opacity(
                                  opacity: 0.85,
                                  child: CachedNetworkImage(
                                    filterQuality: FilterQuality.medium,
                                    fit: BoxFit.fill,
                                    imageUrl: urlpro[widget.map!['idprod']]!,
                                    placeholder:
                                        (BuildContext context, String url) {
                                      return Center(
                                        child: SkeletonContainer.square(
                                          height: 50,
                                          width: 50,
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            )
                          : SkeletonContainer.rounded(
                              height: 20,
                              width: 20,
                            ),
                    ),
                    InkWell(
                      onTap: () {
                        push(context, EtabUI(idetab: widget.map!['idetab']));
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(3.0),
                        child: profiletab != eve
                            ? Container(
                                height: 20,
                                width: 20,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.blueGrey, width: 2),
                                    borderRadius: BorderRadius.circular(20)),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(50),
                                  child: CachedNetworkImage(
                                    filterQuality: FilterQuality.medium,
                                    fit: BoxFit.fill,
                                    imageUrl: profiletab,
                                    placeholder:
                                        (BuildContext context, String url) {
                                      return Center(
                                        child: SkeletonContainer.rounded(
                                          height: 20,
                                          width: 20,
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              )
                            : SkeletonContainer.square(
                                height: 50,
                                width: 50,
                              ),
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                children: [
                  infoprod['idprod'] != null
                      ? Text('${infoprod['idprod']}',
                          style: TextStyle(color: Colors.black, fontSize: 12))
                      : SkeletonContainer.square(
                          width: 50,
                          height: 1,
                        ),
                  infoprod['prix'] != null
                      ? Text('${infoprod['prix']} \$',
                          style: TextStyle(color: Colors.red, fontSize: 11))
                      : SkeletonContainer.square(
                          width: 50,
                          height: 1,
                        ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  IconButton(
                      icon: Icon(
                        favorits.firstWhere(
                                  (element) =>
                                      element['phone'] == shareget('phone') &&
                                      element['idprod'] ==
                                          widget.map!['idprod'] &&
                                      element['idetab'] ==
                                          widget.map!['idetab'],
                                  orElse: () {
                                    return eve;
                                  },
                                ) ==
                                eve
                            ? Icons.favorite_outline
                            : Icons.favorite,
                        color: Colors.red,
                      ),
                      onPressed: () async {
                        var old = favorits.firstWhere(
                          (element) =>
                              element['phone'] == shareget('phone') &&
                              element['idprod'] == widget.map!['idprod'] &&
                              element['idetab'] == widget.map!['idetab'],
                          orElse: () {
                            return eve;
                          },
                        );
                        if (old == eve) {
                          Vistal_Favorits_produits.push().set({
                            'idetab': widget.map!['idetab'],
                            'phone': shareget('phone'),
                            'idprod': widget.map!['idprod'],
                            'date': DateTime.now().toString()
                          });
                        } else {
                          Vistal_Favorits_produits.child(old['key']).remove();
                          setState(() {
                            favorits.remove(old);
                          });
                        }
                      }),
                  Container(
                    alignment: Alignment.center,
                    height: 40,
                    width: 40,
                    child: IconButton(
                        icon: Icon(
                          Icons.shopping_cart_outlined,
                          color: Colors.white,
                        ),
                        onPressed: () {
                          if (commandes.firstWhere(
                                (element) =>
                                    element['phone'] == shareget('phone') &&
                                    element['idprod'] ==
                                        widget.map!['idprod'] &&
                                    element['idetab'] == widget.map!['idetab'],
                                orElse: () {
                                  return eve;
                                },
                              ) ==
                              eve) {
                            Vistal_panier.push().set({
                              'phone': shareget('phone'),
                              'idprod': widget.map!['idprod'],
                              'idetab': widget.map!['idetab'],
                              'date': DateTime.now().toString(),
                              'livre': 'false',
                              'qt': '1',
                              'prix': infoprod['prix'],
                              'prix_total': infoprod['prix'],
                              'vendeurconfirme': 'false',
                              'cilentconfirme': 'false',
                              'commandeconfirme': 'false',
                              'adresser': '',
                              'ref': '',
                              'code': '',
                              'cloudtoken': ''
                            });
                          } else {
                            toast('Produit déjà ajouté dans le panier',
                                Colors.grey, Colors.white);
                          }
                        }),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40),
                        color: Colors.grey),
                  )
                  ///////////////////////////////////////////////////////////////////////////////////////////:::::
                ],
              )
            ],
          ),
        ),
      ],
    );
  }
}
