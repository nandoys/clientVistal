import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Dashboard/Homes.dart';
import 'package:vistalapp/Dashboard/Etab/EtabUI.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/SeemoreProd.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Searchsclasses/searchProductInEtab.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';

class DetaiUIProd extends StatefulWidget {
  final mapinfoprod; //  Map
  DetaiUIProd({@required this.mapinfoprod});
  @override
  _DetaiUIProdState createState() => _DetaiUIProdState();
}

class _DetaiUIProdState extends State<DetaiUIProd> {
  List<String> listimages = [];

  Map<String, String> urlpro = {};
  String profiletab = '';
  String etabname = '';
  List<Map> favorits = [];
  List<Map> panier = [];
  Map detailProduit = {};
  List<Map> searchproinetab = [];
  Map<String, String> tockenvendeurs = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    /////////////////////////////////////////// // panier url prod
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      setState(() {
        if (widget.mapinfoprod['idetab'] == event.snapshot.value['idetab'] &&
            widget.mapinfoprod['idprod'] == event.snapshot.value['idprod']) {
          setState(() {
            listimages.add(event.snapshot.value['url']);
          });
        }
      });
      /////////////////////////////////////////// image of one prod ////////////
      setState(() {
        if (!urlpro.containsKey(event.snapshot.value['idprod'])) {
          urlpro[event.snapshot.value['idprod']] = event.snapshot.value['url'];
        }
      });
    });
    ////////////////////////////////////////////:panier::::///////////////////////////////////////////////////
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_panier.onChildRemoved.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = panier.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'],
          orElse: () {
            return eve;
          },
        );
        setState(() {
          if (old != eve) {}
          panier.remove(old);
        });
      }
    });
    //////////////////////////////////////////// end commande ///////////////////////////////////
    Vistal_vendeur_profil_photo.onChildAdded.listen((event) {
      if (widget.mapinfoprod['idetab'] == event.snapshot.key) {
        setState(() {
          profiletab = event.snapshot.value['url'];
        });
      }
    });
    Vistal_Vendeur.onChildAdded.listen((event) {
      if (widget.mapinfoprod['idetab'] == event.snapshot.key) {
        setState(() {
          etabname = event.snapshot.value['etabname'];
        });
      }
    });
    ///////////////////////////////// favorit /////////////////////////////////////////////
    Vistal_Favorits_produits.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          favorits.add({
            'key': event.snapshot.key,
            'idetab': event.snapshot.value['idetab'],
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
          });
        });
      }
    });
    ////////////////////////////////////////////////////////////////////////////////////
    Vistal_Favorits_produits.onChildRemoved.listen((event) {
      var old = favorits.firstWhere(
        (element) =>
            element['phone'] == event.snapshot.value['phone'] &&
            element['idprod'] == event.snapshot.value['idprod'] &&
            element['idetab'] == event.snapshot.value['idetab'],
        orElse: () {
          return eve;
        },
      );
      if (old != eve) {
        setState(() {
          favorits.remove(old);
        });
      }
    });

    //////////////////////////////////////////// detail produit //////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      if (widget.mapinfoprod['idetab'] == event.snapshot.value['idetab'] &&
          widget.mapinfoprod['idprod'] == event.snapshot.value['nom']) {
        print('info seen successfully');
        setState(() {
          detailProduit = {
            'nom': event.snapshot.value['nom'],
            'idcat': event.snapshot.value['idcat'],
            'idetab': event.snapshot.value['idetab'],
            'desc': event.snapshot.value['desc'],
            'prix': event.snapshot.value['prix'],
            'visible': event.snapshot.value['visible'],
            'prix_total': event.snapshot.value['prix_total'],
          };
        });
      }
    });

////////////////////////////////// all prod of etab ///////////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      if (widget.mapinfoprod['idetab'] == event.snapshot.value['idetab']) {
        print('info seen successfully');
        setState(() {
          searchproinetab.add({
            'nom': event.snapshot.value['nom'],
            'idcat': event.snapshot.value['idcat'],
            'idetab': event.snapshot.value['idetab'],
            'desc': event.snapshot.value['desc'],
            'prix': event.snapshot.value['prix'],
            'visible': event.snapshot.value['visible'],
          });
        });
      }
    });
    //////////////////////////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        tockenvendeurs[event.snapshot.key!] = event.snapshot.value['tocken'];
      });
    });
  }

/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        actions: [
          IconButton(
              icon: Icon(Icons.inventory_outlined),
              onPressed: () {
                push(context, CallerCouserEtCommande());
              }),
          Stack(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 5.0, left: 2, right: 4),
                child: IconButton(
                    icon: Icon(Icons.local_grocery_store),
                    onPressed: () {
                      push(
                          context, Homepage(index: 3, page: 3, toseecat: null));
                    }),
              ),
              panier.length != 0
                  ? Positioned(
                      top: 5,
                      left: 30,
                      child: Container(
                        alignment: Alignment.center,
                        child: Text(
                          '${panier.length}',
                          style: TextStyle(color: Colors.white),
                        ),
                        height: 20,
                        width: 20,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.black),
                      ),
                    )
                  : Container()
            ],
          ),
        ],
        backgroundColor: Colors.red,
        leading: Row(
          children: [
            IconButton(
                icon: Icon(Icons.arrow_back),
                color: Colors.white,
                onPressed: () {
                  pop(context);
                }),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10.0),
                  child: Container(
                    height: 20,
                    width: 20,
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(20)),
                    // radius: 20,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(150),
                      child: profiletab != ''
                          ? CachedNetworkImage(
                              filterQuality: FilterQuality.medium,
                              fit: BoxFit.fill,
                              imageUrl: profiletab,
                              placeholder: (BuildContext context, String url) {
                                return Center(
                                  child: SkeletonContainer.rounded(
                                    height: 20,
                                    width: 20,
                                  ),
                                );
                              },
                            )
                          : Container(
                              alignment: Alignment.center,
                              child: Icon(
                                Icons.storefront_rounded,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 2,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    etabname.toString().toUpperCase(),
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
                  ),
                ),
              ],
            )
          ],
        ),
        elevation: 0,
      ),
      /////////////////////////////////////////////////////////////////////////////////////////////////////
      ///////////////////////////////////////////////////////////////////////////////////////////////////
      body: SingleChildScrollView(
        child: Column(
          children: [
            InkWell(
              onTap: () {
                showSearch(
                    context: context,
                    delegate: DataSearchProdinEtab(
                        list: searchproinetab, urlprod: urlpro));
              },
              child: Container(
                alignment: Alignment.center,
                child: Container(
                  height: 29,
                  width: getwidth(context) * 0.96,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 10,
                      ),
                      Icon(
                        Icons.search,
                        color: Colors.red,
                      ),
                      Text(
                        'Rechercher un produit dans ${etabname.toString()} ',
                        style: TextStyle(color: Colors.grey),
                      )
                    ],
                  ),
                ),
                height: 50,
                width: getwidth(context),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        colors: [Colors.red, Colors.redAccent, Colors.red])),
              ),
            ),
            ////////////////////////////////////////////////////////////
            listimages.isNotEmpty
                ? Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: SizedBox(
                      height: getheight(context) * 0.45,
                      width: double.infinity,
                      child: Carousel(
                        autoplay: false,
                        dotIncreasedColor: Colors.pink,
                        autoplayDuration: Duration(seconds: 0),
                        dotSize: 7.0,
                        dotSpacing: 15.0,
                        indicatorBgPadding:
                            4.0, // la bar grise ou se placent les indicateurs
                        dotBgColor: Colors.transparent,
                        dotColor: Colors.black,
                        animationCurve: Curves.easeInQuad,
                        boxFit: BoxFit.fill,
                        dotVerticalPadding: 5.0,
                        dotPosition: DotPosition.bottomCenter,
                        images: [
                          for (final imge in listimages)
                            Padding(
                              padding: const EdgeInsets.all(2),
                              child: Stack(
                                children: [
                                  Container(
                                    height: getheight(context) * 0.5,
                                    width: getwidth(context) * 0.96,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(10),
                                      child: Hero(
                                        tag: imge,
                                        child: CachedNetworkImage(
                                          filterQuality: FilterQuality.medium,
                                          fit: BoxFit.fill,
                                          imageUrl: imge,
                                          placeholder: (BuildContext context,
                                              String url) {
                                            return Center(
                                              child: SkeletonContainer.rounded(
                                                height:
                                                    getheight(context) * 0.9,
                                                width: double.infinity,
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(2.0),
                                    child: InkWell(
                                      onTap: () {
                                        push(
                                            context,
                                            EtabUI(
                                                idetab: widget
                                                    .mapinfoprod['idetab']));
                                      },
                                      child: Container(
                                        height: 40,
                                        width: 40,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(20),
                                            border: Border.all(
                                                color: Colors.white, width: 2)),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(150),
                                          child: profiletab != ''
                                              ? CachedNetworkImage(
                                                  filterQuality:
                                                      FilterQuality.medium,
                                                  fit: BoxFit.fill,
                                                  imageUrl: profiletab,
                                                  placeholder:
                                                      (BuildContext context,
                                                          String url) {
                                                    return Center(
                                                      child: SkeletonContainer
                                                          .rounded(
                                                        height: 40,
                                                        width: 40,
                                                      ),
                                                    );
                                                  },
                                                )
                                              : Container(
                                                  alignment: Alignment.center,
                                                  child: Icon(
                                                    Icons.storefront_rounded,
                                                    color: Colors.white,
                                                    size: 20,
                                                  ),
                                                ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                        ],
                      ),
                    ),
                  )
                : Container(),
            ///////////////////////////////////////////////////////////////////////////////////////////
            Card(
              child: ListTile(
                title: Text(
                  detailProduit['nom'].toString(),
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
                subtitle: Text('prix: ${detailProduit['prix'].toString()}\$',
                    style: TextStyle(
                        fontWeight: FontWeight.w400, color: Colors.red)),
              ),
            ),
            Card(
              child: ListTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    IconButton(
                        icon: Icon(
                          favorits.firstWhere(
                                    (element) =>
                                        element['phone'] == shareget('phone') &&
                                        element['idprod'] ==
                                            widget.mapinfoprod['idprod'] &&
                                        element['idetab'] ==
                                            widget.mapinfoprod['idetab'],
                                    orElse: () {
                                      return eve;
                                    },
                                  ) ==
                                  eve
                              ? Icons.favorite_outline
                              : Icons.favorite,
                          color: Colors.red,
                        ),
                        onPressed: () async {
                          var old = favorits.firstWhere(
                            (element) =>
                                element['phone'] == shareget('phone') &&
                                element['idprod'] ==
                                    widget.mapinfoprod['idprod'] &&
                                element['idetab'] ==
                                    widget.mapinfoprod['idetab'],
                            orElse: () {
                              return eve;
                            },
                          );
                          if (old == eve) {
                            Vistal_Favorits_produits.push().set({
                              'idetab': widget.mapinfoprod['idetab'],
                              'phone': shareget('phone'),
                              'idprod': widget.mapinfoprod['idprod'],
                              'date': DateTime.now().toString()
                            });
                          } else {
                            await Vistal_Favorits_produits.child(old['key'])
                                .remove();
                            setState(() {
                              favorits.remove(old);
                            });
                          }
                        }),
                    Container(
                      alignment: Alignment.center,
                      height: 40,
                      width: 40,
                      child: IconButton(
                          icon: Icon(
                            Icons.shopping_cart_outlined,
                            color: Colors.white,
                          ),
                          onPressed: () {
                            if (panier.firstWhere(
                                  (element) =>
                                      element['phone'] == shareget('phone') &&
                                      element['idprod'] ==
                                          widget.mapinfoprod['idprod'] &&
                                      element['idetab'] ==
                                          widget.mapinfoprod['idetab'],
                                  orElse: () {
                                    return eve;
                                  },
                                ) ==
                                eve) {
                              Vistal_panier.push().set({
                                'phone': shareget('phone'),
                                'idprod': widget.mapinfoprod['idprod'],
                                'idetab': widget.mapinfoprod['idetab'],
                                'date': DateTime.now().toString(),
                                'livre': 'false',
                                'vendeurconfirmeReception': 'false',
                                'cilentconfirmeRception': 'false',
                                'commandeValider': 'false',
                                'adresser': '',
                                'ref': '',
                                'code': '',
                                'qt': '1',
                                'prix': detailProduit['prix'],
                                'prix_total': detailProduit['prix'],
                                'cloudtoken':
                                    tockenvendeurs[widget.mapinfoprod['idetab']]
                              });
                              toast(
                                  'Produit ajouté dans le panier avec succès ',
                                  Colors.black,
                                  Colors.white);
                            } else {
                              toast('Produit déjà ajouté dans le panier',
                                  Colors.red, Colors.white);
                            }
                          }),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(40),
                          color: Colors.red),
                    ),
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.grey.shade300),
                      child: IconButton(
                          icon: Icon(
                            Icons.more_horiz_outlined,
                            color: Colors.black,
                            // size: 10,
                          ),
                          onPressed: () {
                            modalbotosheetcontact(context);
                          }),
                    ),
                  ],
                ),
              ),
            )

            ////////////////////////////////////////////////
            ,
            SizedBox(
              height: 10,
            ),
            Card(
              child: ListTile(
                title: Text(
                  detailProduit['desc'].toString(),
                  style: TextStyle(fontWeight: FontWeight.w400, fontSize: 15),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
