import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/Etab/EtabUI.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/detail_prod_ui.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';

class TwoSeparatedUI extends StatefulWidget {
  final map; // Map

  TwoSeparatedUI({@required this.map});
  @override
  _TwoSeparatedUIState createState() => _TwoSeparatedUIState();
}

class _TwoSeparatedUIState extends State<TwoSeparatedUI> {
  Map<String, String> urlpro = {};
  String profiletab = '';
  String etabname = '';
  List<Map> favorits = [];
  List<Map> panier = [];
  Map infoprod = {};
  Map<String, String> tockenvendeurs = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      if (widget.map['idetab'] == event.snapshot.value['idetab'] &&
          widget.map['idprod'] == event.snapshot.value['idprod']) {
        print('url vuuuuu');
        setState(() {
          if (!urlpro.containsKey(event.snapshot.value['idprod'].toString())) {
            setState(() {
              urlpro[event.snapshot.value['idprod'].toString()] =
                  event.snapshot.value['url'].toString();
            });
          }
        });
      }
    });
    ////////////////////////////////////////////
    Vistal_vendeur_profil_photo.onChildAdded.listen((event) {
      if (widget.map['idetab'] == event.snapshot.key) {
        setState(() {
          profiletab = event.snapshot.value['url'];
        });
      }
    });
    Vistal_Vendeur.onChildAdded.listen((event) {
      if (widget.map['idetab'] == event.snapshot.key) {
        setState(() {
          etabname = event.snapshot.value['etabname'];
        });
      }
    });
    ///////////////////////////////// favorit /////////////////////////////////////////////
    Vistal_Favorits_produits.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          favorits.add({
            'key': event.snapshot.key,
            'idetab': event.snapshot.value['idetab'],
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
          });
        });
      }
    });
    ////////////////////////////////////////////////////////////////////////////////////
    Vistal_Favorits_produits.onChildRemoved.listen((event) {
      var old = favorits.firstWhere(
        (element) =>
            element['phone'] == event.snapshot.value['phone'] &&
            element['idprod'] == event.snapshot.value['idprod'] &&
            element['idetab'] == event.snapshot.value['idetab'],
        orElse: () {
          return eve;
        },
      );
      if (old != eve) {
        setState(() {
          favorits.remove(old);
        });
      }
    });
    /////////////////////////////////////////// panier //////////////////////////////////////////
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab'],
          });
        });
      }
    });
    Vistal_panier.onChildRemoved.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = panier.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'],
          orElse: () {
            return eve;
          },
        );
        setState(() {
          if (old != eve) {}
          panier.remove(old);
        });
      }
    });
    //////////////////////////////////////// all prod //////////////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      if (event.snapshot.value['nom'] == widget.map['idprod'] &&
          event.snapshot.value['idetab'] == widget.map['idetab']) {
        setState(() {
          infoprod = {
            'idprod': event.snapshot.value['nom'],
            'prix': event.snapshot.value['prix'],
            'prixpromotion': event.snapshot.value['prixpromotion'],
          };
        });
      }
    });
    ////////////////////////////////////////all take all vendors tockens ////////////////////////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        tockenvendeurs[event.snapshot.key!] = event.snapshot.value['tocken'];
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return urlpro != {} || etabname != null || profiletab.toString() != ''
        ? Column(
            children: [
              Container(
                height: 150,
                width: 150,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10)),
                  // boxShadow: [
                  //   BoxShadow(
                  //       color: Colors.grey, spreadRadius: 1, blurRadius: 1)
                  // ],
                ),
                child: Stack(
                  children: [
                    InkWell(
                      onTap: () {
                        push(
                            context,
                            DetaiUIProd(mapinfoprod: {
                              'idprod': widget.map['idprod'],
                              'idetab': widget.map['idetab']
                            }));
                      },
                      child: Center(
                        child: ClipRRect(
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10)),
                          child: Opacity(
                            opacity: 0.85,
                            child: widget.map['url'] != null
                                ? Hero(
                                    tag: widget.map['url'],
                                    child: CachedNetworkImage(
                                      height: 150,
                                      width: 150,
                                      filterQuality: FilterQuality.high,
                                      fit: BoxFit.fill,
                                      imageUrl: widget.map['url'],
                                      placeholder:
                                          (BuildContext context, String url) {
                                        return Center(
                                          child: SkeletonContainer.rounded(
                                            height: 150,
                                            width: 150,
                                          ),
                                        );
                                      },
                                    ),
                                  )
                                : SkeletonContainer.rounded(
                                    height: 150,
                                    width: 150,
                                  ),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        push(context, EtabUI(idetab: widget.map['idetab']));
                      },
                      child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Container(
                            height: 30,
                            width: 30,
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.white, width: 2),
                                borderRadius: BorderRadius.circular(20)),
                            child: profiletab.toString() != ''
                                ? ClipRRect(
                                    borderRadius: BorderRadius.circular(50),
                                    child: CachedNetworkImage(
                                      filterQuality: FilterQuality.medium,
                                      fit: BoxFit.fill,
                                      imageUrl: profiletab.toString(),
                                      placeholder:
                                          (BuildContext context, String url) {
                                        return Center(
                                          child: SkeletonContainer.rounded(
                                            height: 30,
                                            width: 30,
                                          ),
                                        );
                                      },
                                    ),
                                  )
                                : SkeletonContainer.rounded(
                                    height: 30,
                                    width: 30,
                                  ),
                          )),
                    ),
                  ],
                ),
              ),
              ///////////////////////////////////////////////////////////////////////////////////////////////:
              Column(
                mainAxisSize: MainAxisSize.min,
                // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  widget.map['idprod'] != null
                      ? Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            widget.map['idprod'],
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        )
                      : SkeletonContainer.square(
                          height: 1,
                          width: 10,
                        ),

                  //////////////////////////////////////////////////////////////////////////////////////////
                  Row(
                    // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 0.0),
                        child: infoprod['prixpromotion'].toString().isNotEmpty
                            ? Container(
                                height: 40,
                                width: 40,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                    color: Colors.red,
                                    borderRadius: BorderRadius.circular(20)),
                                child: Text(
                                    infoprod['prix'] != null
                                        ? infoprod['prix'] + '\$'
                                        : '....',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 18,
                                        decorationColor: Colors.black,
                                        decorationStyle:
                                            TextDecorationStyle.solid,
                                        decoration:
                                            TextDecoration.lineThrough)),
                              )
                            : Padding(
                                padding: const EdgeInsets.all(3.0),
                                child: Container(
                                  height: 40,
                                  width: 40,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: Colors.white54,
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(color: Colors.grey)),
                                  child: IconButton(
                                      icon: Icon(
                                        favorits.firstWhere(
                                                  (element) =>
                                                      element['phone'] ==
                                                          shareget('phone') &&
                                                      element['idprod'] ==
                                                          widget
                                                              .map['idprod'] &&
                                                      element['idetab'] ==
                                                          widget.map['idetab'],
                                                  orElse: () {
                                                    return eve;
                                                  },
                                                ) ==
                                                eve
                                            ? Icons.favorite_outline
                                            : Icons.favorite,
                                        color: Colors.red,
                                      ),
                                      onPressed: () async {
                                        var old = favorits.firstWhere(
                                          (element) =>
                                              element['phone'] ==
                                                  shareget('phone') &&
                                              element['idprod'] ==
                                                  widget.map['idprod'] &&
                                              element['idetab'] ==
                                                  widget.map['idetab'],
                                          orElse: () {
                                            return eve;
                                          },
                                        );
                                        if (old == eve) {
                                          Vistal_Favorits_produits.push().set({
                                            'idetab':
                                                widget.map['idetab'].toString(),
                                            'phone':
                                                shareget('phone').toString(),
                                            'idprod':
                                                widget.map['idprod'].toString(),
                                            'date': DateTime.now().toString(),
                                            'qt': '1',
                                            'prix_total': infoprod['prix'],
                                            'prix': infoprod['prix'],
                                          });
                                        } else {
                                          await Vistal_Favorits_produits.child(
                                                  old['key'])
                                              .remove();
                                          setState(() {
                                            favorits.remove(old);
                                          });
                                        }
                                      }),
                                ),
                              ),
                      ),

                      Container(
                        width: 2,
                      ),
                      ///////////////////////// fin fav
                      infoprod['prix'] != null
                          ? Container(
                              height: 40,
                              width: 40,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                  color: Colors.orange,
                                  borderRadius: BorderRadius.circular(20)),
                              child: Text(
                                  infoprod['prixpromotion'].toString().isEmpty
                                      ? infoprod['prix'] != null
                                          ? infoprod['prix']
                                          : '' + '\$'
                                      : '${infoprod['prixpromotion']}' + '\$',
                                  style: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      color: infoprod['prixpromotion'] != ''
                                          ? Colors.black
                                          : Colors.black,
                                      decoration: infoprod['prixpromotion']
                                              .toString()
                                              .isNotEmpty
                                          ? TextDecoration.none
                                          : TextDecoration.none)),
                            )
                          : SkeletonContainer.square(
                              height: 1,
                              width: 10,
                            ),
                      ///////////////////////////////// fin prix
                      Container(
                        width: 5,
                      ),

                      Container(
                        alignment: Alignment.center,
                        height: 40,
                        width: 40,
                        child: IconButton(
                            icon: Icon(
                              Icons.shopping_cart_outlined,
                              color: Colors.white,
                            ),
                            onPressed: () {
                              if (panier.firstWhere(
                                    (element) =>
                                        element['phone'] == shareget('phone') &&
                                        element['idprod'] ==
                                            widget.map['idprod'] &&
                                        element['idetab'] ==
                                            widget.map['idetab'],
                                    orElse: () {
                                      return eve;
                                    },
                                  ) ==
                                  eve) {
                                Vistal_panier.push().set({
                                  'phone': shareget('phone').toString(),
                                  'idprod': widget.map['idprod'].toString(),
                                  'idetab': widget.map['idetab'].toString(),
                                  'date': DateTime.now().toString(),
                                  'qt': '1',
                                  'prix_total': infoprod['prix'],
                                  'prix': infoprod['prix'],
                                }).then((value) {});
                              } else {
                                snackshow(
                                    'Article déjà ajouté dans votre panier',
                                    context);
                              }
                            }),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            color: Colors.pink),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          )
        : Center(
            child: SkeletonContainer.square(
              width: 600.0,
              height: 200.0,
            ),
          );
  }
}
