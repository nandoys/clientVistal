import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/SeemoreProd.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';

class ProdfromCateg extends StatefulWidget {
  // const ProdfromCateg({ Key? key }) : super(key: key);
  final String? idetab;
  final String? nomcat;
  ProdfromCateg({@required this.idetab, @required this.nomcat});

  @override
  _ProdfromCategState createState() => _ProdfromCategState();
}

class _ProdfromCategState extends State<ProdfromCateg> {
  Map urlpro = {};
  List<Map> allprod = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      setState(() {
        if (!urlpro.containsKey((event.snapshot.value['idprod'] +
            event.snapshot.value['idetab']))) {
          urlpro[event.snapshot.value['idprod'] +
              event.snapshot.value['idetab']] = event.snapshot.value['url'];
        }
      });
    });
    Vistal_Produits.onChildAdded.listen((event) {
      if (event.snapshot.value['idetab'] == widget.idetab &&
          event.snapshot.value['cat'] == widget.nomcat) {
        setState(() {
          allprod.add({
            'idprod': event.snapshot.value['nom'],
            'idetab': event.snapshot.value['idetab'],
            'url': urlpro[
                '${event.snapshot.value['nom'] + event.snapshot.value['idetab']}']
          });
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Seemore(
      list: allprod,
    );
  }
}
