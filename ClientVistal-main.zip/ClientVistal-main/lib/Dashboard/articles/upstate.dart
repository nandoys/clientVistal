import 'package:flutter/material.dart';

class AppStates extends ChangeNotifier {
  int selectedCategoryId = 0;

  void updateCategoryId(int selectedCategoryId) {
    this.selectedCategoryId = selectedCategoryId;
    notifyListeners();
  }
}
