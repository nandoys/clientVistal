import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Category {
  final int? categoryId;
  final String? name;
  final IconData? icon;

  Category({this.categoryId, this.name, this.icon});
}

final Allproduit = Category(
  categoryId: 0,
  name: "Tout",
  icon: Icons.all_inclusive_sharp,
);

final bycategorie = Category(
  categoryId: 1,
  name: "Categories",
  icon: Icons.dynamic_feed_outlined,
);

// final bymarket = Category(
//   categoryId: 2,
//   name: "Marché",
//   icon: Icons.store,
// );
///////////////////////////////////////////////////////////////////////////::
final categories = [
  Allproduit,
  bycategorie,
  // bymarket,
  ////// on y ajoute une categorie créée
];
