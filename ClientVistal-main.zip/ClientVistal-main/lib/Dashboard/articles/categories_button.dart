import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vistalapp/Dashboard/articles/list_buttons_categories.dart';
import 'package:vistalapp/Dashboard/articles/upstate.dart';
import 'package:vistalapp/Dashboard/articles/style.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';

class CategoryWidget extends StatelessWidget {
  final Category? category;

  const CategoryWidget({Key? key, this.category}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppStates>(context);
    final isSelected = appState.selectedCategoryId == category!.categoryId;

    return GestureDetector(
      onTap: () {
        if (!isSelected) {
          appState.updateCategoryId(category!.categoryId!);
        }
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 15),
        width: 150,
        height: 90,
        decoration: BoxDecoration(
          border: Border.all(
              color: isSelected
                  ? dark == false || dark == eve
                      ? Colors.blue.shade900
                      : Colors.white
                  : dark == false || dark == eve
                      ? Colors.red
                      : Color(0x99FFFFFF),
              width: 3),
          borderRadius: BorderRadius.all(Radius.circular(16)),
          color: isSelected
              ? dark == false || dark == eve
                  ? Colors.blue.shade900
                  : Colors.white
              : dark == false || dark == eve
                  ? Colors.red
                  : Color(0x99FFFFFF),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(
              category!.icon,
              color: isSelected
                  ? dark == false || dark == eve
                      ? Colors.white
                      : Colors.red
                  : dark == false || dark == eve
                      ? Colors.white
                      : Colors.white,
              size: 40,
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              category!.name!,
              style: TextStyle(
                  color: isSelected
                      ? dark == false || dark == eve
                          ? Colors.white
                          : Colors.red
                      : dark == false || dark == eve
                          ? Colors.white
                          : Colors.white),
            )
          ],
        ),
      ),
    );
  }
}
