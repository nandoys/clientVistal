import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:vistalapp/Dashboard/Etab/EtabUI.dart';
import 'package:vistalapp/Dashboard/articles/list_buttons_categories.dart';
import 'package:vistalapp/Dashboard/articles/style.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Moeles.dart';
// import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:geolocator/geolocator.dart';
import 'package:location/location.dart';
import 'package:geocoder/geocoder.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';

class Maps extends StatefulWidget {
  @override
  MapsState createState() => MapsState();
}

class MapsState extends State<Maps> {
  Completer<GoogleMapController> _controller = Completer();
  late String _currentAddress;
  late int markerId;
  /////////////////////////////////////////////////////////
  List<EtabModel> restaurants = [];
  List<EtabModel> supermarches = [];
  List<EtabModel> boutique = [];
  List<EtabModel> articles = [];
  List<EtabModel> soinsbeautes = [];
  Map etaburls = {};
//////////////////////////////////////////////////////////////////////////////////////////////////
  LocationData _currentPositions = eve;
  String _address = '';
  Location location = Location();
  getLoc() async {
    bool _serviceEnabled;
    PermissionStatus _permissionGranted;
    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }
    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }
    ///////////////////////////////////////////////////////////////////////////////////
    location.onLocationChanged.listen((LocationData currentLocation) {
      setState(() {
        _currentPositions = currentLocation;
        _getAddress(currentLocation.latitude!, currentLocation.longitude!)
            .then((value) {
          setState(() {
            _address = "${value.first.locality} ${value.first.subLocality}";
          });
        });
      });
    });
  }

  Future<List<Address>> _getAddress(double lat, double lang) async {
    final coordinates = new Coordinates(lat, lang);
    List<Address> add =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    return add;
  }

///////////////////////////////////////////////////////////////////////////////////////////////
  @override
  void initState() {
    super.initState();
    // _getrestaurantsLlocation();
    // _getCurrentLocation();
    getLoc();
    ////////////////////////////////////////////////////////////////
    Vistal_vendeur_profil_photo.onChildAdded.listen((event) {
      setState(() {
        etaburls[event.snapshot.key!] = event.snapshot.value['url'];
      });
    });
    //////////////////////////////////////////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      if (event.snapshot.value['catEtab'] == 'Restaurant') {
        setState(() {
          restaurants.add(EtabModel(
              event.snapshot.key!,
              event.snapshot.value['etabname'],
              double.parse(event.snapshot.value['lat']),
              double.parse(
                event.snapshot.value['long'],
              ),
              etaburls[event.snapshot.key!]));
        });
      }
      ////////////////////////////////////////////////////////////
      if (event.snapshot.value['catEtab'] == 'Supermarché') {
        setState(() {
          supermarches.add(
            EtabModel(
                event.snapshot.key!,
                event.snapshot.value['etabname'],
                double.parse(event.snapshot.value['lat']),
                double.parse(event.snapshot.value['long']),
                etaburls[event.snapshot.key!]),
          );
        });
      }
      ////////////////////////
      if (event.snapshot.value['catEtab'] == 'Bijouterie, articles souvenirs') {
        setState(() {
          articles.add(EtabModel(
              event.snapshot.key!,
              event.snapshot.value['etabname'],
              double.parse(event.snapshot.value['lat']),
              double.parse(event.snapshot.value['long']),
              etaburls[event.snapshot.key!]));
        });
      }
      ////////////////////////
      if (event.snapshot.value['catEtab'] == 'Boutique') {
        setState(() {
          boutique.add(EtabModel(
              event.snapshot.key!,
              event.snapshot.value['etabname'],
              double.parse(event.snapshot.value['lat']),
              double.parse(event.snapshot.value['long']),
              etaburls[event.snapshot.key!]));
        });
      }
      if (event.snapshot.value['catEtab'] == 'Soins et beauté') {
        setState(() {
          soinsbeautes.add(EtabModel(
              event.snapshot.key!,
              event.snapshot.value['etabname'],
              double.parse(event.snapshot.value['lat']),
              double.parse(event.snapshot.value['long']),
              etaburls[event.snapshot.key!]));
        });
      }
    });
    /////////////////////////////
    category = 'Restaurant';
    color_selected = Colors.red;
    foodColor = Colors.blue;
    pharmaciesColor = Colors.blue;
    drinksColor = Colors.blue;
    superMarketsColor = Colors.blue;
    agroveterinariesColor = Colors.blue;
    cosmeticsColor = Colors.blue;
    clothingStoresColor = Colors.blue;
    _currentPositions != eve ? _getrestaurantsLlocation() : print('Vide');
  }

  double zoom = 15.0;
//////////////////////////////////////////////////////////////////////////////////////////////////
  @override
  Widget build(BuildContext context) {
    return _currentPositions != eve
        ? Stack(
            children: <Widget>[
              _buildGoogleMap(context),
              categories(),
              Padding(
                padding: const EdgeInsets.only(top: 500),
                child: getetabImages(category == 'Restaurant'
                    ? restaurants
                    : category == 'Super marché'
                        ? supermarches
                        : category == 'Boutique'
                            ? boutique
                            : category == 'Articles souvenirs'
                                ? articles
                                : soinsbeautes),
              )
            ],
          )
        : Container(
            child: Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
              ),
            ),
          );
  }

//////////////////////////////////////////////////////////////////////////////////////////////////////////
  String category = '';
  Color color_selected = Colors.blue;
  Color foodColor = Colors.blue;
  Color pharmaciesColor = Colors.blue;
  Color drinksColor = Colors.blue;
  Color superMarketsColor = Colors.blue;
  Color agroveterinariesColor = Colors.blue;
  Color cosmeticsColor = Colors.blue;
  Color clothingStoresColor = Colors.blue;

////////////////////////////////////////////////////////////////////////////////////////////////:
  Widget getetabImages(List<EtabModel> list) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (final etab in list)
            InkWell(
              onTap: () {
                push(context, EtabUI(idetab: etab.id));
              },
              child: Card(
                child: Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                        border: Border.all(
                            color: Colors.black.withOpacity(0.8), width: 1),
                      ),
                      height: 100,
                      width: 100,
                      child: etab.url != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(5),
                                  topRight: Radius.circular(5)),
                              child: etab.url != null
                                  ? Hero(
                                      tag: etab.url,
                                      child: Opacity(
                                        opacity: 0.8,
                                        child: CachedNetworkImage(
                                          filterQuality: FilterQuality.medium,
                                          fit: BoxFit.fill,
                                          imageUrl: etab.url,
                                          placeholder: (BuildContext context,
                                              String url) {
                                            return Center(
                                              child: SkeletonContainer.rounded(
                                                height: 100,
                                                width: 100,
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                    )
                                  : SkeletonContainer.rounded(
                                      height: 100,
                                      width: 100,
                                    ),
                            )
                          : Container(
                              alignment: Alignment.center,
                              child: Icon(
                                Icons.storefront_rounded,
                                size: 40,
                                color: Colors.pink,
                              )),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Text(
                        '${etab.nom}',
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color:
                                etab.url != null ? Colors.white : Colors.black,
                            fontSize: 8),
                      ),
                    )
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
////////////////////////////////////////////////////////////////////////////////////////////////:

  ///
  Widget categories() {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Align(
        alignment: Alignment.topCenter,
        child: Container(
          height: MediaQuery.of(context).size.height / 12,
          width: double.infinity,
          child: ListView(
              physics: BouncingScrollPhysics(),
              scrollDirection: Axis.horizontal,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: RaisedButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: color_selected,
                      textColor: Colors.white,
                      child: Row(
                        children: [
                          Container(
                            height: 40,
                            width: 40,
                            decoration: BoxDecoration(
                                // border:
                                // Border.all(color: Colors.white, width: 1),
                                borderRadius: BorderRadius.circular(20),
                                image: DecorationImage(
                                  image:
                                      AssetImage('assets/mapicons/resto.png'),
                                )),
                          ),
                          Text('Restaurant'),
                        ],
                      ),
                      onPressed: () {
                        setState(() {
                          _getrestaurantsLlocation();
                          _gotoLocation(_currentPositions.latitude!,
                              _currentPositions.longitude!);
                          //////////////////////////////////////////////////////////////////////
                          category = 'Restaurant';
                          color_selected = Colors.red;
                          foodColor = Colors.blue;
                          pharmaciesColor = Colors.blue;
                          drinksColor = Colors.blue;
                          superMarketsColor = Colors.blue;
                          agroveterinariesColor = Colors.blue;
                          cosmeticsColor = Colors.blue;
                          clothingStoresColor = Colors.blue;
                        });
                      }),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: RaisedButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: foodColor,
                      textColor: Colors.white,
                      child: Row(
                        children: [
                          Container(
                            height: 40,
                            width: 40,
                            decoration: BoxDecoration(
                                // border:
                                // Border.all(color: Colors.white, width: 1),
                                borderRadius: BorderRadius.circular(20),
                                image: DecorationImage(
                                  image:
                                      AssetImage('assets/mapicons/super.png'),
                                )),
                          ),
                          Text('SuperMarché'),
                        ],
                      ),
                      onPressed: () {
                        setState(() {
                          // markerRestos.clear();
                          _getallsupermarches();
                          _gotoLocation(_currentPositions.latitude!,
                              _currentPositions.longitude!);
                          // _getrestaurantsLlocation();
                          category = 'Super marché';
                          foodColor = Colors.red;
                          color_selected = Colors.blue;
                          pharmaciesColor = Colors.blue;
                          drinksColor = Colors.blue;
                          superMarketsColor = Colors.blue;
                          agroveterinariesColor = Colors.blue;
                          cosmeticsColor = Colors.blue;
                          clothingStoresColor = Colors.blue;
                        });
                      }),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: RaisedButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: pharmaciesColor,
                      textColor: Colors.white,
                      child: Row(
                        children: [
                          Container(
                            height: 40,
                            width: 40,
                            decoration: BoxDecoration(
                                // border:
                                // Border.all(color: Colors.white, width: 1),
                                borderRadius: BorderRadius.circular(20),
                                image: DecorationImage(
                                  image: AssetImage(
                                      'assets/mapicons/boutique.png'),
                                )),
                          ),
                          Text('Boutique'),
                        ],
                      ),
                      onPressed: () {
                        setState(() {
                          _getallboutique();
                          _gotoLocation(_currentPositions.latitude!,
                              _currentPositions.longitude!);
                          category = 'Boutique';
                          pharmaciesColor = Colors.red;
                          foodColor = Colors.blue;
                          color_selected = Colors.blue;
                          drinksColor = Colors.blue;
                          superMarketsColor = Colors.blue;
                          agroveterinariesColor = Colors.blue;
                          cosmeticsColor = Colors.blue;
                          clothingStoresColor = Colors.blue;
                        });
                      }),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: RaisedButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: drinksColor,
                      textColor: Colors.white,
                      child: Row(
                        children: [
                          Container(
                            height: 40,
                            width: 40,
                            decoration: BoxDecoration(
                                // border:
                                // Border.all(color: Colors.white, width: 1),
                                borderRadius: BorderRadius.circular(20),
                                image: DecorationImage(
                                  image: AssetImage(
                                      'assets/mapicons/souvenir.png'),
                                )),
                          ),
                          Text('Articles souvenirs'),
                        ],
                      ),
                      onPressed: () {
                        setState(() {
                          _getallsouvenir();
                          _gotoLocation(_currentPositions.latitude!,
                              _currentPositions.longitude!);
                          category = 'Articles souvenirs';
                          drinksColor = Colors.red;
                          foodColor = Colors.blue;
                          color_selected = Colors.blue;
                          pharmaciesColor = Colors.blue;
                          superMarketsColor = Colors.blue;
                          agroveterinariesColor = Colors.blue;
                          cosmeticsColor = Colors.blue;
                          clothingStoresColor = Colors.blue;
                        });
                      }),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: RaisedButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: agroveterinariesColor,
                      textColor: Colors.white,
                      child: Row(
                        children: [
                          Container(
                            height: 40,
                            width: 40,
                            decoration: BoxDecoration(
                                // border:
                                // Border.all(color: Colors.white, width: 1),
                                borderRadius: BorderRadius.circular(20),
                                image: DecorationImage(
                                  image: AssetImage('assets/mapicons/taxi.png'),
                                )),
                          ),
                          Text('Soins et beauté'),
                        ],
                      ),
                      onPressed: () {
                        setState(() {
                          _getallsoins();
                          _gotoLocation(_currentPositions.latitude!,
                              _currentPositions.longitude!);
                          category = 'Soins et beauté';
                          agroveterinariesColor = Colors.red;
                          foodColor = Colors.blue;
                          pharmaciesColor = Colors.blue;
                          drinksColor = Colors.blue;
                          superMarketsColor = Colors.blue;
                          color_selected = Colors.blue;
                          cosmeticsColor = Colors.blue;
                          clothingStoresColor = Colors.blue;
                        });
                      }),
                ),
              ]),
        ),
      ),
    );
  }

////////////////////////////////////////// google map //////////////////////////////////////////////////////////
////////////////////////////////////////// google map //////////////////////////////////////////////////////////
  Widget _buildGoogleMap(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: GoogleMap(
        zoomControlsEnabled: true,
        zoomGesturesEnabled: true,
        mapType: MapType.normal,
        myLocationEnabled: true, // autoriser la visibilité de ma localisation
        myLocationButtonEnabled: true, // ma localisation actuel bouton
        initialCameraPosition: CameraPosition(
            target: LatLng(
                _currentPositions.latitude!, _currentPositions.longitude!),
            zoom: 12),
        onMapCreated: (GoogleMapController controller) {
          _controller.complete(controller);
          _getrestaurantsLlocation();
        },
        markers: Set<Marker>.of(category == 'Restaurant'
            ? markerRestostrue.values
            : category == 'Super marché'
                ? markersupermarchestrue.values
                : category == 'Boutique'
                    ? markerboutiquetrue.values
                    : category == 'Articles souvenirs'
                        ? markersouvenirtrue.values
                        : soinstrue.values),
      ),
    );
  }

  Future<void> _gotoLocation(double lat, double long) async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
      target: LatLng(lat, long),
      zoom: 7,
      tilt: 30.0,
      bearing: 20.0,
    )));
  }

  Map<MarkerId, Marker> markerRestos = {};
  Map<MarkerId, Marker> markerRestostrue = {};
////////////////////////////////////////////////////////////
  Map<MarkerId, Marker> markersupermarches = {};
  Map<MarkerId, Marker> markersupermarchestrue = {};
  /////////////////////////////////////////////////////////////
  Map<MarkerId, Marker> markerboutique = {};
  Map<MarkerId, Marker> markerboutiquetrue = {};
  ///////////////////////////////////////////////////////////
  Map<MarkerId, Marker> markersouvenir = {};
  Map<MarkerId, Marker> markersouvenirtrue = {};
  ////////////////////////////////////////////////////////////
  Map<MarkerId, Marker> soins = {};
  Map<MarkerId, Marker> soinstrue = {};
////////////////////////////////////////////////////////////////////////////////////////////////
  void _getrestaurantsLlocation() async {
    markerRestos.clear();
    restaurants.forEach((element) async {
      double distance = await Geolocator.distanceBetween(
          double.parse(element.lat.toString()),
          double.parse(element.long.toString()),
          _currentPositions.latitude!,
          _currentPositions.longitude!);
      //////////
      if (distance <= 82000) {
        markerRestos[MarkerId(element.id)] = Marker(
            onTap: () {
              // toast('Restaurant ' + element.nom, Colors.red, Colors.white);
              push(context, EtabUI(idetab: element.id));
            },
            infoWindow:
                InfoWindow(title: element.nom, snippet: 'Une descrition'),
            // flat: true,
            consumeTapEvents: true,
            markerId: MarkerId(element.id),
            icon: await BitmapDescriptor.fromAssetImage(
              ImageConfiguration(devicePixelRatio: 2.5),
              'assets/mapicons/resto.png',
            ),
            // icon: BitmapDescriptor.defaultMarkerWithHue(
            //   BitmapDescriptor.huered,
            // ),
            position: LatLng(double.parse(element.lat.toString()),
                double.parse(element.long.toString())));
        setState(() {
          markerRestostrue = markerRestos;
        });
      }
    });
  }

///////////////////////////////////////////////////////////////////////////////////////////////////
  void _getallsupermarches() async {
    markersupermarches.clear();
    supermarches.forEach((element) async {
      double distance = await Geolocator.distanceBetween(
          double.parse(element.lat.toString()),
          double.parse(element.long.toString()),
          _currentPositions.latitude!,
          _currentPositions.longitude!);
      print("1");
      if (distance <= 82000) {
        markersupermarches[MarkerId(element.id)] = Marker(
            onTap: () {
              push(context, EtabUI(idetab: element.id));
            },
            infoWindow: InfoWindow(
              title: element.nom,
            ),
            consumeTapEvents: true,
            markerId: MarkerId(element.id),
            icon: await BitmapDescriptor.fromAssetImage(
              ImageConfiguration(devicePixelRatio: 1.0),
              'assets/mapicons/super.png',
            ),
            // icon: BitmapDescriptor.defaultMarkerWithHue(
            //   BitmapDescriptor.huered,
            // ),
            position: LatLng(double.parse(element.lat.toString()),
                double.parse(element.long.toString())));
        setState(() {
          markersupermarchestrue = markersupermarches;
        });
      }
    });
  }

  /////////////////////////////////////////////////
  void _getallboutique() async {
    markerboutique.clear();
    boutique.forEach((element) async {
      double distance = await Geolocator.distanceBetween(
          double.parse(element.lat.toString()),
          double.parse(element.long.toString()),
          _currentPositions.latitude!,
          _currentPositions.longitude!);
      print(distance);
      if (distance <= 82000) {
        markerboutique[MarkerId(element.id)] = Marker(
            onTap: () {
              // toast('Restaurant ' + element.nom, Colors.red, Colors.white);
              push(context, EtabUI(idetab: element.id));
            },
            infoWindow: InfoWindow(
              title: element.nom,
              snippet: element.nom,
            ),
            // flat: true,
            consumeTapEvents: true,
            markerId: MarkerId(element.id),
            icon: await BitmapDescriptor.fromAssetImage(
              ImageConfiguration(devicePixelRatio: 2.5),
              'assets/mapicons/boutique.png',
            ),
            // icon: BitmapDescriptor.defaultMarkerWithHue(
            //   BitmapDescriptor.huered,
            // ),
            position: LatLng(double.parse(element.lat.toString()),
                double.parse(element.long.toString())));
        setState(() {
          markerboutiquetrue = markerboutique;
        });
      }
    });
  }

  /////////////////////////////////////////////////////////////////////////////////
  void _getallsouvenir() async {
    markersouvenir.clear();
    articles.forEach((element) async {
      double distance = await Geolocator.distanceBetween(
          double.parse(element.lat.toString()),
          double.parse(element.long.toString()),
          _currentPositions.latitude!,
          _currentPositions.longitude!);
      print(distance);
      if (distance <= 82000) {
        markersouvenir[MarkerId(element.id)] = Marker(
            onTap: () {
              // toast('Restaurant ' + element.nom, Colors.red, Colors.white);
              push(context, EtabUI(idetab: element.id));
              print(element.nom);
            },
            infoWindow: InfoWindow(
              title: element.nom,
              snippet: element.nom,
            ),
            // flat: true,
            consumeTapEvents: true,
            markerId: MarkerId(element.id),
            icon: await BitmapDescriptor.fromAssetImage(
              ImageConfiguration(devicePixelRatio: 2.5),
              'assets/mapicons/souvenir.png',
            ),
            // icon: BitmapDescriptor.defaultMarkerWithHue(
            //   BitmapDescriptor.huered,
            // ),
            position: LatLng(double.parse(element.lat.toString()),
                double.parse(element.long.toString())));
        setState(() {
          markersouvenirtrue = markersouvenir;
        });
      }
    });
  }

  /////////////////////////////////////////////////////
  void _getallsoins() async {
    soins.clear();
    soinsbeautes.forEach((element) async {
      double distance = await Geolocator.distanceBetween(
          double.parse(element.lat.toString()),
          double.parse(element.long.toString()),
          _currentPositions.latitude!,
          _currentPositions.longitude!);
      print(distance);
      if (distance <= 82000) {
        soins[MarkerId(element.id)] = Marker(
            onTap: () {
              // toast('Restaurant ' + element.nom, Colors.red, Colors.white);
              print(element.nom);
            },
            infoWindow: InfoWindow(
              title: element.nom,
              snippet: element.nom,
            ),
            // flat: true,
            consumeTapEvents: true,
            markerId: MarkerId(element.id),
            icon: await BitmapDescriptor.fromAssetImage(
              ImageConfiguration(devicePixelRatio: 2.5),
              'assets/mapicons/taxi.png',
            ),
            // icon: BitmapDescriptor.defaultMarkerWithHue(
            //   BitmapDescriptor.huered,
            // ),
            position: LatLng(double.parse(element.lat.toString()),
                double.parse(element.long.toString())));
        setState(() {
          soinstrue = soins;
        });
      }
    });
  }
}
