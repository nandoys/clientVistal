import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:vistalapp/upload_image/firebase_storage_services.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';

class CompletCouseDetail extends StatefulWidget {
  final Map? infos;
  CompletCouseDetail({@required this.infos});

  @override
  _CompletCouseDetailState createState() => _CompletCouseDetailState();
}

class _CompletCouseDetailState extends State<CompletCouseDetail> {
  String nature = '';
  String accuse = '';
  List<String> tockens = [];
  var filename;
  bool _saving = false;
  TextEditingController descriprtion = TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_Admin.onChildAdded.listen((event) {
      setState(() {
        tockens.add(event.snapshot.value['tocken']);
      });
    });
    Vistal_coursier.onChildAdded.listen((event) {
      setState(() {
        tockens.add(event.snapshot.value['tocken']);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Infos complémentaires',
          style: TextStyle(fontSize: 14),
        ),
        // centerTitle: true,
        backgroundColor: Colors.red,
        elevation: 0,
        actions: [
          IconButton(
              onPressed: () async {
                if (accuse.isNotEmpty &&
                    nature.isNotEmpty &&
                    descriprtion.text.isNotEmpty) {
                  var url;
                  if (filename != null) {
                    // await showDialogs(context, 2, 'Envoi...');
                    setState(() {
                      _saving = true;
                    });
                    url = await sendimage(filename, 'CourseImageDescription');
                  }
                  // await showDialogs(context, 2, 'Envoi...');
                  await Vistal_Couse.push().set({
                    'infos': widget.infos,
                    'tockens': tockens,
                    'date': DateTime.now().toString(),
                    'accuse': accuse,
                    'nature': nature,
                    'description': descriprtion.text,
                    'idcoursier': '',
                    'statut': 'Traitement...',
                    'url': url.toString(),
                    'phone': shareget('phone'),
                    'paye_coursier': 'Non payé'
                  });
                  toast('Course créée avec succès', Colors.black, Colors.white);
                  setState(() {
                    _saving = false;
                  });
                  push(context, CallerCouserEtCommande());
                } else {
                  toast(
                      'Veullez completer toutes les informations non facultatives à la courses',
                      Colors.black,
                      Colors.white);
                }
              },
              icon: Icon(Icons.check))
        ],
      ),
      body: ModalProgressHUD(
        inAsyncCall: _saving,
        progressIndicator: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              SizedBox(
                height: 5,
              ),

              ///////////////////////////////////////////////////////////////////////////////////////////
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(),
                  Container(),
                  Container(),
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      image: DecorationImage(
                          image: AssetImage(
                            'assets/logos/go.png',
                          ),
                          fit: BoxFit.fill),
                    ),
                  ),
                  Container(),
                  Container(),
                  Container(),
                ],
              ),
              Card(
                child: ListTile(
                  title: Text('Départ'),
                  subtitle: Text(widget.infos!['orgAddresse']),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(),
                  Container(),
                  Container(),
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      image: DecorationImage(
                          image: AssetImage(
                            'assets/logos/pesa.png',
                          ),
                          fit: BoxFit.fill),
                    ),
                  ),
                  Container(),
                  Container(),
                  Container(),
                ],
              ),

              Card(
                child: ListTile(
                  title: Text('Destination'),
                  subtitle: Text(widget.infos!['destAddresse']),
                ),
              ),
              Card(
                child: ListTile(
                  title: Text('Tarif'),
                  subtitle: Text(
                    widget.infos!['prix'].toString() + '\$',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Padding(
                padding: const EdgeInsets.all(5.0),
                child: InkWell(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (_) {
                        return StatefulBuilder(builder:
                            (BuildContext context, StateSetter mystate) {
                          return SimpleDialog(
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20.0))),
                            // contentPadding: EdgeInsets.only(top: 10.0),
                            title: Text(
                              'Nature de l\'objet',
                              style: TextStyle(
                                  color: Colors.blueGrey,
                                  fontWeight: FontWeight.w600),
                            ),
                            children: [
                              Card(
                                  child: ListTile(
                                onTap: () {
                                  setState(() {
                                    nature = 'Colis';
                                  });
                                  pop(context);
                                },
                                title: Text('Colis'),
                              )),
                              Card(
                                  child: ListTile(
                                onTap: () {
                                  setState(() {
                                    nature = 'Courier';
                                  });
                                  pop(context);
                                },
                                title: Text('Courier'),
                              ))
                            ],
                          );
                        });
                      },
                      /////////////////////////////////////////////////////////////////////////////:
                    );
                  },
                  child: Container(
                    height: 50,
                    width: getwidth(context),
                    alignment: Alignment.center,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Text(
                            nature.isEmpty
                                ? 'Selectionner la nature de l\'objet'
                                : nature,
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                        Container(),
                        Container(),
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Icon(
                            Icons.select_all,
                            color: Colors.white,
                          ),
                        )
                      ],
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Padding(
                padding: const EdgeInsets.all(5.0),
                child: InkWell(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (_) {
                        return StatefulBuilder(builder:
                            (BuildContext context, StateSetter mystate) {
                          return SimpleDialog(
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20.0))),
                            // contentPadding: EdgeInsets.only(top: 10.0),
                            title: Text(
                              'Nature de l\'accusé',
                              style: TextStyle(
                                  color: Colors.blueGrey,
                                  fontWeight: FontWeight.w600),
                            ),
                            children: [
                              Card(
                                  child: ListTile(
                                onTap: () {
                                  setState(() {
                                    accuse = 'Accusé de reception physique';
                                  });
                                  showAlertDialogOnOkCallback(
                                      'A votre attention',
                                      'Un accusé de réception physique est consideré comme une course de plus. En selectionnant cette option, vous acceptez de prendre en charge la livraison de cet accusé au même prix que la course. (${(widget.infos!['prix']).toString()}\$)',
                                      DialogType.WARNING,
                                      context,
                                      () => {pop(context)});
                                  // pop(context);
                                },
                                title: Text('Accusé de reception physique'),
                              )),
                              Card(
                                  child: ListTile(
                                onTap: () {
                                  setState(() {
                                    accuse = 'Accusé de réception Electronique';
                                  });
                                  showAlertDialogOnOkCallback(
                                      'A votre attention',
                                      'Nous allons vous envoyer via Whattsapp un accusé de réception au numéro: ${shareget('phone')}',
                                      DialogType.WARNING,
                                      context,
                                      () => {pop(context)});
                                  // pop(context);
                                },
                                title: Text('Accusé de réception Electronique'),
                              ))
                            ],
                          );
                        });
                      },
                      /////////////////////////////////////////////////////////////////////////////:
                    );
                  },
                  child: Container(
                    height: 50,
                    width: getwidth(context),
                    alignment: Alignment.center,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Text(
                            accuse.isEmpty
                                ? 'Type d\'accusé de reception'
                                : accuse,
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                        Container(),
                        Container(),
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Icon(
                            Icons.message,
                            color: Colors.white,
                          ),
                        )
                      ],
                    ),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.blueGrey),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(4.0),
                child: Container(
                  height: 100,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    // border: Border.all(color: Colors.grey, width: 0.5)
                  ),
                  // ),
                  child: TextField(
                    keyboardType: TextInputType.multiline,
                    maxLengthEnforced: true,
                    // maxLength: 500,
                    maxLines: 10,
                    controller: descriprtion,
                    decoration: InputDecoration(
                      labelText:
                          '* Ajouter une  description ou appeler\nLe +243 83 053 73 53',
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(5.0),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Text(
                          'Ajouter une image descriptive de l\'objet(Facultatif)',
                          style: TextStyle(color: Colors.black),
                        ),
                        Container(),
                        Container(),
                        Container()
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Row(
                        children: [
                          Container(
                            height: 50,
                            width: 50,
                            child: IconButton(
                                onPressed: () async {
                                  showDialog(
                                    context: context,
                                    builder: (_) {
                                      return StatefulBuilder(builder:
                                          (BuildContext context,
                                              StateSetter mystate) {
                                        return SimpleDialog(
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(20.0))),
                                          // contentPadding: EdgeInsets.only(top: 10.0),
                                          title: Text(
                                            'Ajouter une image',
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          children: [
                                            InkWell(
                                              onTap: () async {
                                                print('pick here');
                                                pop(context);
                                                var image;
                                                var url;
                                                image =
                                                    await pickImageandcompress(
                                                        1, context);
                                                setState(() {
                                                  filename = image;
                                                });
                                              },
                                              child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(5.0),
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    height: 40,
                                                    width: getwidth(context),
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      color: Colors.red,
                                                    ),
                                                    child: Text(
                                                      'Galerie photos',
                                                      style: TextStyle(
                                                          color: Colors.white),
                                                    ),
                                                  )),
                                            ),
                                            InkWell(
                                              onTap: () async {
                                                pop(context);
                                                print('pick here');
                                                var image;
                                                var url;
                                                image =
                                                    await pickImageandcompress(
                                                        0, context);
                                                setState(() {
                                                  filename = image;
                                                });
                                              },
                                              child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(5.0),
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    height: 40,
                                                    width: getwidth(context),
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      color: Colors.blue,
                                                    ),
                                                    child: Text(
                                                      'Caméra',
                                                      style: TextStyle(
                                                          color: Colors.white),
                                                    ),
                                                  )),
                                            ),
                                          ],
                                        );
                                      });
                                    },
                                    //////////////////////////////////////////////////////////////////////////////////:
                                  );
                                },
                                icon: Icon(Icons.photo_camera)),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.grey),
                          ),
                          Container(),
                          Container(),
                          Container(),
                          Container(),
                          Container(),
                          Container(),
                          Container(),
                          Container(),
                          Container(),
                          filename != null
                              ? Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: Container(
                                    height: 50,
                                    width: 50,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        image: DecorationImage(
                                            image: FileImage(filename),
                                            fit: BoxFit.fill)),
                                  ),
                                )
                              : Container()
                        ],
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
