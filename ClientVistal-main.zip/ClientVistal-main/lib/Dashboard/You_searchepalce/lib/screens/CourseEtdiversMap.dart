import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Dashboard/You_searchepalce/lib/states/app_state.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:google_maps_place_picker/google_maps_place_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoder/geocoder.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'CompleteCouseEtdivers.dart';
import 'package:solid_bottom_sheet/solid_bottom_sheet.dart';
import 'package:awesome_dialog/awesome_dialog.dart';

class Couseetdiver extends StatefulWidget {
  @override
  _CouseetdiverState createState() => _CouseetdiverState();
}

class _CouseetdiverState extends State<Couseetdiver> {
  late PickResult origineresult;
  late PickResult destinationeresult;
  bool saveway = false;
  List<Event> oldadres = [];
  TextEditingController locationController = TextEditingController();
  TextEditingController destinationController = TextEditingController();
////////////////////////////////////////////////////////////////////////////////
  PolylinePoints polylinePoints = PolylinePoints();
  late PolylineResult result;
  late PointLatLng origine = eve;
  late PointLatLng destination = eve;
  List<Polyline> polyline = [];
  List<LatLng> routeCoords = [];
  List<Marker> allMarkers = [];
  SolidController _controller = SolidController();
  Smoothness? smoothness;
////////////////////////////////////////////////////////////////////////////////
  Future<bool> _gotoHom() {
    setState(() {
      locationController.text = '';
      destinationController.text = '';
    });
    push(context, Homepage(index: 2, page: 2, toseecat: null));
    return eve;
  }

////////////////////////////////////////////////////////////////////////////////
  Future<List<Address>> _getAddress(double lat, double lang) async {
    final coordinates = new Coordinates(lat, lang);
    List<Address> add =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    return add;
  }

  var test;
////////////////////////////////////////////////////////////////////////////////
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_chemin_Course.onChildAdded.listen((event) {
      setState(() {
        test = event.snapshot.key;
      });
      if (event.snapshot.value['userId'] == shareget('phone')) {
        setState(() {
          oldadres.add(event);
        });
      }
    });
  }

////////////////////////////////////////////////////////////////////////////////
  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    return WillPopScope(
      onWillPop: _gotoHom,
      child: Scaffold(
        bottomSheet: SolidBottomSheet(
            controller: _controller,
            maxHeight: locationController.text.isNotEmpty &&
                    destinationController.text.isNotEmpty
                ? 250
                : 130,
            minHeight: locationController.text.isNotEmpty &&
                    destinationController.text.isNotEmpty
                ? 250
                : 130,
            draggableBody: true,
            body: test != null
                ? Container(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: const EdgeInsets.all(6.0),
                      child: Column(
                        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          locationController.text.isEmpty
                              ? InkWell(
                                  onTap: () {
                                    // _controller.hide();
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          return PlacePicker(
                                            apiKey:
                                                'AIzaSyAi04dhThv5DBboLvTe3ysSNradOoZka4g',
                                            initialPosition:
                                                appState.initialPosition,
                                            useCurrentLocation: true,
                                            selectInitialPosition: true,
                                            usePlaceDetailSearch: true,
                                            hintText:
                                                'Rechercher le point de départ',
                                            region: 'CD',
                                            forceAndroidLocationManager: true,
                                            searchingText: 'Recherche...',
                                            ///////////////////////////////////////////////////////////////////////////////
                                            onPlacePicked: (depart) async {
                                              origineresult = depart;
                                              setState(() {
                                                Navigator.of(context).pop();
                                                setState(() {});
                                                // _controller.show();
                                                ////////////////////////////////////////////////////////////////////////////
                                                locationController.text = depart
                                                    .formattedAddress
                                                    .toString();
                                                //////////////////////////////////////////////////////////////////////////////////
                                                allMarkers.add(Marker(
                                                    markerId: MarkerId('org'),
                                                    position: LatLng(
                                                        depart.geometry!
                                                            .location.lat,
                                                        depart.geometry!
                                                            .location.lng),
                                                    infoWindow: InfoWindow(
                                                        title:
                                                            '${depart.formattedAddress}',
                                                        snippet: "Origine"),
                                                    icon: BitmapDescriptor
                                                        .defaultMarkerWithHue(
                                                            BitmapDescriptor
                                                                .hueRose)));

                                                //////////////////////////////////////////////////////////////////////////////////
                                                ////////////////////////////////////////////////////
                                                origine = PointLatLng(
                                                    depart
                                                        .geometry!.location.lat,
                                                    depart.geometry!.location
                                                        .lng);
                                              });
                                              await getPoints();
                                              appState.mapController
                                                  .animateCamera(
                                                CameraUpdate.newCameraPosition(
                                                  CameraPosition(
                                                      target: LatLng(
                                                          depart.geometry!
                                                              .location.lat,
                                                          depart.geometry!
                                                              .location.lng),
                                                      zoom: 14.0),
                                                ),
                                              );
                                              appState.notifyListeners();
                                            },

                                            ///////////////////////////////////////////////////
                                            forceSearchOnZoomChanged: true,
                                          );
                                        },
                                      ),
                                    );
                                  },
                                  child: Container(
                                    height: 30,
                                    // width: 400,
                                    alignment: Alignment.center,
                                    child: Padding(
                                      padding: const EdgeInsets.all(5.0),
                                      child: Text(
                                        locationController.text.isEmpty
                                            ? 'Selectionner le point de départ ou de ramassage'
                                            : 'Modifier le point de départ ou de ramassage',
                                        style: TextStyle(
                                            color: Colors.grey, fontSize: 14),
                                      ),
                                    ),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(
                                            color: Colors.black, width: 0.5),
                                        color: Colors.white),
                                  ),
                                )
                              : Container(),
                          SizedBox(
                            height: 5.0,
                          ),
                          locationController.text.isNotEmpty
                              ? Column(
                                  children: [
                                    Container(
                                        height: 50.0,
                                        width: double.infinity,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(3.0),
                                          color: Colors.white,
                                        ),
                                        child: TextField(
                                          // readOnly: true,
                                          cursorColor: Colors.black,
                                          controller: locationController,
                                          decoration: InputDecoration(
                                            icon: Container(
                                              margin: EdgeInsets.only(
                                                  left: 20, top: 5),
                                              width: 10,
                                              height: 10,
                                              child: Icon(
                                                Icons.location_on,
                                                color: Colors.black,
                                              ),
                                            ),
                                            hintText: "Départ?",
                                            border: InputBorder.none,
                                            contentPadding: EdgeInsets.only(
                                                left: 15.0, top: 16.0),
                                          ),
                                        )),
                                    InkWell(
                                      onTap: () async {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) {
                                              return PlacePicker(
                                                apiKey:
                                                    'AIzaSyAi04dhThv5DBboLvTe3ysSNradOoZka4g',
                                                initialPosition:
                                                    appState.initialPosition,
                                                useCurrentLocation: true,
                                                selectInitialPosition: true,
                                                usePlaceDetailSearch: true,
                                                hintText:
                                                    'Rechercher le point de départ',
                                                region: 'CD',
                                                forceAndroidLocationManager:
                                                    true,
                                                searchingText: 'Recherche...',
                                                ///////////////////////////////////////////////////////////////////////////////
                                                onPlacePicked: (depart) async {
                                                  origineresult = depart;
                                                  setState(() {
                                                    Navigator.of(context).pop();
                                                    setState(() {});
                                                    // _controller.show();
                                                    ////////////////////////////////////////////////////////////////////////////
                                                    locationController.text =
                                                        depart.formattedAddress
                                                            .toString();
                                                    //////////////////////////////////////////////////////////////////////////////////
                                                    allMarkers.add(Marker(
                                                        markerId:
                                                            MarkerId('org'),
                                                        position: LatLng(
                                                            depart.geometry!
                                                                .location.lat,
                                                            depart.geometry!
                                                                .location.lng),
                                                        infoWindow: InfoWindow(
                                                            title:
                                                                '${depart.formattedAddress}',
                                                            snippet: "Origine"),
                                                        icon: BitmapDescriptor
                                                            .defaultMarkerWithHue(
                                                                BitmapDescriptor
                                                                    .hueRose)));

                                                    //////////////////////////////////////////////////////////////////////////////////
                                                    ////////////////////////////////////////////////////
                                                    origine = PointLatLng(
                                                        depart.geometry!
                                                            .location.lat,
                                                        depart.geometry!
                                                            .location.lng);
                                                  });
                                                  await getPoints();
                                                  appState.mapController
                                                      .animateCamera(
                                                    CameraUpdate
                                                        .newCameraPosition(
                                                      CameraPosition(
                                                          target: LatLng(
                                                              depart.geometry!
                                                                  .location.lat,
                                                              depart
                                                                  .geometry!
                                                                  .location
                                                                  .lng),
                                                          zoom: 14.0),
                                                    ),
                                                  );
                                                  appState.notifyListeners();
                                                },

                                                ///////////////////////////////////////////////////
                                                forceSearchOnZoomChanged: true,
                                              );
                                            },
                                          ),
                                        );
                                      },
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Container(),
                                          Container(),
                                          Container(),
                                          Text(
                                            'Modifier le point de départ sur la carte',
                                            style:
                                                TextStyle(color: Colors.blue),
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                )
                              : Container(),
                          SizedBox(
                            height: 5.0,
                          ),
                          destinationController.text.isEmpty
                              ? InkWell(
                                  onTap: () {
                                    // _controller.hide();
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          return PlacePicker(
                                            apiKey:
                                                'AIzaSyAi04dhThv5DBboLvTe3ysSNradOoZka4g',
                                            initialPosition:
                                                appState.initialPosition,
                                            useCurrentLocation: true,
                                            selectInitialPosition: true,
                                            usePlaceDetailSearch: true,

                                            hintText:
                                                'Rechercher la destination',
                                            region: 'CD',
                                            searchingText: 'Recherche...',
                                            /////////////////////////////////////////////////////////////////////////////////////////////////
                                            onPlacePicked: (arriveee) async {
                                              setState(() {
                                                // _controller.show();
                                                destinationeresult = arriveee;
                                                Navigator.of(context).pop();
                                                setState(() {});
                                                //////////////////////////////////////////////////////////////////////////////////
                                                destinationController.text =
                                                    arriveee.formattedAddress
                                                        .toString();
                                                //////////////////////////////////////////////////////////////////////////////////

                                                allMarkers.add(Marker(
                                                    markerId: MarkerId('arrv'),
                                                    position: LatLng(
                                                        arriveee.geometry!
                                                            .location.lat,
                                                        arriveee.geometry!
                                                            .location.lng),
                                                    infoWindow: InfoWindow(
                                                        title:
                                                            '${arriveee.formattedAddress}',
                                                        snippet: "Destination"),
                                                    icon: BitmapDescriptor
                                                        .defaultMarkerWithHue(
                                                            BitmapDescriptor
                                                                .hueRed)));
                                                /////////////////////////////////////////////////////////////////////////////////////////////////
                                                /////////////////////////////////////////////////////////////////////////////////////////////////
                                                destination = PointLatLng(
                                                    arriveee
                                                        .geometry!.location.lat,
                                                    arriveee.geometry!.location
                                                        .lng);
                                              });
                                              await getPoints();
                                              ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                              // appState.setmappos();
                                              appState.mapController
                                                  .animateCamera(
                                                CameraUpdate.newCameraPosition(
                                                  CameraPosition(
                                                      target: LatLng(
                                                          arriveee.geometry!
                                                              .location.lat,
                                                          arriveee.geometry!
                                                              .location.lng),
                                                      zoom: 14.0),
                                                ),
                                              );
                                              appState.notifyListeners();
                                            },
                                            ///////////////////////////////////////////////////
                                            forceSearchOnZoomChanged: true,
                                          );
                                        },
                                      ),
                                    );
                                  },
                                  child: Container(
                                    height: 30,
                                    // width: 400,
                                    alignment: Alignment.center,
                                    child: Padding(
                                      padding: const EdgeInsets.all(5.0),
                                      child: Text(
                                        destinationController.text.isEmpty
                                            ? 'Selectionner le point  d\'arrivé ou de dépôt'
                                            : 'Modifier le point  d\'arrivée ou de dépôt',
                                        style: TextStyle(
                                            color: Colors.grey, fontSize: 14),
                                      ),
                                    ),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(
                                            color: Colors.black, width: 0.5),
                                        color: Colors.white),
                                  ),
                                )
                              : Container(),
                          SizedBox(
                            height: 5.0,
                          ),
                          destinationController.text.isNotEmpty
                              ? Column(
                                  children: [
                                    Container(
                                        height: 50.0,
                                        width: double.infinity,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(3.0),
                                          color: Colors.white,
                                        ),
                                        child: Column(
                                          children: [
                                            TextField(
                                              cursorColor: Colors.black,
                                              controller: destinationController,
                                              textInputAction:
                                                  TextInputAction.go,
                                              onChanged: (value) {},
                                              decoration: InputDecoration(
                                                icon: Container(
                                                  margin: EdgeInsets.only(
                                                      left: 20, top: 5),
                                                  width: 10,
                                                  height: 10,
                                                  child: Icon(
                                                    Icons.motorcycle,
                                                    color: Colors.black,
                                                  ),
                                                ),
                                                hintText: "destination?",
                                                border: InputBorder.none,
                                                contentPadding: EdgeInsets.only(
                                                    left: 15.0, top: 16.0),
                                              ),
                                            )
                                          ],
                                        )),
                                    InkWell(
                                      onTap: () {
                                        // _controller.hide();
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) {
                                              return PlacePicker(
                                                apiKey:
                                                    'AIzaSyAi04dhThv5DBboLvTe3ysSNradOoZka4g',
                                                initialPosition:
                                                    appState.initialPosition,
                                                useCurrentLocation: true,
                                                selectInitialPosition: true,
                                                usePlaceDetailSearch: true,

                                                hintText:
                                                    'Rechercher la destination',
                                                region: 'CD',
                                                searchingText: 'Recherche...',
                                                /////////////////////////////////////////////////////////////////////////////////////////////////
                                                onPlacePicked:
                                                    (arriveee) async {
                                                  setState(() {
                                                    // _controller.show();
                                                    destinationeresult =
                                                        arriveee;
                                                    Navigator.of(context).pop();
                                                    setState(() {});
                                                    //////////////////////////////////////////////////////////////////////////////////
                                                    destinationController.text =
                                                        arriveee
                                                            .formattedAddress
                                                            .toString();
                                                    //////////////////////////////////////////////////////////////////////////////////

                                                    allMarkers.add(Marker(
                                                        markerId:
                                                            MarkerId('arrv'),
                                                        position: LatLng(
                                                            arriveee.geometry!
                                                                .location.lat,
                                                            arriveee.geometry!
                                                                .location.lng),
                                                        infoWindow: InfoWindow(
                                                            title:
                                                                '${arriveee.formattedAddress}',
                                                            snippet:
                                                                "Destination"),
                                                        icon: BitmapDescriptor
                                                            .defaultMarkerWithHue(
                                                                BitmapDescriptor
                                                                    .hueRed)));
                                                    /////////////////////////////////////////////////////////////////////////////////////////////////
                                                    /////////////////////////////////////////////////////////////////////////////////////////////////
                                                    destination = PointLatLng(
                                                        arriveee.geometry!
                                                            .location.lat,
                                                        arriveee.geometry!
                                                            .location.lng);
                                                  });
                                                  await getPoints();
                                                  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                  // appState.setmappos();
                                                  appState.mapController
                                                      .animateCamera(
                                                    CameraUpdate
                                                        .newCameraPosition(
                                                      CameraPosition(
                                                          target: LatLng(
                                                              arriveee.geometry!
                                                                  .location.lat,
                                                              arriveee
                                                                  .geometry!
                                                                  .location
                                                                  .lng),
                                                          zoom: 14.0),
                                                    ),
                                                  );
                                                  appState.notifyListeners();
                                                },
                                                ///////////////////////////////////////////////////
                                                forceSearchOnZoomChanged: true,
                                              );
                                            },
                                          ),
                                        );
                                      },
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Container(),
                                          Container(),
                                          Container(),
                                          Text(
                                            'Modifier le point de dépôt sur la carte',
                                            style:
                                                TextStyle(color: Colors.blue),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                )
                              : Container(),
                          destinationController.text.isNotEmpty &&
                                  locationController.text.isNotEmpty
                              ? Padding(
                                  padding: const EdgeInsets.only(top: 15.0),
                                  child: InkWell(
                                    onTap: () {
                                      showrecapitulatif(
                                          origineresult.geometry!.location.lat,
                                          origineresult.geometry!.location.lng,
                                          destinationeresult
                                              .geometry!.location.lat,
                                          destinationeresult
                                              .geometry!.location.lng,
                                          '${locationController.text.toString()}',
                                          '${destinationController.text.toString()}',
                                          'carte');
                                    },
                                    child: Container(
                                      height: 40.0,
                                      width: 250,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                          color: Colors.green.shade500,
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      child: Text(
                                        'Valider la course',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 3),
                                      ),
                                    ),
                                  ),
                                )
                              : Container(),
                        ],
                      ),
                    ),
                  )
                : Center(
                    child: Column(
                      children: [
                        SizedBox(
                          height: 3.0,
                        ),
                        CircularProgressIndicator(
                            valueColor:
                                AlwaysStoppedAnimation<Color>(Colors.red)),
                        SizedBox(
                          height: 5.0,
                        ),
                        Text('En attente de connexion...')
                      ],
                    ),
                  ),
            headerBar: InkWell(
              onTap: () {
                _controller.isOpened ? _controller.hide() : _controller.show();
              },
              child: Container(
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.red,
                  // _controller.isOpened ?
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    topRight: Radius.circular(15),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Center(
                      child: Text(
                        locationController.text.isNotEmpty &&
                                destinationController.text.isNotEmpty
                            ? "Confirmer les itineraires"
                            : locationController.text.isEmpty
                                ? 'Déterminer les coordonnées'
                                : 'Déterminer les coordonnées',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 3),
                      ),
                    ),
                    IconButton(
                        onPressed: () {
                          showAlertDialogOnOkCallback(
                              'C\'est quoi course et diverse ?',
                              'Course et diverse est cette option qui vous donne la posibilité de vous faire livrer vos courriers ou colis partout à kinshasa.\n Pour se faire, vous devez selectionner le point de ramassage du colis ou courrier et selectionner le point du dépôt puis Vistal s\'en charge du reste, donc de la livraison.',
                              DialogType.QUESTION,
                              context,
                              () => {});
                        },
                        icon: Icon(
                          Icons.help,
                          color: Colors.white,
                        ))
                  ],
                ),
              ),
            )),
        // appBar: AppBar(),

        floatingActionButtonLocation: FloatingActionButtonLocation.centerTop,
        floatingActionButton: locationController.text.isEmpty &&
                destinationController.text.isEmpty
            ?
            //////////////////////////////////////////////////////////////////////////////////:
            //////////////////////////////////////////////////////////////////////////////////:
            //////////////////////////////////////////////////////////////////////////////////:
            oldadres.isNotEmpty
                ? FloatingActionButton(
                    backgroundColor: Colors.white,
                    onPressed: () async {
                      showDialog(
                        context: context,
                        builder: (_) {
                          return StatefulBuilder(builder:
                              (BuildContext context, StateSetter mystate) {
                            return SimpleDialog(
                              shape: RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(20.0))),
                              // contentPadding: EdgeInsets.only(top: 10.0),
                              title: Text(
                                'Chemins sauvegardés',
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w600),
                              ),
                              children: [
                                for (final chemin in oldadres.reversed)
                                  Card(
                                    child: ListTile(
                                      onTap: () async {
                                        pop(context);
                                        showrecapitulatif(
                                            chemin.snapshot.value['latorg'],
                                            chemin.snapshot.value['longorg'],
                                            chemin.snapshot.value['latdest'],
                                            chemin.snapshot.value['longdest'],
                                            chemin.snapshot
                                                .value['adresseOrigine'],
                                            chemin.snapshot
                                                .value['adresseDestination'],
                                            'save');
                                      },
                                      title: Text(
                                          'Départ: \n${chemin.snapshot.value['adresseOrigine']}'),
                                      subtitle: Text(
                                          '\n\nDestination: \n${chemin.snapshot.value['adresseDestination']}'),
                                    ),
                                  )
                              ],
                            );
                          });
                        },
                        /////////////////////////////////////////////////////////////////////////////:
                      );
                    },
                    child: Icon(
                      Icons.favorite,
                      color: Colors.red,
                    ),
                  )
                : Container()
            : Container(),
        // : Container(),
        body: SafeArea(
            child: appState.initialPosition == eve
                ? Container(
                    child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          SpinKitRotatingCircle(
                            color: Colors.black,
                            size: 50.0,
                          )
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Visibility(
                        visible: appState.locationServiceActive == false,
                        child: Text(
                          "Veuillez activer le service de localisation svp!",
                          style: TextStyle(color: Colors.grey, fontSize: 14),
                        ),
                      )
                    ],
                  ))
                : GoogleMap(
                    initialCameraPosition: CameraPosition(
                        target: appState.initialPosition, zoom: 15.0),
                    onMapCreated: appState.onCreated,
                    myLocationEnabled: true,
                    mapType: MapType.normal,
                    compassEnabled: true,
                    markers: Set.from(allMarkers),
                    onCameraMove: appState.onCameraMove,
                    polylines: Set.from(polyline),
                  )),
      ),
    );
  }
  ///////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

  showrecapitulatif(
      orglat, orlong, deslat, destlong, addesdep, addressdest, from) async {
    if (orglat != deslat && orlong != destlong) {
      double metres =
          await Geolocator.distanceBetween(orglat, orlong, deslat, destlong);
      /////////////////////////////////////////////////////////////////////////////////////////::
      double km = metres / 1000;
      print(km);
      double prix = 0.0;
      if ((km >= 0) && (km <= 10)) {
        prix = 5.0;
      }
      if ((km > 10) && (km <= 15)) {
        prix = 7.0;
      }
      if ((km > 15) && (km <= 20)) {
        prix = 10.0;
      }
      if (km > 20) {
        prix = 20.0;
      }

      ///////////////////////////////////////////////////////////////////////////////////////////
      var communeDepart;
      var communeArrive;

      await _getAddress(
        orglat,
        orlong,
      ).then((value) {
        setState(() {
          communeDepart = value.first.subLocality;
        });
      });
      await _getAddress(deslat, destlong).then((value) {
        setState(() {
          communeArrive = value.first.subLocality;
        });
      });
      ///////////////////////////////////////////////////////////////////////////////////////////
      showDialog(
        context: context,
        builder: (_) {
          return StatefulBuilder(
              builder: (BuildContext context, StateSetter mystate) {
            return SimpleDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(20.0))),
              // contentPadding: EdgeInsets.only(top: 10.0),
              title: Text(
                'Récapitulatif',
                style: TextStyle(
                    color: Colors.blueGrey, fontWeight: FontWeight.w600),
              ),
              children: [
                ListTile(
                  subtitle: Text(
                    from == 'save'
                        ? 'Départ:\n$addesdep\n\nDestination:\n$addressdest'
                        : 'Départ:\n$addesdep\nCommune de: $communeDepart \n\nDestination:\n$addressdest \n Commune de: $communeArrive',
                  ),
                  title: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Text(
                          'Tarif:',
                          style: TextStyle(color: Colors.blueAccent),
                        ),
                        SizedBox(
                          width: 4,
                        ),
                        Text(
                          '${prix.toString()}\$',
                          style: TextStyle(color: Colors.blueAccent),
                        ),
                      ],
                    ),
                  ),
                ),
                options('Valider la course', Colors.blue, Icons.check, () {
                  pop(context);
                  push(
                      context,
                      CompletCouseDetail(
                        infos: {
                          'orgAddresse': addesdep,
                          'destAddresse': addressdest,
                          'prix': prix,
                          'orglat': orglat,
                          'orglong': orlong,
                          'destlat': deslat,
                          'destlong': destlong,
                          'communedep': communeDepart.toString(),
                          'communearriv': communeArrive.toString()
                        },
                      ));
                }),
                saveway == false
                    ? oldadres.firstWhere(
                              (element) =>
                                  element.snapshot.value['latdest'] == deslat &&
                                  element.snapshot.value['latorg'] == orglat &&
                                  element.snapshot.value['longdest'] ==
                                      destlong &&
                                  element.snapshot.value['longorg'] == orlong,
                              orElse: () {
                                return eve;
                              },
                            ) ==
                            eve
                        ? options(
                            'Sauvegarder le chemin', Colors.black, Icons.save,
                            () async {
                            await showDialogs(context, 2, 'Sauvegarde...');
                            // toast('Sauvegarde...', Colors.black,
                            //     Colors.white);
                            Vistal_chemin_Course.push().set({
                              'adresseOrigine': locationController.text
                                      .toString() +
                                  '\nCommune de: ${communeDepart.toString()}',
                              'adresseDestination': destinationController.text
                                      .toString() +
                                  '\nCommune de: ${communeArrive.toString()}',
                              'latorg': orglat,
                              'longorg': orlong,
                              'latdest': deslat,
                              'longdest': destlong,
                              'userId': shareget('phone').toString()
                            });
                            mystate(() {
                              saveway = true;
                            });
                            toast('Chemin sauvegardé avec succès', Colors.black,
                                Colors.white);
                          })
                        : Container()
                    : Container(),
                options(
                    'Modifier les coordonnées', Colors.blueGrey, Icons.create,
                    () {
                  setState(() {
                    destinationController.text = '';
                    locationController.text = '';
                    _controller.show();
                    allMarkers.clear();
                    polyline.clear();
                    origine = eve;
                    destination = eve;
                    // _controller.
                  });
                  pop(context);
                }),
              ],
            );
          });
        },
        //////////////////////////////////////////////////////////////////////////////////:
      );
    } else {
      toast('L\'origine dois être différente de la destination', Colors.black,
          Colors.white);
    }
  }

///////////////////////////////////////////////////////////////////////////////////////////////////
  options(text, Color color, IconData iconData, function) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: InkWell(
        onTap: function,
        child: Container(
          height: 50,
          width: getwidth(context),
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Text(
                text,
                style: TextStyle(color: Colors.white),
              ),
              Container(),
              Container(),
              Icon(
                iconData,
                color: Colors.white,
                size: 30,
              )
            ],
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: color,
          ),
        ),
      ),
    );
  }

  //////////////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////////////////
  Future<PolylineResult> getPoints() async {
    if (origine != eve && destination != eve) {
      polyline.clear();
      result = await polylinePoints
          .getRouteBetweenCoordinates(
              "AIzaSyAi04dhThv5DBboLvTe3ysSNradOoZka4g", origine, destination)
          .then((p) {
        routeCoords = p.points.map((k) {
          return LatLng(k.latitude, k.longitude);
        }).toList();
        setState(() {
          polyline.add(new Polyline(
              polylineId: PolylineId("id1"),
              color: Colors.black,
              points: routeCoords,
              visible: true,
              width: 4,
              startCap: Cap.roundCap,
              endCap: Cap.buttCap));
        });
        return p;
      });
      return result;
    } else {
      return eve;
    }
  }
}
