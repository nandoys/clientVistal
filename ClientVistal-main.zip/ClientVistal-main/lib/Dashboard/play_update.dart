import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';

////////////////////////////////////////////////////////////////////////////////

class Customdialog extends StatefulWidget {
  final String title, description, buttontext;
  // final AssetImage image;
  Customdialog(
    this.title,
    this.description,
    this.buttontext,
  );
  @override
  _CustomdialogState createState() => _CustomdialogState();
}

class _CustomdialogState extends State<Customdialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: dialogContent(context, () {}),
    );
  }

  dialogContent(_, Function function) {
    return Stack(
      children: [
        Container(
          padding: EdgeInsets.only(top: 100, bottom: 16, left: 16, right: 14),
          margin: EdgeInsets.only(top: 14),
          decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.circular(17),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 10.0,
                  offset: Offset(0.0, 10.0),
                )
              ]),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                widget.title,
                style: TextStyle(
                  fontSize: 10.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(
                height: 16,
              ),
              Text(
                widget.description,
                style: TextStyle(
                  fontSize: 10,
                ),
              ),
              SizedBox(
                height: 24,
              ),
              Align(
                alignment: Alignment.centerRight,
                child: FlatButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('Bien compris')),
              )
            ],
          ),
        ),
        Positioned(
            top: 0,
            left: 16,
            right: 14,
            child: Container(
              height: 100,
              width: 100,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(100),
                child: CachedNetworkImage(
                  filterQuality: FilterQuality.medium,
                  fit: BoxFit.fill,
                  imageUrl: shareget('urlphoto'),
                  placeholder: (BuildContext context, String url) {
                    return Center(
                      child: SkeletonContainer.rounded(
                        height: 100,
                        width: 100,
                      ),
                    );
                  },
                ),
              ),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white, width: 1),
                borderRadius: BorderRadius.circular(60),
              ),
            ))
      ],
    );
  }
}

///////////////////////////////////////////////////////////////////*
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
class Playsoredialog extends StatefulWidget {
  final String title, description, buttontext;
  final AssetImage image;
  Playsoredialog(this.title, this.description, this.buttontext, this.image);
  @override
  _PlaysoredialogState createState() => _PlaysoredialogState();
}

class _PlaysoredialogState extends State<Playsoredialog> {
  launchURL(link) async {
    if (await canLaunch(link)) {
      await launch(link);
    } else {
      throw 'Could not launch $link';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: dialogContent(context, () {}),
    );
  }

  dialogContent(_, Function function) {
    return Stack(
      children: [
        Container(
          padding: EdgeInsets.only(top: 100, bottom: 16, left: 16, right: 14),
          margin: EdgeInsets.only(top: 14),
          decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.circular(17),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 10.0,
                  offset: Offset(0.0, 10.0),
                )
              ]),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height: 54,
                decoration: BoxDecoration(),
                width: getwidth(context),
                alignment: Alignment.center,
                child: Text(
                  widget.title,
                  style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.w600,
                      color: Colors.black),
                ),
              ),
              SizedBox(
                height: 16,
              ),
              Text(
                widget.description,
                style: TextStyle(
                    fontSize: 18, color: Colors.black, fontFamily: 'font1'),
              ),
              SizedBox(
                height: 24,
              ),
              Align(
                alignment: Alignment.centerRight,
                child: FlatButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 50.0),
                        child: InkWell(
                          child: Text(
                            'Mettre à Jour',
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.blue,
                                fontSize: 20),
                          ),
                          onTap: () {
                            launchURL(
                                'https://play.google.com/store/apps/details?id=hellofootballpub.com');
                            Navigator.pop(context);
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 50.0),
                        child: InkWell(
                          child: Text(
                            'Plustard',
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.blue,
                                fontSize: 20),
                          ),
                          onTap: () {
                            Navigator.pop(context);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
        Positioned(
          top: 0,
          left: 16,
          right: 14,
          child: CircleAvatar(
            backgroundColor: Colors.transparent,
            radius: 40,
            child: Image(image: widget.image),
          ),
        )
      ],
    );
  }
}
