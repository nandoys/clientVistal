import 'dart:math';
import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/Mydrawer.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/two_separete.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/ui_list_prod.dart';

import 'articles/Poduct_ui/SeemoreProd.dart';

class Messages extends StatefulWidget {
  @override
  _MessagesState createState() => _MessagesState();
}

class _MessagesState extends State<Messages> {
  String news = '';
  String plus_cons = '';
  String livraison = '';
  String moins_cher = '';
/////////////////////////////////////
  List<Map> promotionels = [];
  List<Map> articlemoincher = [];
  List<Map> pluscommandes = [];
  List<Map> newarticles = [];
  List<Map> allarticles = [];
//////// ///////////////
  late String lastdate;
  Map urlpro = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
///////////////////////////////////////:: url prodd
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      print('url vuuuuu');
      setState(() {
        if (!urlpro.containsKey(event.snapshot.value['idprod'].toString())) {
          setState(() {
            urlpro[event.snapshot.value['idprod'].toString()] =
                event.snapshot.value['url'].toString();
          });
        }
      });
    });
//////////////////////////////////////////////////////////////////////////////////////////:
    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      if (event.snapshot.key == shareget('phone')) {
        setState(() {
          lastdate = event.snapshot.value['lastconnexion'];
        });
      }
    });
    /////////////////////// mise à jour de la date de connexion
    Vistal_SIMPLEUSER.child(shareget('phone')).update({
      'lastconnexion': DateTime.now().toString(),
    });
    ////////////////////////////////////////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      setState(() {
        allarticles.add({
          'idprod': event.snapshot.value['nom'],
          'idcat': event.snapshot.value['idcat'],
          'idetab': event.snapshot.value['idetab'],
          'prixpromotion': event.snapshot.value['prixpromotion'],
          'prix': event.snapshot.value['prix'],
          'url': urlpro[event.snapshot.value['nom']]
        });
      });
      setState(() {
        if (event.snapshot.value['promotion'] == 'true') {
          promotionels.add({
            'idprod': event.snapshot.value['nom'],
            'idcat': event.snapshot.value['idcat'],
            'idetab': event.snapshot.value['idetab'],
            'prixpromotion': event.snapshot.value['prixpromotion'],
            'prix': event.snapshot.value['prix'],
            'url': urlpro[event.snapshot.value['nom']]
          });
        }
      });
      //////////////////////////////////////////// new prod /////////////////////////
      if (DateTime.parse(event.snapshot.value['date'])
          .isAfter(DateTime.parse(lastdate))) {
        newarticles.add({
          'idprod': event.snapshot.value['nom'],
          'idcat': event.snapshot.value['idcat'],
          'idetab': event.snapshot.value['idetab'],
          'url': urlpro[event.snapshot.value['nom']],
          'prix': event.snapshot.value['prix'],
        });
      }
      ////////////////////// moins cher <5$
      if (double.parse(event.snapshot.value['prix']) < 5.0) {
        articlemoincher.add({
          'idprod': event.snapshot.value['nom'],
          'idcat': event.snapshot.value['idcat'],
          'idetab': event.snapshot.value['idetab'],
          'url': urlpro[event.snapshot.value['nom']],
          'prix': event.snapshot.value['prix'],
        });
      }
    });
/////////////////////////////////////////////////////////////////////////////////
/////////////////// les plus commandés //////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
    Vistal_Commandes.onChildAdded.listen((event) {
      if (event.snapshot.value['livre'] != 'false') {
        for (final prod in event.snapshot.value['listprods']) {
          setState(() {
            var old = pluscommandes.firstWhere(
              (element) =>
                  element['key'].toString() ==
                  (prod['idetab'] + prod['idprod']).toString(),
              orElse: () {
                return eve;
              },
            );
            if (old == eve) {
              pluscommandes.add({
                'idprod': prod['idprod'],
                'idetab': prod['idetab'],
                'url': urlpro[prod['idprod']],
                'key': prod['idetab'].toString() + prod['idprod'].toString(),
                'prix': prod['prix'],
                'vue': 1
              });
            } else {
              pluscommandes.remove(old);
              pluscommandes.add({
                'idprod': prod['idprod'],
                'idetab': prod['idetab'],
                'url': urlpro[prod['idprod']],
                'key': prod['idetab'].toString() + prod['idprod'].toString(),
                'prix': prod['prix'],
                'vue': old['vue'] + 1
              });
            }
          });
        }
      }
    });
////////////////////////////////////////////////
    showDialogs(context, 3, 'Chargement...');
  }

  @override
  Widget build(BuildContext context) {
    print('long; ' + pluscommandes.length.toString());
    // List<int> list = [9, 8, 1];
    // list.sort((a, b) {
    //   return a.compareTo(b);
    // });
    return Scaffold(
        backgroundColor: Color(0xFFf6f5ee),

        // backgroundColor:
        //     dark == false || dark == null ? Colors.transparent : Darkcolor,
        drawer: Mydrawer(),
        body: SingleChildScrollView(
            child: Column(
          children: [
            SizedBox(
              height: 10,
            ),
            allarticles.length != 0
                ? _buildoption('Tous les articles', allarticles)
                : Container(),
            SizedBox(
              height: 10,
            ),
            newarticles.length != 0
                ? _buildoption('Nouveautés', newarticles)
                : Container(),
            //////////////////////////////////////////
            pluscommandes.length != 0
                ? _buildoption(
                    'Les plus commandés',
                    pluscommandes
                      ..sort((a, b) {
                        return b['vue'].compareTo(a['vue']);
                      }))
                : Container(),
            ////////////////////////////////////////////////:::::///////////////////////////////

            promotionels.length != 0
                ? _buildoption('En promotion', promotionels)
                : Container(),
            /////////////////////////////////////////////////////////////////////

            articlemoincher.length != 0
                ? _buildoption('Bonnes opportunités', articlemoincher)
                : Container(),
            ////////////////////////////////////////////////////////////////////////
          ],
        )));
  }

  _buildtitle(title, functionvoirplus, List list) {
    // list.reversed;
    // list.shuffle();
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: Text(
            title,
            style: TextStyle(
              letterSpacing: 1,
              color: Colors.blueGrey,
              fontSize: 15,
              // fontWeight: FontWeight.w700,
            ),
          ),
        ),
        InkWell(
          onTap: functionvoirplus,
          child: IconButton(
              onPressed: () {
                push(context, Seemore(list: list));
              },
              icon: Icon(Icons.arrow_forward)),
        ),
      ],
    );
  }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  _buildoption(catTitle, List listofarticles) {
    return Column(
      children: [
        _buildtitle(catTitle, () {}, listofarticles),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Row(
                children: [
                  for (final article in listofarticles.reversed)
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TwoSeparatedUI(map: article),
                    )
                ],
              ),
              Container(),
              Container(),
              Container(),
              Container(),
            ],
          ),
        ),
      ],
    );
  }
}
