import 'package:flutter/material.dart';
import 'dart:math';
import 'package:vector_math/vector_math.dart' show radians;
import 'package:get/get.dart';
// import 'package:vistalapp/ListCommadeETcourse/CourseEtdier.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/Dashboard/Portefeuil_Promotion.dart';
import 'CallerDash.dart';
import 'Etab/Mainpagevendors.dart';
import 'You_searchepalce/lib/screens/CourseEtdiversMap.dart';

class CategoryMenu extends StatefulWidget {
  // final String address;
  // const CategoryMenu({Key key, this.address}) : super(key: key);
  @override
  _CategoryMenuState createState() => _CategoryMenuState();
}

class _CategoryMenuState extends State<CategoryMenu>
    with SingleTickerProviderStateMixin {
  AnimationController? controller;
  bool menuornewprod = false;
/////////////////////////////////////////////////////
  List<String> articlesouve = [];
  List<String> restaurantsss = [];
  List<String> supermarketss = [];
  List<String> boutiquesss = [];
  List<String> soinetbeautes = [];
/////////////////////////////////////////////////////////
  @override
  void initState() {
    super.initState();
    controller =
        AnimationController(duration: Duration(milliseconds: 900), vsync: this);
    // ..addListener(() => setState(() {}));
    //////////////////////////////////////////////////////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      if (event.snapshot.value['catEtab'] == 'Bijouterie, articles souvenirs') {
        setState(() {
          articlesouve.add(event.snapshot.key!);
        });
      }
      if (event.snapshot.value['catEtab'] == 'Restaurant') {
        setState(() {
          restaurantsss.add(event.snapshot.key!);
        });
      }
      if (event.snapshot.value['catEtab'] == 'Boutique') {
        setState(() {
          boutiquesss.add(event.snapshot.key!);
        });
      }
      if (event.snapshot.value['catEtab'] == 'Supermarché') {
        setState(() {
          supermarketss.add(event.snapshot.key!);
        });
      }
      if (event.snapshot.value['catEtab'] == 'Soins et beauté') {
        setState(() {
          soinetbeautes.add(event.snapshot.key!);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return RadialAnimation(
      controller: controller,
      // address: widget.address,
      address: 'adresse',
      articlesouve: articlesouve,
      boutiquesss: boutiquesss,
      restaurantsss: restaurantsss,
      soinetbeautes: soinetbeautes,
      supermarketss: supermarketss,
    );
  }
}

String category = '';

class RadialAnimation extends StatelessWidget {
  List<String>? articlesouve;
  List<String>? restaurantsss;
  List<String>? supermarketss;
  List<String>? boutiquesss;
  List<String>? soinetbeautes;

  final String? address; //
  RadialAnimation({
    Key? key,
    this.controller,
    this.address,
    @required this.articlesouve,
    @required this.restaurantsss,
    @required this.supermarketss,
    @required this.boutiquesss,
    @required this.soinetbeautes,
  })  : translation = Tween<double>(
          begin: 0.0,
          end: 100.0,
        ).animate(
          CurvedAnimation(parent: controller!, curve: Curves.elasticOut),
        ),
        scale = Tween<double>(
          begin: 1.5,
          end: 0.0,
        ).animate(
          CurvedAnimation(parent: controller, curve: Curves.fastOutSlowIn),
        ),
        rotation = Tween<double>(
          begin: 0.0,
          end: 360.0,
        ).animate(
          CurvedAnimation(
            parent: controller,
            curve: Interval(
              0.0,
              0.7,
              curve: Curves.decelerate,
            ),
          ),
        ),
        super(key: key);

  final AnimationController? controller;
  final Animation<double>? rotation;
  final Animation<double>? translation;
  final Animation<double>? scale;

  @override
  Widget build(BuildContext context) {
    _open();
    return AnimatedBuilder(
        animation: controller!,
        builder: (context, widget) {
          return Transform.rotate(
              angle: radians(rotation!.value),
              child: Stack(alignment: Alignment.center, children: <Widget>[
                _buildButton(() {
                  push(
                      context,
                      Mainpagevendor(
                          list: supermarketss, label: 'Super marché'));
                }, 300, address!,
                    color: Colors.grey,
                    icon: Image.asset("assets/menu/ssupermarketMain.png",
                        height: 50, width: 50),
                    text: ('Super marché').toString()),
                _buildButton(() {
                  push(context,
                      Mainpagevendor(list: restaurantsss, label: 'Restaurant'));
                }, 240, address!,
                    color: Colors.grey,
                    icon: Image.asset("assets/menu/burger.png",
                        height: 50, width: 50),
                    text: ('Restaurant').toString()),
                _buildButton(() {
                  push(context, Couseetdiver());
                }, 60, address!,
                    color: Colors.grey,
                    icon: Image.asset("assets/menu/run-bell.png",
                        height: 50, width: 50),
                    text: ('Courses diverses').toString()),
                _buildButton(() {
                  push(context,
                      Mainpagevendor(list: boutiquesss, label: 'Boutique'));
                }, 0, address!,
                    color: Colors.grey,
                    icon: Image.asset("assets/menu/stores.png",
                        height: 50, width: 50),
                    text: ('Boutique').toString()),
                _buildButton(() {
                  push(
                      context,
                      Mainpagevendor(
                          list: articlesouve, label: 'Articles souvenirs'));
                }, 180, address!,
                    color: Colors.grey,
                    icon: Image.asset("assets/menu/technology.png",
                        height: 50, width: 50),
                    text: ('Articles souvenirs').toString()),
                _buildButton(() {
                  push(
                      context,
                      Mainpagevendor(
                          list: soinetbeautes, label: 'Soins et beauté'));
                }, 120, address!,
                    color: Colors.grey,
                    icon: Image.asset(
                      "assets/menu/soin.png",
                      height: 50,
                      width: 50,
                    ),
                    text: ('Soins et beauté').toString()),
                //////////////////////////////////////////////
                Transform.scale(
                  scale: scale!.value - 1,
                  child: FloatingActionButton(
                      heroTag: null,
                      child: Icon(
                        Icons.attach_money_outlined,
                        color: Colors.white,
                      ),
                      onPressed: () {
                        Future.delayed(Duration(milliseconds: 100), () {
                          // execute this action after 100 time when the user click
                          Get.to(Homepage(
                            index: 2,
                            page: 'Not null',
                            toseecat: 'oui',
                          ));
                        });
                      },
                      // onPressed: _close,
                      backgroundColor: Colors.red),
                ),
                // HERE WE CAN ADD A WIDGET TO DESPLAY WHEN THE CIRCLE IS CLOLSED Transform.scale( if the circular is closed, we despaly this widget
              ]));
        });
  }

  _open() {
    controller!.forward();
  }

  _close() {
    controller!.reverse();
  }

  _buildButton(function, double angle, String address,
      {Color? color, Image? icon, String? text}) {
    final double rad = radians(angle);
    return Transform(
        transform: Matrix4.identity()
          ..translate(
              (translation!.value) * cos(rad), (translation!.value) * sin(rad)),
        child: InkWell(
          onTap: function,
          child: Container(
              height: 95,
              width: 200,
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey, width: 1.0),
                  color: Colors.white10,
                  shape: BoxShape.circle,
                ),
                child: Column(
                  children: [
                    SizedBox(height: 5),
                    icon!,
                    SizedBox(height: 3),
                    Container(
                        width: 60,
                        child: Text(
                          text!,
                          style: TextStyle(
                              fontSize: 10,
                              color: dark == false || dark == null
                                  ? Darkcolor
                                  : litetextcolors),
                          overflow: TextOverflow.fade,
                          textAlign: TextAlign.center,
                        ))
                  ],
                ),
              )),
        ));
  }
}
