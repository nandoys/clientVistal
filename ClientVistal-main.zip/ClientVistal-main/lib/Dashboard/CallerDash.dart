import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:vistalapp/Dashboard/actualites_articles.dart';
import 'package:vistalapp/Dashboard/Homes.dart';
import 'package:vistalapp/Dashboard/Market.dart';
import 'package:vistalapp/Dashboard/Favorit.dart';
import 'package:vistalapp/Dashboard/Mydrawer.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:vistalapp/Dashboard/map.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';
import 'package:vistalapp/validation_payementNotification/Notification.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';

class Homepage extends StatefulWidget {
  final page;
  final index;
  final toseecat;
  Homepage(
      {@required this.index, @required this.page, @required this.toseecat});
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  int _currentindex = 0;
  GlobalKey _bottomnavigationkey = GlobalKey();
  PageController _pageController = PageController();
  int _selectedIndex = 2;
  final GlobalKey<ScaffoldState> scaffoldkey = new GlobalKey();
  List<Map> panier = [];
  // Map nombrePAnier = {};
  List<Event> notification = [];
  ////////////////////////////////////////////////////////////////////////////////////////////////

  DateTime backbuttonpressedTime = eve;
  Future<bool> onWillPop() async {
    DateTime currentTime = DateTime.now();
    //Statement 1 Or statement2
    bool backButton = backbuttonpressedTime == eve ||
        currentTime.difference(backbuttonpressedTime) > Duration(seconds: 1);
    if (backButton) {
      backbuttonpressedTime = currentTime;
      Fluttertoast.showToast(
          msg: "Taper à nouveau pour quitter",
          backgroundColor: Colors.black,
          textColor: Colors.white);

      return false;
    }

    SystemChannels.platform.invokeMethod('SystemNavigator.pop');

    return true;
  }

//////////////////////////////////////////////////////// willpop pro
////////////////////////////////////////////////////////////////////////////////////////////////////
  String title = 'Vistal';
  void appbartext(int index) {
    setState(() {
      _selectedIndex = index;
      if (_selectedIndex == 2) {
        title = 'Vistal';
      }
      if (_selectedIndex == 0) {
        title = 'Stat';
      }
      if (_selectedIndex == 1) {
        title = 'Près de vous';
        Fluttertoast.showToast(
            gravity: ToastGravity.CENTER,
            msg: 'Patientez pendant que la carte se charge',
            backgroundColor: Colors.red,
            textColor: Colors.white);
      }
      if (_selectedIndex == 3) {
        title = 'Mon panier'.toString();
      }
      if (_selectedIndex == 4) {
        title = 'Favoris';
      }
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (nomuser.isNotEmpty) {
      Vistal_SIMPLEUSER.child(phoneuser).update({
        'nom': nomuser,
        'prenom': prenomuser,
        'commingdate': DateTime.now().toString(),
        'lastconnexion': DateTime.now().toString(),
        'pointgagne': 0,
        'pointutilise': 0
      }).then((value) {
        nomuser = '';
        prenomuser = '';
        phoneuser = '';
      });
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////:::::///////////////////////////////////////////////////
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab'],
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_panier.onChildRemoved.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = panier.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'] &&
              element['idetab'] == event.snapshot.value['idetab'],
          orElse: () {
            return eve;
          },
        );
        setState(() {
          panier.remove(old);
        });
      }
    });
///////////////////////// notification //////////////////
    Vistal_notifications.onChildAdded.listen((event) {
      if (!event.snapshot.value['lu'].toString().contains(shareget('phone'))) {
        setState(() {
          notification.add(event);
        });
      }
    });

////////////////////////////////////////////////////////////////////////////////////
    _pageController = PageController(initialPage: widget.index);
    setState(() {
      _currentindex = widget.index;
    });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _pageController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: onWillPop,
      child: Scaffold(
        key: scaffoldkey,
        appBar: AppBar(
          elevation: 0,
          leading: IconButton(
            icon: Icon(drawericon),
            onPressed: () {
              scaffoldkey.currentState!.openDrawer();
            },
          ),
          title: Text(
            title,
            style: TextStyle(
                // letterSpacing: 2,
                ),
          ),
          centerTitle: false,
          backgroundColor: Colors.red,
          actions: [
            // IconButton(
            //   icon: Icon(Icons.run_circle),
            //   onPressed: () {},
            // ),
            ///////////////////////////////////////////////////////////////////////////////////////////////
            _selectedIndex != 1
                ? Row(
                    children: [
                      _selectedIndex != 1
                          ? Stack(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 5.0, left: 2, right: 4),
                                  child: IconButton(
                                      icon: Icon(Icons.notifications),
                                      onPressed: () {
                                        notification.forEach((element) {
                                          Vistal_notifications.child(
                                                  element.snapshot.key!)
                                              .update({
                                            'lu': (element.snapshot.value['lu']
                                                        .toString() +
                                                    shareget('phone')
                                                        .toString())
                                                .toString()
                                          });
                                        });
                                        push(context, Notifications());
                                      }),
                                ),
                                notification.length != 0
                                    ? Positioned(
                                        top: 5,
                                        left: 30,
                                        child: Container(
                                          alignment: Alignment.center,
                                          child: Text(
                                            '${notification.length}',
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                          height: 20,
                                          width: 20,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              color: Colors.black),
                                        ),
                                      )
                                    : Container()
                              ],
                            )
                          : Container(),
                      IconButton(
                          icon: Icon(Icons.inventory_outlined),
                          onPressed: () {
                            push(context, CallerCouserEtCommande());
                          }),
                    ],
                  )
                : IconButton(icon: Icon(Icons.location_on), onPressed: () {}),
            _selectedIndex != 1
                ? Stack(
                    children: [
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 5.0, left: 2, right: 4),
                        child: IconButton(
                            icon: Icon(Icons.local_grocery_store),
                            onPressed: panier.length != 0
                                ? () {
                                    setState(() {
                                      _currentindex = 3;
                                      appbartext(3);
                                    });
                                  }
                                : () {}),
                      ),
                      panier.length != 0
                          ? Positioned(
                              top: 5,
                              left: 30,
                              child: Container(
                                alignment: Alignment.center,
                                child: Text(
                                  '${panier.length}',
                                  style: TextStyle(color: Colors.white),
                                ),
                                height: 20,
                                width: 20,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.black),
                              ),
                            )
                          : Container()
                    ],
                  )
                : Container(),
          ],
        ),
        drawer: ClipRRect(
            borderRadius: BorderRadius.only(
                topRight: Radius.circular(35),
                bottomRight: Radius.circular(35)),
            child: Mydrawer()),
        bottomNavigationBar: CurvedNavigationBar(
          ///////////////////////////////////////////////////////////////////////////////
          height: 55,
          index: _currentindex,
          color: Colors.red,
          backgroundColor: dark == false || dark == null
              ? Colors.white
              : Colors.black.withOpacity(0.8),
          key: _bottomnavigationkey,
          items: [
            Icon(
              Icons.bar_chart_sharp,
              size: 20,
              color: Colors.white,
            ),
            Icon(
              Icons.location_on,
              size: 20,
              color: Colors.white,
            ),
            Icon(
              Icons.home,
              size: 20,
              color: Colors.white,
            ),
            Icon(
              Icons.local_grocery_store,
              size: 20,
              color: Colors.white,
            ),
            Icon(
              Icons.favorite_border_outlined,
              size: 20,
              color: Colors.white,
            )
          ],
          onTap: (index) {
            if (index == 2) {
              push(
                  context,
                  Homepage(
                    index: 2,
                    page: null,
                    toseecat: '',
                  ));
            }
            appbartext(index);
            setState(() {
              _currentindex = index;
              // _pageController.jumpToPage(index); if you want to jump by sliding
            });
          },
        ),
        body: SafeArea(
          child: _getpage(_currentindex),
        ),
        // body: SizedBox.expand(   if you want to jump by sliding
        //   child: PageView(
        //     allowImplicitScrolling: true,
        //     controller: _pageController,
        //     onPageChanged: (index) {
        //       setState(() {
        //         _currentindex = index;
        //         appbartext(index);
        //       });
        //     },
        //     children: [Messages(), Position(), Home(), Market(), Favorit()],
        //   ),
        // ),
      ),
    );
  }

  _getpage(index) {
    if (_currentindex == 0) {
      return Messages();
    }
    if (_currentindex == 1) {
      // return Position();
      return Maps();
    }
    if (_currentindex == 2) {
      return Home(
        page: widget.toseecat == 'oui' ? widget.page : null,
      );
    }
    if (_currentindex == 3) {
      return Market();
    }
    if (_currentindex == 4) {
      return Favorit();
    }
  }
}
