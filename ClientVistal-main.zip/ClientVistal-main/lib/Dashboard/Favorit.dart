import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Dashboard/Homes.dart';
import 'package:vistalapp/Dashboard/Mydrawer.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/ui_list_prod.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Searchsclasses/SearchAllProd.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:google_fonts/google_fonts.dart';

import 'articles/Poduct_ui/Two_of_staggered.dart';

class Favorit extends StatefulWidget {
  @override
  _FavoritState createState() => _FavoritState();
}

class _FavoritState extends State<Favorit> {
  List<Map> allpod = [];
  Map etabnme = {};
  Map urlpro = {};
  List<Map> allfav = [];
  var wait = '';
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    ////////////////////////// prod url //////////////////////////////////////
    ////////////////////////// prod url //////////////////////////////////////
    ////////////////////////// prod url //////////////////////////////////////
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      setState(() {
        if (!urlpro.containsKey((event.snapshot.value['idprod'] +
            event.snapshot.value['idetab']))) {
          urlpro[event.snapshot.value['idprod'] +
              event.snapshot.value['idetab']] = event.snapshot.value['url'];
        }
      });
    });
    ///////////////////////////////////////////////////////////////////////////////////////
    Vistal_Favorits_produits.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = allfav.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'] &&
              element['idetab'] == event.snapshot.value['idetab'],
          orElse: () {
            return eve;
          },
        );
        if (old == eve) {
          setState(() {
            setState(() {
              allfav.add({
                'idetab': event.snapshot.value['idetab'],
                'idprod': event.snapshot.value['idprod'],
                'phone': event.snapshot.value['phone'],
                'url': urlpro[event.snapshot.value['idprod'] +
                    event.snapshot.value['idetab']]
              });
            });
          });
        }
      }
    });
    Vistal_Favorits_produits.onChildRemoved.listen((event) {
      var old = allfav.firstWhere(
        (element) =>
            element['phone'] == event.snapshot.value['phone'] &&
            element['idprod'] == event.snapshot.value['idprod'] &&
            element['idetab'] == event.snapshot.value['idetab'] &&
            element['url'] == event.snapshot.value['url'],
        orElse: () {
          return eve;
        },
      );
      if (old != eve) {
        setState(() {
          allfav.remove(old);
        });
      }
    });
    ////////////////////////////////searchallprod/////////////////////////////////////////////////////////////////////
    ////////////////////////////////searchallprod/////////////////////////////////////////////////////////////////////
    ////////////////////////////////searchallprod/////////////////////////////////////////////////////////////////////
    ////////////////////////////////searchallprod/////////////////////////////////////////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      setState(() {
        allpod.add({
          'idprod': event.snapshot.value['nom'],
          'idcat': event.snapshot.value['idcat'],
          'idetab': event.snapshot.value['idetab'],
          'desc': event.snapshot.value['desc'],
          'prix': event.snapshot.value['prix'],
          'visible': event.snapshot.value['visible'],
        });
      });
    });

    ///////////////////////////////////////////// Etab name ///////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        etabnme[event.snapshot.key] = event.snapshot.value['etabname'];
      });
    });

    showDialogs(context, 4, 'Chargement');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xFFf6f5ee),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                InkWell(
                  onTap: () {
                    showSearch(
                        context: context,
                        delegate: DataserachALLProd(
                            list: allpod, etabname: etabnme, urlprod: urlpro));
                  },
                  child: Container(
                    alignment: Alignment.center,
                    child: Container(
                      height: 29,
                      width: getwidth(context) * 0.96,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.white),
                      child: Row(
                        children: [
                          SizedBox(
                            width: 10,
                          ),
                          Icon(
                            Icons.search,
                            color: Colors.red,
                          ),
                          Text(
                            'Rechercher un produit',
                            style: TextStyle(color: Colors.grey),
                          )
                        ],
                      ),
                    ),
                    height: 50,
                    width: getwidth(context),
                    decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [
                      Colors.red,
                      Colors.redAccent,
                      Colors.red
                    ])),
                  ),
                ),
                SizedBox(
                  height: 5,
                ),
                allfav.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.only(top: 278.0),
                        child: Center(
                          child: Text('Aucun favori'),
                        ),
                      )
                    : Padding(
                        padding: const EdgeInsets.only(bottom: 108.0),
                        child: SizedBox(
                            height: getheight(context) / 1.4,
                            width: getwidth(context),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: buildProducts(),
                            )),
                      ),
              ],
            ),
          ),
        ));
  }

  Widget buildProducts() {
    final double spacing = 12;
    return GridView(
      // padding: EdgeInsets.all(spacing),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: spacing,
        mainAxisSpacing: spacing,
        childAspectRatio: 3 / 4,
      ),
      children: [
        for (final prod in allfav)
          ProductsTwosepa(map: {
            'idprod': prod['idprod'],
            'idetab': prod['idetab'],
            'url': prod['url'],
          }, fromfav: true)
      ],
    );
  }
}
