import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vistalapp/Dashboard/Etab/EtabUI.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/detail_prod_ui.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';

import '../CallerDash.dart';

class Mainpagevendor extends StatefulWidget {
  final list;
  final label;
  Mainpagevendor({@required this.list, @required this.label});
  @override
  _MainpagevendorState createState() => _MainpagevendorState();
}

class _MainpagevendorState extends State<Mainpagevendor> {
  List<Map> panier = [];
  ////////////////////////////////////////////////
  Map profiletab = {};
  Map etabname = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_panier.onChildRemoved.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = panier.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'],
          orElse: () {
            return eve;
          },
        );
        setState(() {
          if (old != eve) {}
          panier.remove(old);
        });
      }
    });
    //////////////////////////////////////////////////////////////////////
    Vistal_vendeur_profil_photo.onChildAdded.listen((event) {
      setState(() {
        profiletab[event.snapshot.key] = event.snapshot.value['url'];
      });
    });
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        etabname[event.snapshot.key] = event.snapshot.value['etabname'];
      });
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Color(0xFFf6f5ee),
        appBar: AppBar(
          title: Text(
            widget.label,
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: false,
          backgroundColor: Colors.red,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              pop(context);
            },
          ),
          actions: [
            IconButton(
                icon: Icon(Icons.inventory_outlined),
                onPressed: () {
                  push(context, CallerCouserEtCommande());
                }),
            Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 5.0, left: 2, right: 4),
                  child: IconButton(
                      icon: Icon(Icons.local_grocery_store),
                      onPressed: () {
                        push(context,
                            Homepage(index: 3, page: 3, toseecat: null));
                      }),
                ),
                panier.length != 0
                    ? Positioned(
                        top: 5,
                        left: 30,
                        child: Container(
                          alignment: Alignment.center,
                          child: Text(
                            '${panier.length}',
                            style: TextStyle(color: Colors.white),
                          ),
                          height: 20,
                          width: 20,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.black),
                        ),
                      )
                    : Container()
              ],
            ),
          ],
        ),
        body: Container(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: buildProducts(),
          ),
        ),
      );

  Widget buildProducts() {
    final double spacing = 12;

    return GridView(
      // padding: EdgeInsets.all(spacing),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: spacing,
        mainAxisSpacing: spacing,
        childAspectRatio: 3 / 4,
      ),
      children: [
        for (final prod in widget.list)
          buildProduct(
              {'url': profiletab[prod], 'nom': etabname[prod], 'idetab': prod})
      ],
    );
  }

  Widget buildProduct(Map product) => InkWell(
        onTap: () {
          push(context, EtabUI(idetab: product['idetab']));
        },
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(Radius.circular(20)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Center(
                    child: Hero(
                        tag: product['url'].toString(),
                        child: Container(
                            height: 150,
                            width: 150,
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.white, width: 2),
                                borderRadius: BorderRadius.circular(10)),
                            child: product['url'] != null
                                ? ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: CachedNetworkImage(
                                      filterQuality: FilterQuality.medium,
                                      fit: BoxFit.fill,
                                      imageUrl: product['url'],
                                      placeholder:
                                          (BuildContext context, String url) {
                                        return Center(
                                          child: SkeletonContainer.rounded(
                                            height: 150,
                                            width: 150,
                                          ),
                                        );
                                      },
                                    ),
                                  )
                                : Container(
                                    alignment: Alignment.center,
                                    child: Icon(
                                      Icons.storefront_rounded,
                                      color: Colors.grey,
                                      size: 80,
                                    ),
                                  ))),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  ' ${product['nom']}',
                  style: TextStyle(
                      fontWeight: FontWeight.w500, color: Colors.blueGrey),
                ),
              ],
            ),
          ),
        ),
      );
}
