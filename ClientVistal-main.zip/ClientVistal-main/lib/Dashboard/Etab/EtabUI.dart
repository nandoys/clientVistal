import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/SeemoreProd.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/see.allartcleFromCat.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/two_separete.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Searchsclasses/searchProductInEtab.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';
import 'package:firebase_database/firebase_database.dart';

class EtabUI extends StatefulWidget {
  final String? idetab;
  EtabUI({@required this.idetab});

  @override
  _EtabUIState createState() => _EtabUIState();
}

class _EtabUIState extends State<EtabUI> {
  Map<String, String> urlprof = {};
  Map<String, String> urlcouve = {};
  List<Map> allprods = [];
  Map<String, String> urlprod = {};
  List<String> listimageetab = [];
  List<Map> searchproinetab = [];
  List<Map> panier = [];
  List<Event> allcatetab = [];
  Map vendeurs = {
    'nom': '',
    'mail': '',
    'phone': '',
    'adresse': '',
    'reference': '',
    'long': '',
    'lat': '',
    'apropo': '',
  };

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_vendeur_profil_photo.onChildAdded.listen((event) {
      setState(() {
        urlprof[event.snapshot.key.toString()] = event.snapshot.value['url'];
      });
    });
    Vistal_vendeur_couverture_photo.onChildAdded.listen((event) {
      setState(() {
        urlcouve[event.snapshot.key.toString()] = event.snapshot.value['url'];
      });
    });
    //////////////////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      if (event.snapshot.key == widget.idetab) {
        print('okokokooo');

        setState(() {
          vendeurs = {
            'nom': event.snapshot.value['etabname'],
            'mail': event.snapshot.value['mail'],
            'phone': event.snapshot.value['phone'],
            'adresse': event.snapshot.value['adresse'],
            'reference': event.snapshot.value['reference'],
            'long': event.snapshot.value['long'],
            'lat': event.snapshot.value['lat'],
            'descrip': event.snapshot.value['descrip'],
          };
        });
      }
    });
///////////////////// image prod //////////////////////////////
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      if (widget.idetab == event.snapshot.value['idetab']) {
        setState(() {
          if (!urlprod.containsKey(event.snapshot.value['idprod'])) {
            urlprod[event.snapshot.value['idprod']] =
                event.snapshot.value['url'];
          }
        });
      }
    });
    ///////////////////////// all prod
    Vistal_Produits.onChildAdded.listen((event) {
      if (widget.idetab == event.snapshot.value['idetab']) {
        setState(() {
          allprods.add({
            'idprod': event.snapshot.value['nom'],
            'idetab': event.snapshot.value['idetab'],
            'prix': event.snapshot.value['prix'],
            'url': urlprod[event.snapshot.value['nom']],
          });
        });
      }
    });

    //////////////////// image description etab
    Vistal_vendeur_EtabImageDascription_photo.onChildAdded.listen((event) {
      if (event.snapshot.value['username'] == widget.idetab) {
        setState(() {
          listimageetab.add(event.snapshot.value['url']);
        });
      }
    });

    ////////////////////////////////// all prod of etab ///////////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      if (widget.idetab == event.snapshot.value['idetab']) {
        print('info seen successfully');
        setState(() {
          searchproinetab.add({
            'nom': event.snapshot.value['nom'],
            'idcat': event.snapshot.value['idcat'],
            'idetab': event.snapshot.value['idetab'],
            'desc': event.snapshot.value['desc'],
            'prix': event.snapshot.value['prix'],
            'visible': event.snapshot.value['visible'],
            'url': event.snapshot.value['nom'],
          });
        });
      }
    });

////////////////////////////////////////////////////////////
/////////////////////////////////////////// // panier url prod
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      /////////////////////////////////////////// image of one prod ////////////
      setState(() {
        if (!urlprod.containsKey(event.snapshot.value['idprod'])) {
          urlprod[event.snapshot.value['idprod']] = event.snapshot.value['url'];
        }
      });
    });

    ////////////////////////////////////////////:panier::::///////////////////////////////////////////////////
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_panier.onChildRemoved.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = panier.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'],
          orElse: () {
            return eve;
          },
        );
        setState(() {
          if (old != eve) {}
          panier.remove(old);
        });
      }
    });
    //////////////////////////////////////////// end commande ///////////////////////////////////
    Vistal_Categorieprod.onChildAdded.listen((event) {
      setState(() {
        if (event.snapshot.value['idetab'] == widget.idetab) {
          allcatetab.add(event);
        }
      });
    });
    //////////////////////////////////////////// end commande ///////////////////////////////////
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // centerTitle: true,
        actions: [
          IconButton(
              icon: Icon(Icons.inventory_outlined),
              onPressed: () {
                push(context, CallerCouserEtCommande());
              }),
          Stack(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 5.0, left: 2, right: 4),
                child: IconButton(
                    icon: Icon(Icons.local_grocery_store),
                    onPressed: () {
                      push(
                          context, Homepage(index: 3, page: 3, toseecat: null));
                    }),
              ),
              panier.length != 0
                  ? Positioned(
                      top: 5,
                      left: 30,
                      child: Container(
                        alignment: Alignment.center,
                        child: Text(
                          '${panier.length.toString()}',
                          style: TextStyle(color: Colors.white),
                        ),
                        height: 20,
                        width: 20,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.black),
                      ),
                    )
                  : Container()
            ],
          ),
        ],
        backgroundColor: Colors.red,
        title: Row(
          children: [
            Container(
              height: 30,
              width: 30,
              decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10))),
              child: ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(40)),
                child: urlprof[widget.idetab] != null
                    ? Hero(
                        tag: urlprof[widget.idetab].toString(),
                        child: CachedNetworkImage(
                          filterQuality: FilterQuality.medium,
                          fit: BoxFit.fill,
                          imageUrl: urlprof[widget.idetab].toString(),
                          placeholder: (BuildContext context, String url) {
                            return Center(
                              child: SkeletonContainer.rounded(
                                height: 30,
                                width: 30,
                              ),
                            );
                          },
                        ),
                      )
                    : Container(),
              ),
            ),
            SizedBox(
              width: 1,
            ),
            Padding(
              padding: const EdgeInsets.all(4.0),
              child: Text(
                vendeurs['nom'].toString().toUpperCase(),
                style: TextStyle(fontSize: 12),
              ),
            )
          ],
        ),
        elevation: 0,
      ),
      ///////////////////////////////////////////////////////////////////////////////////////////
      body: SingleChildScrollView(
        child: Column(
          children: [
            GestureDetector(
              onTap: () {
                showSearch(
                    context: context,
                    delegate: DataSearchProdinEtab(
                        list: searchproinetab, urlprod: urlprod));
              },
              child: Container(
                alignment: Alignment.center,
                child: Container(
                  height: 29,
                  width: getwidth(context) * 0.96,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 10,
                      ),
                      Icon(
                        Icons.search,
                        color: Colors.red,
                      ),
                      Text(
                        'Rechercher un produit dans ${vendeurs['nom'].toString()}',
                        style: TextStyle(color: Colors.grey),
                      )
                    ],
                  ),
                ),
                height: 50,
                width: getwidth(context),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        colors: [Colors.red, Colors.redAccent, Colors.red])),
              ),
            ),
            /////////////////////////
            Stack(
              overflow: Overflow.visible,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                      top: 5, right: 2, left: 4, bottom: 8),
                  child: Container(
                    height: 200,
                    width: getwidth(context),
                    decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10))),
                    child: ClipRRect(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20)),
                      child: urlcouve[widget.idetab] != null
                          ? CachedNetworkImage(
                              filterQuality: FilterQuality.medium,
                              fit: BoxFit.fill,
                              imageUrl: urlcouve[widget.idetab]!,
                              placeholder: (BuildContext context, String url) {
                                return Center(
                                  child: SkeletonContainer.rounded(
                                    height: getheight(context) * 0.3,
                                    width: double.infinity,
                                  ),
                                );
                              },
                            )
                          : Container(
                              height: 200,
                              width: getwidth(context),
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image: AssetImage('assets/slides/4.jpg'),
                                      fit: BoxFit.fill)),
                            ),
                    ),
                  ),
                ),
                //////////////////////////////////:
                Container(
                  child: Stack(
                    overflow: Overflow.visible,
                    children: [
                      Positioned(
                        top: getheight(context) / 5.5,
                        left: getwidth(context) / 3.0,
                        child: Stack(
                          overflow: Overflow.visible,
                          children: [
                            urlprof[widget.idetab].toString().isNotEmpty
                                ? Container(
                                    height: 120,
                                    width: 120,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(100),
                                      child: urlprof[widget.idetab] != null
                                          ? CachedNetworkImage(
                                              filterQuality:
                                                  FilterQuality.medium,
                                              fit: BoxFit.fill,
                                              imageUrl: urlprof[widget.idetab]!,
                                              placeholder:
                                                  (BuildContext context,
                                                      String url) {
                                                return Center(
                                                  child:
                                                      SkeletonContainer.rounded(
                                                    height: 120,
                                                    width: 120,
                                                  ),
                                                );
                                              },
                                            )
                                          : Container(
                                              height: 200,
                                              alignment: Alignment.center,
                                              child: Icon(
                                                Icons.storefront_rounded,
                                                color: Colors.white,
                                                size: 50,
                                              ),
                                              width: getwidth(context),
                                              decoration: BoxDecoration(
                                                  color: Colors.grey),
                                            ),
                                    ),
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.white, width: 1),
                                      borderRadius: BorderRadius.circular(60),
                                    ),
                                  )
                                : Container(
                                    height: 100,
                                    width: 100,
                                    child: Icon(
                                      Icons.storefront,
                                      color: Colors.red.shade300,
                                      size: 70,
                                    ),
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.black, width: 1),
                                      borderRadius: BorderRadius.circular(60),
                                    ),
                                  ),
                            Positioned(
                                top: 90,
                                left: 70,
                                child: Container(
                                  alignment: Alignment.center,
                                  height: 39,
                                  width: 39,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(
                                          color: Colors.red.shade300,
                                          width: 1)),
                                  child: IconButton(
                                      icon: Icon(
                                        Icons.storefront_outlined,
                                        color: Colors.red,
                                      ),
                                      onPressed: () async {}),
                                ))
                          ],
                        ),
                      ),
                      ///////////////////////////////////////////////////////:::
                    ],
                  ),
                  height: 170,
                  width: getwidth(context),
                ),
              ],
            ),
            SizedBox(
              height: 70,
            ),
            Text(
              vendeurs['nom'].toString().toUpperCase(),
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 20),
            ),
            Card(
              elevation: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                      icon: Icon(Icons.phone),
                      color: Colors.green,
                      onPressed: () {
                        launchURL('tel:$phoneto');
                      }),
                  IconButton(
                      icon: Icon(Icons.mail),
                      color: Colors.red,
                      onPressed: () {
                        launchURL(mailto);
                      }),
                ],
              ),
            ),
            Card(
              elevation: 0,
              child: ListTile(
                leading: IconButton(
                    icon: Icon(
                      Icons.location_on,
                      size: 20,
                    ),
                    color: Colors.red,
                    onPressed: () {}),
                title: Text(
                  vendeurs['adresse'].toString(),
                  style: TextStyle(fontSize: 8, fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  'Réf: ' + vendeurs['reference'].toString(),
                  style: TextStyle(fontSize: 10),
                ),
                trailing: Icon(
                  Icons.storefront_rounded,
                  size: 20,
                  color: Colors.red,
                ),
              ),
            ),
            listimageetab.isNotEmpty
                ? Padding(
                    padding: const EdgeInsets.only(top: 5, bottom: 1),
                    child: SizedBox(
                      height: getheight(context) * 0.35,
                      width: double.infinity,
                      child: Carousel(
                        dotIncreasedColor: Colors.pink,
                        autoplay: true,
                        autoplayDuration: Duration(seconds: 4),
                        dotSize: 7.0,
                        dotSpacing: 15.0,
                        indicatorBgPadding:
                            4.0, // la bar grise ou se placent les indicateurs
                        dotBgColor: Colors.transparent,
                        dotColor: Colors.black,
                        animationCurve: Curves.easeInQuad,
                        boxFit: BoxFit.fill,
                        // overlayShadowColors: Colors.red,
                        //color of the bar where are positioned indicators
                        dotVerticalPadding: 5.0,
                        dotPosition: DotPosition.bottomCenter,
                        images: [
                          for (final imge in listimageetab)
                            Padding(
                              padding: const EdgeInsets.all(2),
                              child: Container(
                                height: 100,
                                width: 100,
                                decoration: BoxDecoration(
                                    color: Colors.transparent,
                                    borderRadius: BorderRadius.circular(2)),
                                child: CachedNetworkImage(
                                  filterQuality: FilterQuality.medium,
                                  fit: BoxFit.fill,
                                  imageUrl: imge,
                                  placeholder:
                                      (BuildContext context, String url) {
                                    return Center(
                                      child: SkeletonContainer.rounded(
                                        height: getheight(context) * 0.3,
                                        width: double.infinity,
                                      ),
                                    );
                                  },
                                ),
                              ),
                            )
                        ],
                      ),
                    ),
                  )
                : Container(),

            ////////////////////////////////////////

            Card(
              child: ListTile(
                title: Text(
                  'A propos',
                  style: TextStyle(
                    // fontWeight: FontWeight.w700,
                    fontSize: 20,
                    color: Colors.blueGrey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(vendeurs['descrip'].toString(),
                    style: TextStyle(
                      fontSize: 15,
                    )),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 4.0),
                  child: Text(
                    'Catégories des articles',
                    style: TextStyle(
                        color: Colors.blueGrey,
                        fontWeight: FontWeight.w600,
                        fontSize: 17),
                  ),
                ),
                Container(),
                Container(),
                Container(),
                Container(),
                Container(),
                Container(),

                // Container(),
                // Container(),
                // Container(),
                // allprods.length != 0
                //     ? IconButton(
                //         onPressed: () {
                //           push(context, Seemore(list: allprods));
                //         },
                //         icon: Icon(Icons.arrow_forward))
                //     : Container()
              ],
            ),
            ///////////////////////////////////////
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    for (final cat in allcatetab)
                      InkWell(
                        onTap: () {
                          push(
                              context,
                              ProdfromCateg(
                                idetab: cat.snapshot.value['idetab'],
                                nomcat: cat.snapshot.value['nomcat'],
                              ));
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            children: [
                              Container(
                                height: 150,
                                width: 150,
                                decoration: BoxDecoration(
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(5)),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: ClipRRect(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(5)),
                                    child: Opacity(
                                      opacity: 0.85,
                                      child: cat.snapshot.value['url'] != null
                                          ? Hero(
                                              tag: cat.snapshot.value['url'],
                                              child: CachedNetworkImage(
                                                filterQuality:
                                                    FilterQuality.medium,
                                                fit: BoxFit.fill,
                                                imageUrl:
                                                    cat.snapshot.value['url'],
                                                placeholder:
                                                    (BuildContext context,
                                                        String url) {
                                                  return Center(
                                                    child: SkeletonContainer
                                                        .rounded(
                                                      height: 150,
                                                      width: 150,
                                                    ),
                                                  );
                                                },
                                              ),
                                            )
                                          : SkeletonContainer.rounded(
                                              height: 150,
                                              width: 150,
                                            ),
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                '${cat.snapshot.value['nomcat']}',
                                style: TextStyle(
                                  fontSize: 15,
                                ),
                              )
                            ],
                          ),
                        ),
                      )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
