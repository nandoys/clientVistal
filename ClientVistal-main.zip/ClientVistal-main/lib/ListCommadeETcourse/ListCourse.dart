import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';

class Course extends StatefulWidget {
  const Course({Key? key}) : super(key: key);

  @override
  _CourseState createState() => _CourseState();
}

class _CourseState extends State<Course> {
  List<Event> courses = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_Couse.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          courses.add(event);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            for (final course in courses.reversed)
              Card(
                child: ListTile(
                  leading: Container(
                    alignment: Alignment.center,
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.grey),
                    child: Text(
                      '${course.snapshot.value['infos']['prix'].toString()}\$',
                      style: TextStyle(color: Colors.white, fontSize: 13),
                    ),
                  ),
                  trailing: Text(
                    '${course.snapshot.value['statut']}',
                    style: TextStyle(color: Colors.red, fontSize: 13),
                  ),
                  title: Text(
                      'Nature de l\'objet: ${course.snapshot.value['nature']}'),
                  subtitle: Text(
                      '${course.snapshot.value['accuse']}\nDate: ${course.snapshot.value['date'].toString().substring(0, 16)}'),
                ),
              )
          ],
        ),
      ),
    );
  }
}
