import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/ListCommadeETcourse/ListCourse.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';

class Choice {
  final String? title;
  // final IconData iconData;
  const Choice({
    this.title,
  });
}

const List<Choice> choices = <Choice>[
  Choice(
    title: 'MES COMMANDES',
  ),
  Choice(
    title: 'MES COURSES',
  ),
];

class CallerCouserEtCommande extends StatefulWidget {
  @override
  _CallerCouserEtCommandeState createState() => _CallerCouserEtCommandeState();
}

class _CallerCouserEtCommandeState extends State<CallerCouserEtCommande> {
  List<Map> panier = [];

  Map? requeried;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
  }

  var eve;
  Future<bool> _gotoHom() {
    push(context, Homepage(index: 2, page: 2, toseecat: null));
    return eve;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _gotoHom,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: DefaultTabController(
          length: choices.length,
          child: Scaffold(
            appBar: AppBar(
              // centerTitle: true,
              elevation: 0,
              actions: [
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Stack(
                    children: [
                      Stack(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 5.0, left: 2, right: 4),
                            child: IconButton(
                                icon: Icon(Icons.local_grocery_store),
                                onPressed: panier.length != 0
                                    ? () {
                                        push(
                                            context,
                                            Homepage(
                                                index: 3,
                                                page: 3,
                                                toseecat: null));
                                      }
                                    : () {}),
                          ),
                          panier.length != 0
                              ? Positioned(
                                  top: 5,
                                  left: 30,
                                  child: Container(
                                    alignment: Alignment.center,
                                    child: Text(
                                      '${panier.length}',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                    height: 20,
                                    width: 20,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: Colors.black),
                                  ),
                                )
                              : Container()
                        ],
                      )
                    ],
                  ),
                ),
              ],
              // leading: IconButton(
              //     icon: Icon(Icons.arrow_back_ios),
              //     onPressed: () => Navigator.pop(context)),
              title: Text(
                'Commandes et courses',
                style: TextStyle(
                  fontSize: 15,
                ),
              ),
              backgroundColor: Colors.red,
              flexibleSpace: Container(
                alignment: Alignment.center,
                // child: Text(
                //     'Près de  250 000 livres numériques de plusieurs domaines à votre disposition. Remportez le prix du meilleur lecteur en lisans plus des livres.',
                //     style: TextStyle(fontSize: 15, color: Colors.white)),
              ),
              bottom: TabBar(
                indicatorColor: Colors.white,
                isScrollable: true,
                tabs: choices.map<Widget>((Choice choice) {
                  //
                  return Tab(
                    text: choice.title,
                    // icon: Icon(
                    //   choice.iconData,
                    //   color: Colors.white38.withOpacity(0.7),
                    // ),
                  );
                }).toList(),
              ),
            ),
            body: TabBarView(
                children: choices.map((Choice choice) {
              return Padding(
                padding: EdgeInsets.all(0),
                child: page(choice.title.toString()),
              );
            }).toList()),
          ),
        ),
      ),
    );
  }

  page(String title) {
    if (title == 'MES COMMANDES') {
      return Listcommandes();
    } else
    // (title == 'GESTION DES VENTES')
    {
      return Course();
    }
  }
}
