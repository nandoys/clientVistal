import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Facture_pdf/api/pdf_api.dart';
import 'package:vistalapp/Facture_pdf/api/pdf_invoice_api.dart';
import 'package:vistalapp/Facture_pdf/model/customer.dart';
import 'package:vistalapp/Facture_pdf/model/invoice.dart';
import 'package:vistalapp/Facture_pdf/model/supplier.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:vistalapp/validation_payementNotification/DetailCommande.dart';

class Listcommandes extends StatefulWidget {
  @override
  _ListcommandesState createState() => _ListcommandesState();
}

class _ListcommandesState extends State<Listcommandes> {
  List<Map> panier = [];
  List<Map> allpod = [];
  Map etabnme = {};
  Map urletab = {};
  List<Event> mycommds = [];
  Map cutomerinfo = {};
  Map prodprice = {};
///////////////////////////////////////////////////////////////////////////////////////////////////
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    ///////////////////////////
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////// end commande ///////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      setState(() {
        prodprice[event.snapshot.key] = event.snapshot.value['prix'];
      });
    });

    ///////////////////////////////////////////// Etab name ///////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        etabnme[event.snapshot.key] = event.snapshot.value['etabname'];
      });
    });
    ////////////////////////// etab url //////////////////////////////////////
    Vistal_vendeur_profil_photo.onChildAdded.listen((event) {
      setState(() {
        urletab['${event.snapshot.key.toString()}'] =
            event.snapshot.value['url'];
      });
    });
    //////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_Commandes.onChildAdded.listen((event) {
      if (event.snapshot.value['userphone'] == shareget('phone')) {
        setState(() {
          mycommds.add(event);
        });
      }
    });
    Vistal_Commandes.onChildChanged.listen((event) {
      if (event.snapshot.value['userphone'] == shareget('phone')) {
        setState(() {
          var old = mycommds.firstWhere(
            (element) => element.snapshot.key == event.snapshot.key,
            orElse: () {
              return eve;
            },
          );
          mycommds.add(event);
          mycommds.remove(old);
        });
        print(event.snapshot.value['statut']);
      }
    });

    ///////////////////////////////////////////////////////////
    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      if (shareget('phone') == event.snapshot.key) {
        setState(() {
          cutomerinfo['prenom'] = event.snapshot.value['prenom'];
          cutomerinfo['nom'] = event.snapshot.value['nom'];
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          for (final commande in mycommds.reversed)
            Card(
              child: ListTile(
                onTap: () {
                  push(
                      context,
                      DetailCommande(
                          list: commande.snapshot.value['listprods']));
                },
                leading: urletab[commande.snapshot.value['idetab']] != null
                    ? Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: CachedNetworkImage(
                            filterQuality: FilterQuality.medium,
                            fit: BoxFit.fill,
                            imageUrl:
                                urletab[commande.snapshot.value['idetab']],
                            placeholder: (BuildContext context, String url) {
                              return Center(
                                child: SkeletonContainer.rounded(
                                  height: 40,
                                  width: 40,
                                ),
                              );
                            },
                          ),
                        ),
                      )
                    : SkeletonContainer.rounded(
                        height: 30,
                        width: 30,
                      ),
                title: Text(
                  'Commande de ' +
                      getitemnumer(commande.snapshot.value['listprods']) +
                      ' article(s)',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                ),
                subtitle: Row(
                  children: [
                    Column(
                      children: [
                        Text(
                            'Chez:  ' +
                                etabnme[commande.snapshot.value['idetab']]
                                    .toString(),
                            style: TextStyle(fontSize: 10)),
                        Text(
                          'Code: ' +
                              commande.snapshot.value['CodeClient'].toString(),
                          style: TextStyle(fontSize: 10),
                        ),
                        Text(
                          'Montant: ' +
                              sumoflist(commande.snapshot.value['listprods'])
                                  .toString() +
                              '\$',
                          style: TextStyle(fontSize: 10),
                        ),
                        Text(
                          'Date: ' +
                              commande.snapshot.value['date']
                                  .toString()
                                  .substring(0, 16),
                          style: TextStyle(fontSize: 10),
                        ),
                      ],
                    ),
                    Container(),
                    Container(),
                    Container(),
                    Container(),
                  ],
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                ),
                trailing: commande.snapshot.value['payement'] == 'CASH' &&
                        commande.snapshot.value['statut'] == 'Traitement...'
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text(
                            commande.snapshot.value['statut'],
                            style: TextStyle(fontSize: 10, color: Colors.red),
                          ),
                          SizedBox(
                            height: 7.0,
                            width: 7.0,
                            child: CircularProgressIndicator(
                              valueColor:
                                  AlwaysStoppedAnimation<Color>(Colors.red),
                            ),
                          )
                        ],
                      )
                    ///////////////////////////////////////::: cash et non payé
                    : commande.snapshot.value['statut'] != 'Livré'
                        ? Column(
                            children: [
                              Text(
                                commande.snapshot.value['statut'],
                                style:
                                    TextStyle(fontSize: 10, color: Colors.red),
                              ),
                              IconButton(
                                  onPressed: () async {
                                    final date = DateTime.now();
                                    final dueDate = date.add(Duration(days: 7));

                                    final invoice = Invoice(
                                      livraison:
                                          commande.snapshot.value['livraison'],
                                      supplier: Supplier(
                                        name: 'Vistal',
                                        address:
                                            'www.vistal.cd\n+243 842642039',
                                        paymentInfo:
                                            commande.snapshot.value['payement'],
                                      ),
                                      customer: Customer(
                                        name: cutomerinfo['prenom'].toString() +
                                            ' ' +
                                            cutomerinfo['nom'].toString(),
                                        address: commande
                                                .snapshot.value['commune']
                                                .toString() +
                                            ' ' +
                                            commande.snapshot.value['quartier']
                                                .toString() +
                                            ' ' +
                                            commande.snapshot.value['avenue']
                                                .toString() +
                                            ' ' +
                                            ', N° ${commande.snapshot.value['numeroavenue'].toString()}',
                                      ),
                                      info: InvoiceInfo(
                                        date: date,
                                        moyenpaye:
                                            commande.snapshot.value['payement'],
                                        description: 'Etablissement:' +
                                            etabnme[commande
                                                .snapshot.value['idetab']],
                                        number:
                                            '${DateTime.now().year}-${commande.snapshot.value['CodeClient']}',
                                      ),
                                      items: [
                                        for (final prod in commande
                                            .snapshot.value['listprods'])
                                          InvoiceItem(
                                            description: prod['idprod'],
                                            quantity: int.parse(prod['qt']),
                                            unitPrice:
                                                double.parse(prod['prix']),
                                          ),
                                        ///////////////////////////////////////on peut en ajouter autant que possible ici
                                      ],
                                    );

                                    final pdfFile =
                                        await PdfInvoiceApi.generate(invoice);
                                    await PdfApi.openFile(pdfFile);
                                  },
                                  icon: Icon(Icons.download)),
                            ],
                          )
                        ///////////////////////// fin cash/////////////////////////////////////////////////////////////////
                        : commande.snapshot.value['payement'] != 'CASH' &&
                                commande.snapshot.value['statut'] != 'Livré'
                            ? Column(
                                children: [
                                  Text(
                                    commande.snapshot.value['statut'],
                                    style: TextStyle(fontSize: 10),
                                  ),
                                  IconButton(
                                      onPressed: () async {
                                        final invoice = Invoice(
                                          livraison: commande
                                              .snapshot.value['livraison'],
                                          supplier: Supplier(
                                            name: 'Vistal',
                                            address:
                                                'www.vistal.cd\n+243 842642039',
                                            paymentInfo: commande
                                                .snapshot.value['payement'],
                                          ),
                                          customer: Customer(
                                            name: cutomerinfo['prenom']
                                                    .toString() +
                                                ' ' +
                                                cutomerinfo['nom'].toString(),
                                            address: commande
                                                    .snapshot.value['commune']
                                                    .toString() +
                                                ' ' +
                                                commande
                                                    .snapshot.value['quartier']
                                                    .toString() +
                                                ' ' +
                                                commande
                                                    .snapshot.value['avenue']
                                                    .toString() +
                                                ' ' +
                                                ', N° ${commande.snapshot.value['numeroavenue'].toString()}',
                                          ),
                                          info: InvoiceInfo(
                                            date: DateTime.parse(commande
                                                .snapshot.value['date']),
                                            moyenpaye: commande
                                                .snapshot.value['payement'],
                                            description: 'Etablissement:' +
                                                etabnme[commande
                                                    .snapshot.value['idetab']],
                                            number:
                                                '${DateTime.now().year}-${commande.snapshot.value['CodeClient']}',
                                          ),
                                          items: [
                                            for (final prod in commande
                                                .snapshot.value['listprods'])
                                              InvoiceItem(
                                                description: prod['idprod'],
                                                quantity: int.parse(prod['qt']),
                                                unitPrice:
                                                    double.parse(prod['prix']),
                                              ),
                                            ///////////////////////////////////////on peut en ajouter autant que possible ici
                                          ],
                                        );

                                        final pdfFile =
                                            await PdfInvoiceApi.generate(
                                                invoice);
                                        await PdfApi.openFile(pdfFile);
                                      },
                                      icon: Icon(Icons.download)),
                                  Text(
                                    commande.snapshot.value['statut'],
                                    style: TextStyle(fontSize: 10),
                                  ),
                                ],
                              )
                            : Column(
                                children: [
                                  Text(
                                    commande.snapshot.value['statut'],
                                    style: TextStyle(
                                        fontSize: 10, color: Colors.red),
                                  ),
                                  IconButton(
                                      onPressed: () async {
                                        final invoice = Invoice(
                                          livraison: commande
                                              .snapshot.value['livraison'],
                                          supplier: Supplier(
                                            name: 'Vistal',
                                            address:
                                                'www.vistal.cd\n+243 842642039',
                                            paymentInfo: commande
                                                .snapshot.value['payement'],
                                          ),
                                          customer: Customer(
                                            name: cutomerinfo['prenom']
                                                    .toString() +
                                                ' ' +
                                                cutomerinfo['nom'].toString(),
                                            address: commande
                                                    .snapshot.value['commune']
                                                    .toString() +
                                                ' ' +
                                                commande
                                                    .snapshot.value['quartier']
                                                    .toString() +
                                                ' ' +
                                                commande
                                                    .snapshot.value['avenue']
                                                    .toString() +
                                                ' ' +
                                                ', N° ${commande.snapshot.value['numeroavenue'].toString()}',
                                          ),
                                          info: InvoiceInfo(
                                            date: DateTime.parse(commande
                                                .snapshot.value['date']),
                                            moyenpaye: commande
                                                .snapshot.value['payement'],
                                            description: 'Etablissement:' +
                                                etabnme[commande
                                                    .snapshot.value['idetab']],
                                            number:
                                                '${DateTime.now().year}-${commande.snapshot.value['CodeClient']}',
                                          ),
                                          items: [
                                            for (final prod in commande
                                                .snapshot.value['listprods'])
                                              InvoiceItem(
                                                description: prod['idprod'],
                                                quantity: int.parse(prod['qt']),
                                                unitPrice:
                                                    double.parse(prod['prix']),
                                              ),
                                            ///////////////////////////////////////on peut en ajouter autant que possible ici
                                          ],
                                        );

                                        final pdfFile =
                                            await PdfInvoiceApi.generate(
                                                invoice);
                                        await PdfApi.openFile(pdfFile);
                                      },
                                      icon: Icon(Icons.download)),
                                ],
                              ),
              ),
            )
        ],
      ),
    ));
  }

  String getitemnumer(List list) {
    int i = 0;
    list.forEach((element) {
      i = i + 1;
    });
    return i.toString();
  }
}
