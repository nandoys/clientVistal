import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/detail_prod_ui.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';

class DataserachALLProd extends SearchDelegate<String> {
  final list; //List<Map>
  final etabname; //Map
  final urlprod; // Map
  // final vente;

  DataserachALLProd(
      {@required this.list, @required this.etabname, @required this.urlprod});

  @override
  List<Widget> buildActions(BuildContext context) {
    // TODO: implement buildActions
    return [
      IconButton(
          icon: Icon(Icons.clear),
          onPressed: () {
            query = "";
          })
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    // TODO: implement buildLeading
    return IconButton(
        icon: AnimatedIcon(
          icon: AnimatedIcons.menu_arrow,
          progress: transitionAnimation,
        ),
        onPressed: () {
          close(context, '');
        });
  }

  @override
  Widget buildResults(BuildContext context) {
    // TODO: implement buildResults
    return Container(
      child: Center(child: Text(query)),
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    // TODO: implement buildSuggestions
    if (query.isNotEmpty)
      return list.firstWhere(
                  (element) => element['nom']
                      .toString()
                      .toLowerCase()
                      .contains(query.toLowerCase()), orElse: () {
                return null;
              }) !=
              null
          ? ListView.builder(
              itemCount: list.length,
              itemBuilder: (context, index) {
                return list[index]['nom']
                        .toString()
                        .toLowerCase()
                        .contains(query.toLowerCase())
                    ? Card(
                        child: ListTile(
                          onTap: () {
                            push(
                                context,
                                DetaiUIProd(mapinfoprod: {
                                  'idprod': list[index]['nom'].toString(),
                                  'idetab': list[index]['idetab']
                                }));
                          },
                          title: Text(list[index]['nom'].toString() +
                              ' /Prix: ' +
                              list[index]['prix'].toString() +
                              '\$'),
                          subtitle: Row(
                            children: [
                              Icon(
                                Icons.storefront_outlined,
                                size: 14,
                                color: Colors.pink,
                              ),
                              SizedBox(
                                width: 2,
                              ),
                              Text(etabname[list[index]['idetab']].toString())
                            ],
                          ),
                          leading: Container(
                            height: 50,
                            width: 50,
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.white, width: 2),
                                borderRadius: BorderRadius.circular(10)),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: CachedNetworkImage(
                                filterQuality: FilterQuality.medium,
                                fit: BoxFit.fill,
                                imageUrl: urlprod[list[index]['nom']],
                                placeholder:
                                    (BuildContext context, String url) {
                                  return Center(
                                    child: SkeletonContainer.square(
                                      height: 50,
                                      width: 50,
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        ),
                      )
                    : Center(
                        child: Container(),
                      );
              })
          : Center(
              child: Container(
                child: Center(
                  child: Row(
                    children: [
                      SizedBox(
                        width: getheight(context) / 7,
                      ),
                      Text('Aucun Produi dit '),
                      Text(
                        '\"${query.toString().length <= 10 ? query.toString() : query.toString().substring(0, 10)}\"',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ),
            );
    else
      return Container(
        child: Center(
          child: Text("Aucun resultat"),
        ),
      );
  }
}
