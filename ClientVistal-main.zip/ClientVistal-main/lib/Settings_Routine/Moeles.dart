import 'package:flutter/material.dart';

class EtabModel {
  String id, nom, url;
  double lat, long;
  EtabModel(this.id, this.nom, this.lat, this.long, this.url);
}
