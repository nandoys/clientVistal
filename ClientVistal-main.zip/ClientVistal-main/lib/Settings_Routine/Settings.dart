import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:package_info/package_info.dart';
import 'package:whatsapp_unilink/whatsapp_unilink.dart';
import 'package:get_storage/get_storage.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:simple_fontellico_progress_dialog/simple_fontico_loading.dart';

var eve;
bool vue_update = false;
/////////////////////////////////////////////////////////
IconData drawericon = Icons.apps_sharp;
Color Darkcolor = Colors.black.withOpacity(0.8);
Color litetextcolors = Colors.white;
////////////////////////////////////////////////////////////////
String nomuser = '';
String prenomuser = '';
String phoneuser = '';
////////////////////////////////////////::  Firebase //////////////////////////////////////////////
final datacloud = FirebaseDatabase.instance.reference();
DatabaseReference Vistal_SIMPLEUSER =
    datacloud.reference().child("Vistal_users");
DatabaseReference Version = datacloud.reference().child("verstion_vistal");
DatabaseReference Image_profil_vistal =
    datacloud.reference().child("Image_profil_vistal");
DatabaseReference Image_couverture_vistal =
    datacloud.reference().child("Image_couverture_vistal");
DatabaseReference Vistal_Produits =
    datacloud.reference().child("Vistal_Produits");
DatabaseReference Vistal_ImageOfProduits =
    datacloud.reference().child("Vistal_ImageOfProduits");
DatabaseReference Vistal_vendeur_profil_photo =
    datacloud.reference().child("Vistal_vendeur_profil_photo");
DatabaseReference Vistal_Vendeur =
    datacloud.reference().child("Vistal_Vendeurs");
DatabaseReference Vistal_Favorits_produits =
    datacloud.reference().child("Vistal_Favorits_produits");
DatabaseReference Vistal_panier = datacloud.reference().child("Vistal_panier");
DatabaseReference Vistal_vendeur_EtabImageDascription_photo =
    datacloud.reference().child("Vistal_vendeur_EtabImageDascription_photo");
DatabaseReference Vistal_vendeur_couverture_photo =
    datacloud.reference().child("Vistal_vendeur_couverture_photo");
DatabaseReference Vistal_Commandes =
    datacloud.reference().child("Vistal_Commandes");
DatabaseReference Vistal_notifications =
    datacloud.reference().child("Vistal_notifications");
DatabaseReference Vistal_coursier =
    datacloud.reference().child("Vistal_coursier");
DatabaseReference Vistal_Admin = datacloud.reference().child("Vistal_Admin");
DatabaseReference Vistal_Categorieprod =
    datacloud.reference().child("Vistal_Categorieprod");
DatabaseReference Vistal_chemin_Course =
    datacloud.reference().child("Vistal_chemin_Course");
DatabaseReference Vistal_Couse = datacloud.reference().child("Vistal_Couse");
//////////////////////////LOGOS//////////////////////////////
String POSITION = 'assets/logos/logo.png';
String APPNAME = 'Vistal';
////////////////// get size of device ////////////////////
getheight(context) => MediaQuery.of(context).size.height;
getwidth(context) => MediaQuery.of(context).size.width;
///////////////////////////sharepre and auth
var user;
late SharedPreferences sharedPreferences;
late FirebaseAuth auth;
late bool dark;

var appdata = GetStorage();
Future<void> intuserandfirebase() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await Firebase.initializeApp().whenComplete(() {
    auth = FirebaseAuth.instance;
    user = auth.currentUser;
  });
  sharedPreferences = await SharedPreferences.getInstance();
  await GetStorage.init();
  dark = appdata.read('dark');
  dark = dark == eve || dark == false ? false : true;
}

//////////////////////////////////// share pref
shareset(key, value) {
  sharedPreferences.setString(key, value);
}

shareget(value) {
  return sharedPreferences.get(value);
}

//////////////////////////////////////// loading ....................////////////////
Future showDialogs(context, int seconde, title) async {
  SimpleFontelicoProgressDialog _dialog =
      SimpleFontelicoProgressDialog(context: context, barrierDimisable: false);
  _dialog.show(message: title, type: SimpleFontelicoProgressDialogType.phoenix);
  await Future.delayed(Duration(seconds: seconde));
  _dialog.hide();
}

////////////////////////////////////////////////////////////////////////////
class Showhide {
  final context;
  final text;
  final SimpleFontelicoProgressDialog _dialog;
// SimpleFontelicoProgressDialog( context: context,barrierDimisable: false) //valeur initiale de _dialog
  Showhide(this.context, this.text, this._dialog);
  show() {
    _dialog.show(
        message: text, type: SimpleFontelicoProgressDialogType.phoenix);
  }

  hide() {
    _dialog.hide();
  }
}

///////////////////////////////url launcher //////////////////////////////////////////////////////////////////

String versionapp = '';
Future initappinfo() async {
  PackageInfo packageInfo = await PackageInfo.fromPlatform();
  versionapp = packageInfo.version;
}

launchURL(link) async {
  if (await canLaunch(link)) {
    await launch(link);
  } else {
    throw 'Could not launch $link';
  }
}

////////////////////// whatsapp ///////////////////////////////////////////
String mailto = 'mailto:contact@vistal.cd';
// password: Kinshasa01
String phoneto = '+243-840808801';
launchwhatsapp(numero) async {
  final link = WhatsAppUnilink(
      phoneNumber: numero, text: 'Bonjour, je vous contacte depuis Vistal...');
  await launch('$link');
}

////// a
// action  avant
//  await Future.delayed(Duration(milliseconds: 4000), () {
//     _home();
//   });

String sumofsum(monpanier) {
  //Map<String, List<Map<dynamic, dynamic>>>
  double sum = 0;
  monpanier[monpanier.keys.first].forEach((element) {
    sum = sum + double.parse(element['prix_total']);
  });
  return sum.toString();
}

String sumoflist(monpanier) {
  double sum = 0;
  monpanier.forEach((element) {
    sum = sum + double.parse(element['prix_total']);
  });
  return sum.toString();
}

String listtaille(monpanier) {
  int nombreitem = 0;
  monpanier.forEach((element) {
    nombreitem = nombreitem + 1;
  });
  return nombreitem.toString();
}

////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
snackshow(titre, context) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(titre)));
}

String getwalinstring(String val, character) {
  int index = val.indexOf('$character');
  var retour = val.substring(0, index);
  return retour;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
getcoutlivraison(commune) {
  if (commune == 'Ngaliema' ||
      commune == 'Limete' ||
      commune == 'Selembao' ||
      commune == 'Gombe' ||
      commune == 'Kintambo' ||
      commune == 'Bandalungwa' ||
      commune == 'Kinshasa' ||
      commune == 'Kasavubu') {
    return '3';
  }
  if (commune == 'Mont Ngafula' || commune == 'Masina' || commune == 'Ndjili') {
    return '5';
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
