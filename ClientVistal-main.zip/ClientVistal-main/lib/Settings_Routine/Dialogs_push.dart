import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:vistalapp/Dashboard/actualites_articles.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';

void showAlertDialogOnOkCallback(String title, String msg,
    DialogType dialogType, BuildContext context, VoidCallback onOkPress) {
  AwesomeDialog(
    context: context,
    animType: AnimType.TOPSLIDE,
    dialogType: dialogType,
    title: title,
    desc: msg,
    btnOkIcon: Icons.check_circle,
    btnOkColor: Colors.green.shade900,
    btnOkOnPress: onOkPress,
  ).show();
}

//////////////////////////// navigator
pop(context) {
  Navigator.pop(context);
}

pushandreplace(context, route) {
  Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) {
    return route;
  }));
}

push(context, route) {
  Navigator.push(context, MaterialPageRoute(builder: (_) {
    return route;
  }));
}

pushanim(context, page) {
  return Navigator.push(
      context,
      PageRouteBuilder(
          transitionDuration: Duration(milliseconds: 1000),
          transitionsBuilder: (context, animation, animationduration, child) {
            animation =
                CurvedAnimation(parent: animation, curve: Curves.bounceInOut);
            // bounceInOut
            return ScaleTransition(
              scale: animation,
              child: child,
              alignment: Alignment.center,
            );
          },
          pageBuilder: (context, animation, animationduration) {
            return page;
          }));
}

pushrepalceanim(context, page) {
  return Navigator.pushReplacement(
      context,
      PageRouteBuilder(
          transitionDuration: Duration(milliseconds: 1000),
          transitionsBuilder: (context, animation, animationduration, child) {
            animation =
                CurvedAnimation(parent: animation, curve: Curves.bounceInOut);
            // bounceInOut
            return ScaleTransition(
              scale: animation,
              child: child,
              alignment: Alignment.center,
            );
          },
          pageBuilder: (context, animation, animationduration) {
            return page;
          }));
}
// pushremovuntilanim(context, page) {
//   return Navigator.pushAndRemoveUntil(
//       context,
//       PageRouteBuilder(
//           transitionDuration: Duration(milliseconds: 2000),
//           transitionsBuilder: (context, animation, animationduration, child) {
//             animation =
//                 CurvedAnimation(parent: animation, curve: Curves.bounceInOut);
//             // bounceInOut
//             return ScaleTransition(
//               scale: animation,
//               child: child,
//               alignment: Alignment.center,
//             );
//           },
//           pageBuilder: (context, animation, animationduration) {
//             return page;
//           }), );
// }

/////////////////////////////////////////////////////////////////////////////////////////////////////
dialogsimple(context, title, message, textleftbutton, textrightbutton,
    functionleft, functionright) {
  showCupertinoDialog(
    context: context,
    builder: (BuildContext context) {
      return CupertinoAlertDialog(
        title: Text(title),
        content: Text(message),
        actions: <Widget>[
          CupertinoDialogAction(
            child: Text(textleftbutton),
            isDestructiveAction: true,
            onPressed: functionleft,
          ),
          CupertinoDialogAction(
            child: Text(textrightbutton),
            isDefaultAction: true,
            onPressed: functionright,
          )
        ],
      );
    },
  );
}

////////////////////////////////////// pushes /////////////////////////////////////////////////////////

//////////////////// toast ////////////////////////////////////////

toast(Message, Color color, Color textcolor) {
  return Fluttertoast.showToast(
      gravity: ToastGravity.CENTER,
      msg: Message,
      backgroundColor: color,
      textColor: textcolor);
}

modalbotosheetcontact(context) {
  return showModalBottomSheet(
    context: context,
    builder: (context) {
      return Container(
        color: Color(0xFF737373),
        child: Container(
          child: Column(
            children: [
              ListTile(
                onTap: () {
                  launchwhatsapp('+243-830537353');
                },
                leading: Icon(
                  Icons.call,
                  color: Colors.red,
                ),
                title: Text('Contacter vistal Via whatsApp',
                    style: TextStyle(color: Colors.blue)),
              ),
              ListTile(
                onTap: () {
                  launchURL(mailto);
                },
                leading: Icon(
                  Icons.mail,
                  color: Colors.red,
                ),
                title: Text('Nous écrire via Mail',
                    style: TextStyle(color: Colors.blue)),
              ),
              ListTile(
                onTap: () {
                  launchURL('tel:$phoneto');
                },
                leading: Icon(
                  Icons.call_made,
                  color: Colors.red,
                ),
                title: Text(
                  'Appel normal',
                  style: TextStyle(color: Colors.blue),
                ),
              ),
            ],
          ),
          decoration: BoxDecoration(
              color: Theme.of(context).canvasColor,
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(12), topRight: Radius.circular(20))),
          height: getheight(context) * 0.23,
          width: 50,
        ),
      );
    },
  );
}
