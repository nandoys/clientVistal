import 'package:vistalapp/Auth_splash/Auth/login.dart';
import 'package:vistalapp/Auth_splash/Beforelog/language.choices.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/connectivity/connexion_error.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vistalapp/connectivity/connectivity_service.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';

class Network extends StatefulWidget {
  // final int coach;
  // const Network({Key key, this.coach}) : super(key: key);
  @override
  _NetworkState createState() => _NetworkState();
}

class _NetworkState extends State<Network> {
  @override
  Widget build(BuildContext context) {
    // Get our connection status from the provider
    var connectionStatus = Provider.of<ConnectivityStatus>(context);
    if (connectionStatus == ConnectivityStatus.WiFi ||
        connectionStatus == ConnectivityStatus.Cellular) {
      return sharedPreferences.getKeys().contains('phone')
          ? Homepage(
              index: 2,
              page: null,
              toseecat: '',
            )
          : Entrypointlog();
      // : Choiceoflanguage();
    } else {
      return ConnectivityError();
    }
  }
}
