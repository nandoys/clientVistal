import 'package:flutter/material.dart';

class ConnectivityError extends StatefulWidget {
  @override
  _ConnectivityErrorState createState() => _ConnectivityErrorState();
}

class _ConnectivityErrorState extends State<ConnectivityError> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
          'Network Error',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.white,
        ),
        body: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(
              Icons.network_wifi,
              size: 100,
              color: Colors.grey[300],
            ),
            SizedBox(height: 10),
            Text('Please Check Your Network Connection'),
          ],
        )));
  }
}
