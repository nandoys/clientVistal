import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:get_storage/get_storage.dart';
import 'package:vistalapp/connectivity/network_decision.dart';
import 'language.choices.dart';

class Splash extends StatefulWidget {
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  ////// the begining of my splash screen ///////////////////////////////////////////////
  void initState() {
    super.initState();
    _time();
  }

  _home() {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => Network(),
    ));
  }

  Future<bool> _time() async {
    await intuserandfirebase();
    print(dark.toString() + ' from splash');
    await Future.delayed(Duration(milliseconds: 4000), () {
      _home();
    });
    return true;
  }

///////////////////////////// the end of my splash screen  ////////////////////////////:
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 350,
              width: 250,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  image: DecorationImage(
                      image: AssetImage(POSITION), fit: BoxFit.fill)),
            ),
            SizedBox(
              height: 30,
            ),
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
              strokeWidth: 6,
            )
          ],
        ),
      ),
    );
  }
}
