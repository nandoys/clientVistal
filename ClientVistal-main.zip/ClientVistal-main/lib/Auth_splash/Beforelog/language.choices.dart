import 'package:flutter/material.dart';
import 'package:vistalapp/Auth_splash/Auth/login.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:google_fonts/google_fonts.dart';

class Choiceoflanguage extends StatefulWidget {
  @override
  _ChoiceoflanguageState createState() => _ChoiceoflanguageState();
}

class _ChoiceoflanguageState extends State<Choiceoflanguage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    height: 40,
                    width: 40,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage('assets/logos/globe.jpg'),
                            fit: BoxFit.fill),
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.transparent),
                  ),
                  Text('Selectionner votre langue préférée',
                      style: GoogleFonts.adventPro(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      )),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Card(
                child: ListTile(
                  onTap: () {
                    pushanim(context, Entrypointlog());
                  },
                  leading: CircleAvatar(
                    backgroundColor: Colors.transparent,
                    backgroundImage: AssetImage('assets/logos/fr.jpg'),
                  ),
                  title: Text('Français',
                      style: GoogleFonts.adventPro(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Card(
                child: ListTile(
                  onTap: () {
                    pushanim(context, Entrypointlog());
                  },
                  leading: CircleAvatar(
                    backgroundColor: Colors.transparent,
                    backgroundImage: AssetImage('assets/logos/en.jpg'),
                  ),
                  title: Text('English',
                      style: GoogleFonts.adventPro(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      )),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
