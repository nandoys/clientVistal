// import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_phone_auth_handler/firebase_phone_auth_handler.dart';
import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:google_fonts/google_fonts.dart';

// ignore: must_be_immutable
class PhoneVerif extends StatelessWidget {
  final phonenumbre;
  PhoneVerif({
    @required this.phonenumbre,
  });
  @override
  Widget build(BuildContext context) {
    late String _enteredOTP;
    return SafeArea(
      child: FirebasePhoneAuthHandler(
        phoneNumber: phonenumbre,
        timeOutDuration: const Duration(seconds: 60),
        onLoginSuccess: (userCredential, autoVerified) async {
          //////////////////////////// when the auth as  succeded
          shareset('phone', userCredential.user!.phoneNumber);
          //////////////////////////////////////////////////////////////////////////////////////////////
          pushandreplace(
              context,
              Homepage(
                index: 2,
                page: null,
                toseecat: '',
              ));
        },
        onLoginFailed: (authException) {
          print("An error occurred: ${authException.message}");
        },
        builder: (context, controller) {
          return Scaffold(
            appBar: AppBar(
              centerTitle: true,
              title: Text(
                controller.timerIsActive ? "Code de Vérification" : '',
                style: TextStyle(color: Colors.white),
              ),
              backgroundColor: Colors.red,
              actions: controller.codeSent
                  ? [
                      TextButton(
                        child: Text(
                          controller.timerIsActive
                              ? "${controller.timerCount.inSeconds}s"
                              : "Envoyer à nouveau",
                          style: TextStyle(color: Colors.white, fontSize: 15),
                        ),
                        onPressed: controller.timerIsActive
                            ? null
                            : () async {
                                await controller.sendOTP();
                              },
                      ),
                      SizedBox(width: 5),
                    ]
                  : null,
            ),
            body: controller.codeSent
                ? ListView(
                    padding: EdgeInsets.all(20),
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 12.0, left: 16),
                        child: Text(
                          "Un SMS avec le code de vérification vous a été envoyé au $phonenumbre",
                          style: TextStyle(
                            fontSize: 17,
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      Divider(),
                      AnimatedContainer(
                        duration: Duration(seconds: 1),
                        height: controller.timerIsActive ? null : 0,
                        child: Column(
                          children: [
                            CircularProgressIndicator(),
                            SizedBox(height: 50),
                            Divider(),
                          ],
                        ),
                      ),
                      Center(
                        child: Text(
                          "Saisir le code",
                          style: TextStyle(
                            fontSize: 17,
                            letterSpacing: 5,
                          ),
                        ),
                      ),
                      TextField(
                        maxLength: 6,
                        keyboardType: TextInputType.number,
                        onChanged: (String v) async {
                          _enteredOTP = v;
                          if (_enteredOTP.length == 6) {
                            final res =
                                await controller.verifyOTP(otp: _enteredOTP);
                            // // Incorrect OTP
                            // if (!res)
                            //   nativetoast(
                            //       context,
                            //       "Svp, entrez le code valide envoyé au $phonenumbre",
                            //       Colors.red,
                            //       4);
                          }
                        },
                      ),
                    ],
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(height: 50),
                      Center(
                        child: Text(
                          "En cours d\'envoi...",
                          style: TextStyle(fontSize: 25),
                        ),
                      ),
                    ],
                  ),
            floatingActionButton: controller.codeSent
                ? FloatingActionButton(
                    backgroundColor: Colors.red,
                    child: Icon(Icons.check, color: Colors.white),
                    onPressed: () async {
                      if (_enteredOTP == null || _enteredOTP.length != 6) {
                        toast("Svp, entrez un code valide", Colors.red,
                            Colors.white);
                      } else {
                        final res =
                            await controller.verifyOTP(otp: _enteredOTP);
                        // Incorrect OTP
                        if (!res)
                          toast(
                              "Svp, entrez le code valide envoyé au $phonenumbre",
                              Colors.red,
                              Colors.white);
                      }
                    },
                  )
                : null,
          );
        },
      ),
    );
  }
}
