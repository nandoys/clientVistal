import 'package:flutter/material.dart';
import 'package:vistalapp/Auth_splash/Auth/signin.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:vistalapp/Auth_splash/Auth/Phone_verif.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:google_fonts/google_fonts.dart';

class Entrypointlog extends StatefulWidget {
  @override
  _EntrypointlogState createState() => _EntrypointlogState();
}

class _EntrypointlogState extends State<Entrypointlog> {
  // TextEditingController nom = TextEditingController();
  TextEditingController phonecontroller = TextEditingController();
  late String phonenumber;
  String initialCountry = 'CD';
  // String phoneNumbe;
  PhoneNumber number = PhoneNumber(isoCode: 'CD');
  List<Map> allusers = [];
  bool obscure = true;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      setState(() {
        allusers.add({
          'phone': event.snapshot.key,
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Column(
                children: <Widget>[
                  Container(
                    height: 280,
                    width: getwidth(context),
                    decoration: BoxDecoration(
                      // borderRadius: BorderRadius.circular(10),
                      // border: Border.all(color: Colors.red),
                      image: DecorationImage(
                          image: AssetImage('assets/logos/top.jpg'),
                          fit: BoxFit.fill),
                    ),
                  ),
                  SizedBox(
                    height: 50,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.grey.shade100),
                      child: InternationalPhoneNumberInput(
                        onInputChanged: (PhoneNumber number) {
                          setState(() {
                            phonenumber = number.phoneNumber.toString();
                            // print(number.phoneNumber);
                          });
                        },
                        maxLength: 12,
                        onInputValidated: (bool value) {
                          // if (value == true)
                          // Fluttertoast.showToast(msg: "teriminé");
                        },
                        selectorConfig: SelectorConfig(
                          selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
                          // backgroundColor: Colors.white,
                        ),
                        ignoreBlank: false,
                        autoValidateMode: AutovalidateMode.disabled,
                        selectorTextStyle: TextStyle(color: Colors.black),
                        initialValue: number,
                        textFieldController: phonecontroller,
                        inputBorder: OutlineInputBorder(),
                        inputDecoration: InputDecoration(
                            hintText: 'Numéro de téléphone',
                            // hintStyle: GoogleFonts.,
                            border: InputBorder.none),
                      ),
                    ),
                  ),
                  SizedBox(height: 30.0),
                  SizedBox(
                    width: double.infinity,
                    child: InkWell(
                      onTap: () {
                        if (allusers.firstWhere(
                              (element) => element['phone'] == phonenumber,
                              orElse: () {
                                return eve;
                              },
                            ) !=
                            eve) {
                          pushanim(
                              context, PhoneVerif(phonenumbre: phonenumber));
                        } else {
                          showAlertDialogOnOkCallback(
                              'Invalide',
                              'Aucun compte ne correspond à ce numéro de téléphone, veuillez vérifier er réessayer',
                              DialogType.ERROR,
                              context,
                              () => {});
                        }
                      },
                      child: Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            color: Colors.red.shade900,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.red.shade100)),
                        height: 50,
                        width: 50,
                        child: Text(
                          'Connexion',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      FlatButton(
                        textColor: Colors.white70,
                        child: Text(
                          "Créer un compte",
                          style: TextStyle(fontSize: 15, color: Colors.blue),
                        ),
                        onPressed: () {
                          // pushfarward(context, Signin());
                          pushanim(context, Signin());
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
