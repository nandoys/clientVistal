import 'package:flutter/material.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:vistalapp/Auth_splash/Auth/login.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'Phone_verif.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Signin extends StatefulWidget {
  @override
  _SigninState createState() => _SigninState();
}

class _SigninState extends State<Signin> {
  TextEditingController prenom = TextEditingController();
  TextEditingController nom = TextEditingController();
  TextEditingController pw = TextEditingController();
  //////////////////////////////////////////////////////// phone number
  final TextEditingController controller = TextEditingController();
  String initialCountry = 'CD';
  late String phoneNumbe;
  PhoneNumber number = PhoneNumber(isoCode: 'CD');

  List<Map> allusers = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      setState(() {
        allusers.add({
          'nom': event.snapshot.value['nom'],
          'prenom': event.snapshot.value['prenom'],
          'phone': event.snapshot.key,
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Column(
                children: <Widget>[
                  Container(
                    height: 280,
                    width: getwidth(context),
                    decoration: BoxDecoration(
                      // borderRadius: BorderRadius.circular(10),
                      // border: Border.all(color: Colors.red),
                      image: DecorationImage(
                          image: AssetImage('assets/logos/top.jpg'),
                          fit: BoxFit.fill),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    'Inscrivez-vous',
                    style: TextStyle(
                        color: Colors.blueGrey,
                        fontSize: 20.0,
                        // letterSpacing: 3,
                        fontWeight: FontWeight.bold),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(10.0)),
                      child: TextField(
                        controller: prenom,
                        decoration: InputDecoration(
                          contentPadding: const EdgeInsets.all(16.0),
                          prefixIcon: Container(
                              padding: const EdgeInsets.only(
                                  top: 16.0, bottom: 16.0),
                              margin: const EdgeInsets.only(right: 8.0),
                              decoration: BoxDecoration(
                                  color: Colors.transparent,
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(30.0),
                                      bottomLeft: Radius.circular(30.0),
                                      topRight: Radius.circular(30.0),
                                      bottomRight: Radius.circular(10.0))),
                              child: Icon(
                                Icons.person,
                                color: Colors.red,
                              )),
                          hintText: "Prénom",
                          hintStyle: TextStyle(color: Colors.black),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30.0),
                              borderSide: BorderSide.none),
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.1),
                        ),
                      ),
                    ),
                  ),
                  ////////////////////////////////////////////////////////////////////////////////////////
                  SizedBox(height: 10.0),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(10.0)),
                      child: TextField(
                        controller: nom,
                        decoration: InputDecoration(
                          contentPadding: const EdgeInsets.all(16.0),
                          prefixIcon: Container(
                              padding: const EdgeInsets.only(
                                  top: 16.0, bottom: 16.0),
                              margin: const EdgeInsets.only(right: 8.0),
                              decoration: BoxDecoration(
                                  color: Colors.transparent,
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(30.0),
                                      bottomLeft: Radius.circular(30.0),
                                      topRight: Radius.circular(30.0),
                                      bottomRight: Radius.circular(10.0))),
                              child: Icon(
                                Icons.person,
                                color: Colors.red,
                              )),
                          hintText: "Nom",
                          hintStyle: TextStyle(color: Colors.black),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30.0),
                              borderSide: BorderSide.none),
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.1),
                        ),
                      ),
                    ),
                  ),

                  ////////////////////////////////////////////////////////////////////////////:
                  SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(10)),
                      child: InternationalPhoneNumberInput(
                        onInputChanged: (PhoneNumber number) {
                          setState(() {
                            phoneNumbe = number.phoneNumber.toString();
                            print(number.phoneNumber);
                          });
                        },
                        maxLength: 12,
                        onInputValidated: (bool value) {
                          if (value == true)
                            Fluttertoast.showToast(
                                msg: "Terminer",
                                backgroundColor: Colors.black,
                                textColor: Colors.white);
                          print("finished value : " + value.toString());
                        },
                        selectorConfig: SelectorConfig(
                          selectorType: PhoneInputSelectorType.BOTTOM_SHEET,
                          // backgroundColor: Colors.white,
                        ),
                        ignoreBlank: false,
                        autoValidateMode: AutovalidateMode.disabled,
                        selectorTextStyle: TextStyle(color: Colors.black),
                        initialValue: number,
                        textFieldController: controller,
                        inputBorder: OutlineInputBorder(),
                        inputDecoration: InputDecoration(
                            hintText: 'Numéro de téléphone',
                            border: InputBorder.none),
                      ),
                    ),
                  ),
                  SizedBox(height: 30.0),
                  SizedBox(
                      width: double.infinity,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: InkWell(
                          onTap: () {
                            if (nom.text.isEmpty ||
                                prenom.text.isEmpty ||
                                phoneNumbe == null) {
                              showAlertDialogOnOkCallback(
                                  'Champ obligatoire',
                                  'Veuillez Remplir tous les champs pour continuer.',
                                  DialogType.INFO,
                                  context,
                                  () => {});
                            } else {
                              if (allusers.firstWhere(
                                    (element) => element['phone'] == phoneNumbe,
                                    orElse: () {
                                      return eve;
                                    },
                                  ) ==
                                  eve) {
                                dialogsimple(
                                    context,
                                    'Avertissement',
                                    '$phoneNumbe est votre numéro de téléphone et vous servira de récupération pour votre compte. Nous allons procéder à sa vérification',
                                    'Annuler',
                                    'Confirmer', () {
                                  Navigator.pop(context);
                                }, () {
                                  prenomuser = prenom.text;
                                  nomuser = nom.text;
                                  phoneuser = phoneNumbe;
                                  pushanim(context,
                                      PhoneVerif(phonenumbre: phoneNumbe));
                                });
                              } else {
                                showAlertDialogOnOkCallback(
                                    'Numéro déjà pris',
                                    'Ce numéro de téléphone est déjà utilisé par un autre compte, veuillez changer et réessayer',
                                    DialogType.WARNING,
                                    context,
                                    () => {});
                              }
                            }
                          },
                          child: Container(
                            alignment: Alignment.center,
                            height: 50,
                            width: 50,
                            child: Text(
                              'Valider',
                              style: TextStyle(
                                  letterSpacing: 2,
                                  color: Colors.white,
                                  fontSize: 15),
                            ),
                            decoration: BoxDecoration(
                              color: Colors.red.shade900,
                              border: Border.all(
                                  color: Colors.red.shade900, width: 2),
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                        ),
                      )),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      FlatButton(
                        textColor: Colors.white70,
                        child: Text(
                          "Déjà un compte ? Connectez-vous",
                          style:
                              TextStyle(fontSize: 15, color: Colors.blueAccent),
                        ),
                        onPressed: () {
                          pushanim(context, Entrypointlog());
                        },
                      ),
                    ],
                  ),
                  //SizedBox(height: 10.0),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
