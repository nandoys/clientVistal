import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import 'package:flutter_native_image/flutter_native_image.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:uuid/uuid.dart';

// the file name of the file, the file access way in the device
////////////////////////////////////////////////////////////////////////////////////////
class FirebaseStorageService {
  final storage = FirebaseStorage.instance;
  Future<String> uploadimage(File file, String fileName, repertoire) async {
    var snapshot = await storage
        .ref()
        .child('$repertoire/$fileName')
        .putFile(file)
        .whenComplete(() {});
    return await snapshot.ref.getDownloadURL();
  }

  Future<String> uploadmultiimages(File file, String fileName) async {
    var snapshot = await storage
        .ref()
        .child('vendorImages/$fileName')
        .putFile(file)
        .whenComplete(() => null);

    return await snapshot.ref.getDownloadURL();
  }
}

///////////////////////////////////////////////// pick image and compresse
pickImageandcompress(int cameraotgalerie, context) async {
  final _picker = ImagePicker();
  late PickedFile? image;

  File croppedFile;
  ////////////////////////////////////////////////////////////////
  await Permission.photos.request(); // on demande la permission
  var permissionStatus = await Permission.photos.status;
  if (permissionStatus.isGranted) {
    //Get Image From Device ///////////////////////////////
    image = await _picker.getImage(
        source:
            cameraotgalerie == 0 ? ImageSource.camera : ImageSource.gallery);
    ///////////////// compression et croppage///////////////////////////////////////
    if (image != null) {
      ImageProperties properties =
          await FlutterNativeImage.getImageProperties(image.path);
      //CropImage
      if (properties.height! > int?.parse(properties.width.toString())) {
        var yoffset =
            (properties.height! - int?.parse(properties.width.toString())) / 2;
        croppedFile = await FlutterNativeImage.cropImage(
            image.path,
            0,
            yoffset.toInt(),
            int?.parse(properties.width.toString()),
            int?.parse(properties.width.toString()));
      } else if (properties.width! > int?.parse(properties.height.toString())) {
        var xoffset =
            (properties.width! - int?.parse(properties.height.toString())) / 2;
        croppedFile = await FlutterNativeImage.cropImage(
            image.path,
            xoffset.toInt(),
            0,
            int?.parse(properties.height.toString()),
            int?.parse(properties.height.toString()));
      } else {
        croppedFile = File(image.path);
      }
      //Resize file //////////////////////////////////////////////
      File compressedFile = await FlutterNativeImage.compressImage(
          croppedFile.path,
          quality: 100,
          targetHeight: 600,
          targetWidth: 600);

      // FirebaseStorageService.IMAGETODESPLAY = compressedFile;
      return compressedFile;
    }
  } else {
    // failedtoast(context, 'Aucune permission donnée');
  }
}

///////////////////////////////////compresse and send///////////////////////////////////////////////////////////
Future<String> sendimage(File compressedFile, repertoire) async {
  // on l'execute et après on stocke l'url dans la bd
  final storageService = FirebaseStorageService();
  var uuid = Uuid();
  //Upload to Firebase
  var imageUrl =
      await storageService.uploadimage(compressedFile, uuid.v4(), repertoire);
  // FirebaseStorageService.URLTOPUBLISH = imageUrl;
  // FirebaseStorageService.IMAGETODESPLAY = null;
  // _isUploading.sink.add(false);
  return imageUrl;
}
