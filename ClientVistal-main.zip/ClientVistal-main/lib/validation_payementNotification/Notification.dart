import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/SeemoreProd.dart';
import 'package:vistalapp/Facture_pdf/api/pdf_api.dart';
import 'package:vistalapp/Facture_pdf/api/pdf_invoice_api.dart';
import 'package:vistalapp/Facture_pdf/model/customer.dart';
import 'package:vistalapp/Facture_pdf/model/invoice.dart';
import 'package:vistalapp/Facture_pdf/model/supplier.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';

class Notifications extends StatefulWidget {
  @override
  _NotificationsState createState() => _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  List<Map> panier = [];
  List<Map> allpod = [];
  Map etabnme = {};
  Map urletab = {};
  List<Event> mycommds = [];
  Map cutomerinfo = {};
  Map prodprice = {};
  List<Event> notifications = [];
///////////////////////////////////////////////////////////////////////////////////////////////////
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    ///////////////////////////
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////// end commande ///////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      setState(() {
        prodprice[event.snapshot.key] = event.snapshot.value['prix'];
      });
    });

    ///////////////////////////////////////////// Etab name ///////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        etabnme[event.snapshot.key] = event.snapshot.value['etabname'];
      });
    });
    ////////////////////////// etab url //////////////////////////////////////
    Vistal_vendeur_profil_photo.onChildAdded.listen((event) {
      setState(() {
        urletab['${event.snapshot.key.toString()}'] =
            event.snapshot.value['url'];
      });
    });
    //////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_Commandes.onChildAdded.listen((event) {
      if (event.snapshot.value['userphone'] == shareget('phone')) {
        setState(() {
          mycommds.add(event);
        });
      }
    });
    ///////////////////////////////////////////////////////////
    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      if (shareget('phone') == event.snapshot.key) {
        setState(() {
          cutomerinfo['prenom'] = event.snapshot.value['prenom'];
          cutomerinfo['nom'] = event.snapshot.value['nom'];
        });
      }
    });
    ///////////////////////// notification //////////////////
    Vistal_notifications.onChildAdded.listen((event) {
      setState(() {
        notifications.add(event);
      });
    });
  }

  var eve;
  Future<bool> _gotoHom() async {
    push(context, Homepage(index: 2, page: 2, toseecat: null));
    return eve;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _gotoHom,
      child: Scaffold(
          appBar: AppBar(
            title: Text(
              'Notifications',
              style: TextStyle(),
            ),
            centerTitle: false,
            backgroundColor: Colors.red,
            elevation: 0,
            actions: [
              IconButton(
                  icon: Icon(Icons.inventory_outlined),
                  onPressed: () {
                    push(context, CallerCouserEtCommande());
                  }),
              Stack(
                children: [
                  Stack(
                    children: [
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 5.0, left: 2, right: 4),
                        child: IconButton(
                            icon: Icon(Icons.local_grocery_store),
                            onPressed: panier.length != 0
                                ? () {
                                    push(
                                        context,
                                        Homepage(
                                            index: 3, page: 3, toseecat: null));
                                  }
                                : () {}),
                      ),
                      panier.length != 0
                          ? Positioned(
                              top: 5,
                              left: 30,
                              child: Container(
                                alignment: Alignment.center,
                                child: Text(
                                  '${panier.length}',
                                  style: TextStyle(color: Colors.white),
                                ),
                                height: 20,
                                width: 20,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.black),
                              ),
                            )
                          : Container()
                    ],
                  )
                ],
              ),
            ],
          ),
          body: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                for (final notif in notifications..reversed)
                  Card(
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.transparent,
                        backgroundImage:
                            AssetImage('assets/logos/location.png'),
                      ),
                      title: Text(notif.snapshot.value['titre'].toString()),
                      subtitle: Column(
                        children: [
                          Text(notif.snapshot.value['content'].toString()),
                          Text(notif.snapshot.value['date']
                              .toString()
                              .substring(0, 10)),
                        ],
                      ),
                    ),
                  )
              ],
            ),
          )),
    );
  }
}
