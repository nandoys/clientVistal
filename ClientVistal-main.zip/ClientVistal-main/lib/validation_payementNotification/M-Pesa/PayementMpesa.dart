import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'dart:convert';
//////////////////////////////////////////////////////////
import 'package:meta/meta.dart';
import 'package:vistalapp/validation_payementNotification/M-Pesa/stomp.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/io.dart';

/////////////////////////////////////////////////////////////////////

// class MpesaPayement extends StatefulWidget {
//   // const MpesaPayement({ Key? key }) : super(key: key);

//   @override
//   _MpesaPayementState createState() => _MpesaPayementState();
// }

// class _MpesaPayementState extends State<MpesaPayement> {
//   Map datafrommpsa = {};
//   Future<void> _getmpesa() async {
//     var random = new Random();
//     int min = 10;
//     int max = 99;
//     var randomclient1 = min + random.nextInt(max - min);

// //////////////////////////////////////////////////////////////////////////
//     var body = jsonEncode({
//       "CustomerMSISDN".toLowerCase(): "24381 1966923",
//       "Currency".toLowerCase(): "USD",
//       "Amount".toLowerCase(): "1",
//       "ThirdPartyReference".toLowerCase(): "$randomclient1",
//       "Initials".toLowerCase(): "", // EX: PAIEMENT FACTURE
//       "Language".toLowerCase(): "FR",
//       "CallBackChannel".toLowerCase(): "3",
//       "CallBackDestination".toLowerCase(): "243811966923",
//       "Surname".toLowerCase(): "Vistal"
//     });
//     ////////////////////////////////////////////////////////////////////////////
//     // var url =
//     //     Uri.http("externalpay.zayaafrica.com", 'api/mpesa/c2bTransaction');
//     var url = Uri.http("numericafrika.com", 'paiementmpesa');
//     /////////////////////////////////////////////////////////////////////////////
//     http.Response response = await http.post(
//       url,
//       body: body,
//       headers: {
//         "Accept": "application/json",
//         "content-type": "application/json"
//       },
//     );
//     ///////////////////////////////////////////////////////////////////////////////
//     print(response.statusCode);
//     print(response.body.isNotEmpty);
//     //////////////////////////////////////    //////////////////////////////////////
//     setState(() {
//       if (response.body.isNotEmpty) {
//         datafrommpsa = jsonDecode(response.body);
//       } else {
//         print('null');
//       }
//     });
// //////////////////////////////////////////////////////////////////////////////////
//   }

//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     _getmpesa();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('MPesa test'),
//       ),
//       body: Center(
//           child: Container(
//         child: Text(datafrommpsa == null
//             ? 'Center'
//             : datafrommpsa["getEtat"].toString()),
//       )),
//     );
//   }
// }

// void main() => runApp(new MyApp());

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return new MaterialApp(
//       home: new MpesaPayement(
//         channel: new IOWebSocketChannel.connect("ws://echo.websocket.org"),
//       ),
//     );
//   }
// }
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

class MpesaPayement extends StatefulWidget {
  @override
  MpesaPayementState createState() {
    return new MpesaPayementState();
  }
}

class MpesaPayementState extends State<MpesaPayement> {
  var random = new Random();
  // int min = 10;
  // int max = 99;
  // var randomclient1 = 10 + random.nextInt(10 - 99);
  // var channel = IOWebSocketChannel.connect(
  //   Uri.http("wss://numericafrika.com", "paiementmpesa"),
  //   // headers: {"Accept": "application/json", "content-type": "application/json"},
  // );
//////////////////////////////////////////////////////////////////////////
  var channel = IOWebSocketChannel.connect(
    Uri.parse("wss://echo.websocket.org"),
    // headers: {"Accept": "application/json", "content-type": "application/json"},
  );
//////////////////////////////////////////////////////////////////////////
  var body = jsonEncode({
    "CustomerMSISDN".toLowerCase(): "243811966923",
    "Currency".toLowerCase(): "USD",
    "Amount".toLowerCase(): "1",
    "ThirdPartyReference".toLowerCase(): "9866",
    "Initials".toLowerCase(): "", // EX: PAIEMENT FACTURE
    "Language".toLowerCase(): "FR",
    "CallBackChannel".toLowerCase(): "3",
    "CallBackDestination".toLowerCase(): "243811966923",
    "Surname".toLowerCase(): "Vistal"
  });
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("MPesa"),
        backgroundColor: Colors.red,
        elevation: 0,
      ),
      body: new Padding(
        padding: const EdgeInsets.all(20.0),
        child: new Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            new StreamBuilder(
              stream: channel.stream,
              builder: (context, snapshot) {
                return snapshot.hasData
                    ? Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: new Text(snapshot.data.toString()),
                      )
                    : Center(
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
                        ),
                      );
              },
            )
          ],
        ),
      ),
      floatingActionButton: new FloatingActionButton(
        child: new Icon(Icons.send),
        onPressed: _sendDataToNumerica,
      ),
    );
  }

  void _sendDataToNumerica() {
    // channel.sink.add(body);
    // print('sent is my date');
    stompClient.activate();
    // stompClient.send(destination: ' /app/accueil', body: 'data');
  }

  @override
  void dispose() {
    channel.sink.close();
    super.dispose();
  }

  ////////////////////////////
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
}
