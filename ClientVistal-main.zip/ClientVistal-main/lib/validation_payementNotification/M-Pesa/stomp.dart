import 'dart:async';
import 'dart:convert';
import 'package:stomp_dart_client/stomp.dart';
import 'package:stomp_dart_client/stomp_config.dart';
import 'package:stomp_dart_client/stomp_frame.dart';

///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
void onConnect(StompFrame frame) {
  print('On connect is called....');
  stompClient.subscribe(
    destination: '/topic/client',
    callback: (frame) {
      List<dynamic>? result = json.decode(frame.body!);
      print('Voici le resultat: ' + result.toString());
    },
  );
////////////////////////////////////////////////////////////////////////////////////
  Timer.periodic(Duration(seconds: 10), (_) {
    stompClient.send(
      destination: '/app/accueil',
      body: 'DatasTest',
    );
  });
}

////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
final stompClient = StompClient(
  config: StompConfig(
    url: 'wss://numericafrika.com/paiements',
    // url: 'wss://echo.websocket.org',
    onConnect: onConnect,
    beforeConnect: () async {
      print('Be. waiting to connect...beforeconnexion');
      await Future.delayed(Duration(milliseconds: 200));
      print('Be. waiting to connect...');
    },
    onWebSocketError: (dynamic error) =>
        print('websocket says: ' + error.toString()),
    // stompConnectHeaders: {'Authorization': 'Bearer yourToken'},
    // webSocketConnectHeaders: {'Authorization': 'Bearer yourToken'},
  ),
);
///////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
var body = jsonEncode({
  "CustomerMSISDN".toLowerCase(): "243811966923",
  "Currency".toLowerCase(): "USD",
  "Amount".toLowerCase(): "1",
  "ThirdPartyReference".toLowerCase(): "9866",
  "Initials".toLowerCase(): "", // EX: PAIEMENT FACTURE
  "Language".toLowerCase(): "FR",
  "CallBackChannel".toLowerCase(): "3",
  "CallBackDestination".toLowerCase(): "243811966923",
  "Surname".toLowerCase(): "Vistal"
});
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////