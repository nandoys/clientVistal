import 'dart:math';
import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Searchsclasses/SearchAllProd.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
// import 'package:geolocator/geolocator.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';
import 'package:vistalapp/validation_payementNotification/validation.dart';
import 'package:location/location.dart';
import 'package:geocoder/geocoder.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';

class LastVerification extends StatefulWidget {
  final map;
  LastVerification({@required this.map});

  @override
  _LastVerificationState createState() => _LastVerificationState();
}

class _LastVerificationState extends State<LastVerification> {
  List<Map> panier = [];
  List<Map> allpod = [];
  Map etabnme = {};
  Map urlpro = {};
  Map points = {};
  late int markerId;
  TextEditingController arret = TextEditingController();
  TextEditingController ref = TextEditingController();
///////////////////////////////////////////////////////////////////////////////////////////////////
// final Geolocator geolocator = Geolocator();
  ///////////////////
  String _livraison = '';
  String comm = '';
  //////////////////////////////////////
  late int randomclient1, randomclient2;
  late int randomvendeur1, randomvendeur2;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////
  // LocationData _currentPositions;
  String _address = '';
  Location location = Location();
  getLoc() async {
    bool _serviceEnabled;
    PermissionStatus _permissionGranted;
    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }
    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }
    ///////////////////////////////////////////////////////////////////////////////////
    location.onLocationChanged.listen((LocationData currentLocation) {
      setState(() {
        _getAddress(currentLocation.latitude!, currentLocation.longitude!)
            .then((value) {
          setState(() {
            _address = "${value.first.locality} ${value.first.subLocality}";
          });
        });
      });
    });
  }

  Future<List<Address>> _getAddress(double lat, double lang) async {
    final coordinates = new Coordinates(lat, lang);
    List<Address> add =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    return add;
  }

///////////////////////////////////////////////////////////////////////////////////////////////////
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getLoc();
    ////////////get Random//////////////////
    setState(() {
      var random = new Random();
      int min = 10;
      int max = 99;
      randomclient1 = min + random.nextInt(max - min);
      randomvendeur1 = min + random.nextInt(max - min);
      randomclient2 = min + random.nextInt(max - min);
      randomvendeur2 = min + random.nextInt(max - min);
    });
    ///////////////////////////
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_panier.onChildRemoved.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = panier.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'],
          orElse: () {
            return eve;
          },
        );
        setState(() {
          if (old != null) {}
          panier.remove(old);
        });
      }
    });
    //////////////////////////////////////////// end commande ///////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      setState(() {
        allpod.add({
          'nom': event.snapshot.value['nom'],
          'idcat': event.snapshot.value['idcat'],
          'idetab': event.snapshot.value['idetab'],
          'desc': event.snapshot.value['desc'],
          'prix': event.snapshot.value['prix'],
          'visible': event.snapshot.value['visible'],
        });
      });
    });

    ///////////////////////////////////////////// Etab name ///////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        etabnme[event.snapshot.key] = event.snapshot.value['etabname'];
      });
    });
    ////////////////////////// prod url //////////////////////////////////////
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      setState(() {
        if (!urlpro.containsKey(event.snapshot.value['idprod'])) {
          urlpro[event.snapshot.value['idprod']] = event.snapshot.value['url'];
        }
      });
    });
    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      if (shareget('phone') == event.snapshot.key) {
        setState(() {
          points['pointgagne'] = event.snapshot.value['pointgagne'];
          points['pointutilise'] = event.snapshot.value['pointutilise'];
        });
      }
    });
    showDialogs(context, 5, 'Chargement');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'Récapitulatif',
            style: TextStyle(fontSize: 20),
          ),
          centerTitle: true,
          backgroundColor: Colors.red,
          elevation: 0,
          actions: [
            IconButton(
                icon: Icon(Icons.inventory_outlined),
                onPressed: () {
                  push(context, CallerCouserEtCommande());
                }),
            Stack(
              children: [
                Stack(
                  children: [
                    Padding(
                      padding:
                          const EdgeInsets.only(top: 5.0, left: 2, right: 4),
                      child: IconButton(
                          icon: Icon(Icons.local_grocery_store),
                          onPressed: panier.length != 0
                              ? () {
                                  push(
                                      context,
                                      Homepage(
                                          index: 3, page: 3, toseecat: null));
                                }
                              : () {}),
                    ),
                    panier.length != 0
                        ? Positioned(
                            top: 5,
                            left: 30,
                            child: Container(
                              alignment: Alignment.center,
                              child: Text(
                                '${panier.length}',
                                style: TextStyle(color: Colors.white),
                              ),
                              height: 20,
                              width: 20,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.black),
                            ),
                          )
                        : Container()
                  ],
                )
              ],
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: () {
                  showSearch(
                      context: context,
                      delegate: DataserachALLProd(
                          list: allpod, etabname: etabnme, urlprod: urlpro));
                },
                child: Container(
                  alignment: Alignment.center,
                  child: Container(
                    height: 29,
                    width: getwidth(context) * 0.96,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 10,
                        ),
                        Icon(
                          Icons.search,
                          color: Colors.red,
                        ),
                        Text(
                          'Rechercher un produit ',
                          style: TextStyle(color: Colors.grey),
                        )
                      ],
                    ),
                  ),
                  height: 50,
                  width: getwidth(context),
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          colors: [Colors.red, Colors.redAccent, Colors.red])),
                ),
              ),
              SizedBox(
                height: 5,
              ),

              /////////////////////////////////////////////////////////////////////////////////////////////////////
              Column(
                children: [
                  Card(
                    child: ListTile(
                      leading: Text('\#Article(s)'),
                      trailing: Text('${listtaille(widget.map['listprods'])}'),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      leading: Text('Etablissement'),
                      trailing: Text(
                        '${etabnme[widget.map['idetab']].toString().toUpperCase()}',
                        style: TextStyle(fontSize: 12),
                      ),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      leading: Text('Prix des articles'),
                      trailing: Text('${sumoflist(widget.map['listprods'])}\$'),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      leading: Text('Frais de livraison'),
                      trailing: Text('${widget.map['livraison']}\$'),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      leading: Text('Total à payer'),
                      trailing: Text(
                          '${double.parse(sumoflist(widget.map['listprods'])) + double.parse(widget.map['livraison'])}\$'),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      leading: Text('Mode de paiement'),
                      trailing: Text('${widget.map['payement']}'),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      title: Text('Adresse de livraison'),
                      subtitle: Text(
                        'Commune: ${widget.map['commune']}, Quartier: ${widget.map['quartier']}, Avenue: ${widget.map['avenue']}, N°${widget.map['numeroavenue']} , Référence: ${widget.map['ref']} ',
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  valideranuler(Colors.blue, () async {
                    await showDialogs(context, 3, 'Chargement');
                    if (widget.map['payement'] == 'PORTEFEUILLE') {
                      widget.map['livraison'] = '0';
                      await Vistal_SIMPLEUSER.child(shareget('phone')).update(
                          {'pointutilise': points['pointutilise'] + 10});
                    }
                    Vistal_Commandes.push().set(widget.map);
                    /////////////////////////// je vide le panier
                    for (final prod in widget.map['listprods']) {
                      Vistal_panier.child(prod['key']).remove();
                    }
                    Vistal_panier.push().set(widget.map);
                    push(context, CallerCouserEtCommande());
                    ///////////////// fin de vidage panier
                  }, 'Valider'),
                  /////////////////////////////////////////////////////////////////////////////
                  valideranuler(Colors.red, () async {
                    widget.map['etabTocken'] = widget.map['etabTocken'][0];
                    await showDialogs(context, 3, 'Chargement');
                    push(
                        context,
                        Validation(
                          map1: widget.map,
                          map2infopanier: widget.map,
                          returner: true,
                        ));
                  }, 'Modifier'),
                ],
              )
            ],
          ),
        ));
  }

  valideranuler(Color color, function, label) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: InkWell(
        onTap: function,
        child: Container(
          height: 50,
          width: getheight(context),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            label,
            style: TextStyle(color: Colors.white),
          ),
          alignment: Alignment.center,
        ),
      ),
    );
  }
}
