import 'dart:math';
import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Dashboard/You_searchepalce/lib/states/app_state.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/SeemoreProd.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Searchsclasses/SearchAllProd.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';
import 'package:vistalapp/validation_payementNotification/Payement.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:location/location.dart';
// import 'package:location/location.dart';
import 'package:intl/intl.dart';
// import 'package:location/location.dart';
import 'package:geocoder/geocoder.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
// import 'package:geocoding/geocoding.dart';

class Validation extends StatefulWidget {
  final map1;
  final map2infopanier;
  final returner;
  Validation(
      {@required this.map1,
      @required this.map2infopanier,
      @required this.returner});
  //{ 1. nbr article
  // 2. total
  // 3. key commnde
  //
  //}
  // const Validation({ Key? key }) : super(key: key);

  @override
  _ValidationState createState() => _ValidationState();
}

class _ValidationState extends State<Validation> {
  List<Map> panier = [];
  List<Map> allpod = [];
  Map etabnme = {};
  Map urlpro = {};
  List<String> tockens = [];
  TextEditingController quartier = TextEditingController();
  TextEditingController ref = TextEditingController();
  TextEditingController avenue = TextEditingController();
  TextEditingController numeroavenu = TextEditingController();
///////////////////////////////////////////////////////////////////////////////////////////////////
  // final Geolocator geolocator = Geolocator()..forceAndroidLocationManager;
  // late Position _currentPosition;
  late String _currentAddress;
  late int markerId;
  /////////////////////////////////////////////////////////////////////////////////////////////////////
  String _livraison = '';
  String comm = '';
  //////////////////////////////////////////////////////////////////////////////////////////////////////
  late int randomclient1, randomclient2;
  late int randomvendeur1, randomvendeur2;
  var random = new Random();
  var eve;
  late LatLng? _currentPositions;
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
  getLoc() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best);
    Coordinates? coordinates =
        Coordinates(position.latitude, position.longitude);
    ///////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////
    _getAddress(position.latitude, position.longitude).then((value) {
      setState(() {
        comm = "${value.first.subLocality}";
        _livraison = getcoutlivraison(comm);
        _currentPositions = LatLng(position.latitude, position.longitude);
      });
      //////////////////////////////////////////////////////////////////////////::::::::::::::::::::::::::::

      showDialog(
        context: context,
        builder: (_) {
          return StatefulBuilder(
              builder: (BuildContext context, StateSetter mystate) {
            return SimpleDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(20.0))),
              // contentPadding: EdgeInsets.only(top: 10.0),
              title: Text(
                'Votre adresse actuelle',
                style: TextStyle(
                    color: Colors.blueGrey,
                    fontWeight: FontWeight.w500,
                    fontSize: 15),
              ),
              children: [
                Card(
                  child: ListTile(
                    title: Text('ville'),
                    subtitle: Text('${value.first.locality.toString()}'),
                  ),
                ),
                Card(
                  child: ListTile(
                    title: Text('Commune'),
                    subtitle: Text('${value.first.subLocality.toString()}'),
                  ),
                ),
                Card(
                  child: ListTile(
                    title: Text('avenue'),
                    subtitle: Text(
                        '${getwalinstring(value.first.addressLine, ',').toString()}'),
                  ),
                ),
                Card(
                  child: ListTile(
                    title: Text('Quartier'),
                    subtitle: Text('${value.first.subThoroughfare.toString()}'),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: InkWell(
                        onTap: () {
                          pop(context);
                        },
                        child: Text(
                          'Non merci',
                          style: TextStyle(
                              color: Colors.red, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                    Container(),
                    Container(),
                    Container(),
                    Container(),
                    Container(),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: InkWell(
                        onTap: () {
                          mystate(() {
                            avenue.text =
                                getwalinstring(value.first.addressLine, ',')
                                    .toString();
                            quartier.text =
                                value.first.subThoroughfare.toString();
                            pop(context);
                          });
                        },
                        child: Text(
                          'Utiliser cette adresse',
                          style: TextStyle(
                              color: Colors.blue, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                )
              ],
            );
          });
        },
        //////////////////////////////////////////////////////////////////////////////////:
      );
    });
  }

  Future<List<Address>> _getAddress(double lat, double lang) async {
    final coordinates = new Coordinates(lat, lang);
    List<Address> add =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    return add;
  }

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // _getCurrentLocation();
    getLoc();
    ////////////get Random//////////////////
    setState(() {
      var random = new Random();
      int min = 10;
      int max = 99;
      randomclient1 = min + random.nextInt(max - min);
      randomvendeur1 = min + random.nextInt(max - min);
      randomclient2 = min + random.nextInt(max - min);
      randomvendeur2 = min + random.nextInt(max - min);
    });
    //////////////////////////////////////////////////////////////////////////////////////////////////
    // Vistal_SIMPLEUSER.onChildAdded.listen((event) {
    //   if (shareget('phone') == event.snapshot.key &&
    //       event.snapshot.value['quartier'] != null) {
    //     setState(() {
    //       quartier.text = event.snapshot.value['quartier'];
    //       avenue.text = event.snapshot.value['avenue'];
    //       numeroavenu.text = event.snapshot.value['numeroavenue'];
    //       ref.text = event.snapshot.value['ref'];
    //     });
    //   }
    // });
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_panier.onChildRemoved.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = panier.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'],
          orElse: () {
            return eve;
          },
        );
        setState(() {
          if (old != eve) {}
          panier.remove(old);
        });
      }
    });
    //////////////////////////////////////////// end commande ///////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      setState(() {
        allpod.add({
          'nom': event.snapshot.value['nom'],
          'idcat': event.snapshot.value['idcat'],
          'idetab': event.snapshot.value['idetab'],
          'desc': event.snapshot.value['desc'],
          'prix': event.snapshot.value['prix'],
          'visible': event.snapshot.value['visible'],
        });
      });
    });

    ///////////////////////////////////////////// Etab name ///////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        etabnme[event.snapshot.key] = event.snapshot.value['etabname'];
        etabnme['${event.snapshot.key}tocken}'] =
            event.snapshot.value['tocken'];
      });
    });
    ////////////////////////// prod url //////////////////////////////////////::::::::::::::
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      setState(() {
        if (!urlpro.containsKey(event.snapshot.value['idprod'])) {
          urlpro[event.snapshot.value['idprod']] = event.snapshot.value['url'];
        }
      });
    });
////////////////////// get all tocken ::::::::::::::::::::::::::::::::::::::::::::::::

    Vistal_Admin.onChildAdded.listen((event) {
      setState(() {
        tockens.add(event.snapshot.value['tocken']);
      });
    });
    Vistal_coursier.onChildAdded.listen((event) {
      setState(() {
        tockens.add(event.snapshot.value['tocken']);
      });
    });
    tockens.add(widget.map2infopanier['etabTocken']);
    //////////////////// fin tocken
  }

  // Future<void> getadresse() async {
  //   if (_currentAddress == null) {
  //     showDialogs(context, 5, 'Chargement');
  //   } else {

  //     setState(() {
  //       comm = _currentAddress;
  //     });
  //   }
  // }
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'Adresse de livraison',
            style: TextStyle(fontSize: 14),
          ),
          // centerTitle: true,
          backgroundColor: Colors.red,
          elevation: 0,
          actions: [
            IconButton(
                icon: Icon(Icons.inventory_outlined),
                onPressed: () {
                  push(context, CallerCouserEtCommande());
                }),
            Stack(
              children: [
                Stack(
                  children: [
                    Padding(
                      padding:
                          const EdgeInsets.only(top: 5.0, left: 2, right: 4),
                      child: IconButton(
                          icon: Icon(Icons.local_grocery_store),
                          onPressed: panier.length != 0
                              ? () {
                                  push(
                                      context,
                                      Homepage(
                                          index: 3, page: 3, toseecat: null));
                                }
                              : () {}),
                    ),
                    panier.length != 0
                        ? Positioned(
                            top: 5,
                            left: 30,
                            child: Container(
                              alignment: Alignment.center,
                              child: Text(
                                '${panier.length}',
                                style: TextStyle(color: Colors.white),
                              ),
                              height: 20,
                              width: 20,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.black),
                            ),
                          )
                        : Container()
                  ],
                )
              ],
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: () {
                  showSearch(
                      context: context,
                      delegate: DataserachALLProd(
                          list: allpod, etabname: etabnme, urlprod: urlpro));
                },
                child: Container(
                  alignment: Alignment.center,
                  child: Container(
                    height: 29,
                    width: getwidth(context) * 0.96,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 10,
                        ),
                        Icon(
                          Icons.search,
                          color: Colors.red,
                        ),
                        Text(
                          'Rechercher un produit',
                          style: TextStyle(color: Colors.grey),
                        )
                      ],
                    ),
                  ),
                  height: 50,
                  width: getwidth(context),
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          colors: [Colors.red, Colors.redAccent, Colors.red])),
                ),
              ),
              SizedBox(
                height: 1,
              ),
              Row(
                children: [
                  SizedBox(
                    width: 7,
                  ),
                  Icon(Icons.airport_shuttle_sharp),
                  SizedBox(
                    width: 5,
                  ),
                  Text(
                    'Livraison de votre commande',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  )
                ],
              ),
              getrow(),
              Container(
                height: 10,
                width: getwidth(context),
                decoration: BoxDecoration(color: Colors.grey),
              ),
              SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(4),
                child: Container(
                  alignment: Alignment.center,
                  height: 40,
                  width: getwidth(context),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text(
                        'Livraison assurée par Vistal',
                        style: TextStyle(),
                      ),
                      Container(),
                      Container(),
                      Container(),
                      Image(
                        image: AssetImage('assets/logos/location.png'),
                        height: 30,
                        width: 30,
                      )
                    ],
                  ),
                  decoration: BoxDecoration(
                      color: Colors.grey,
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),

              ////////////////////////////////////////////////////////////////////////////////////////
              SizedBox(
                height: 1,
              ),
              Padding(
                padding: const EdgeInsets.all(4),
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(10.0)),
                  child: TextField(
                    controller: quartier,
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(16.0),
                      suffixIcon: Text(
                        'Quartier',
                        style: TextStyle(color: Colors.grey),
                      ),
                      prefixIcon: Container(
                        padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                        margin: const EdgeInsets.only(right: 4),
                        decoration: BoxDecoration(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(30.0),
                                bottomLeft: Radius.circular(30.0),
                                topRight: Radius.circular(30.0),
                                bottomRight: Radius.circular(10.0))),
                        child: Icon(
                          Icons.edit_location,
                          color: Colors.red.shade300,
                        ),
                      ),
                      hintText: "Quartier",
                      hintStyle: TextStyle(color: null),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30.0),
                          borderSide: BorderSide.none),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.1),
                    ),
                  ),
                ),
              ),

/////////////////////////////////////////////////////////////////////////////////////////////////:
              ////////////////////////////////////////////////////////////////////////////////////////
              SizedBox(
                height: 1,
              ),
              Padding(
                padding: const EdgeInsets.all(4),
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(10.0)),
                  child: TextField(
                    controller: avenue,
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(16.0),
                      suffixIcon: Text(
                        'Avenue',
                        style: TextStyle(color: Colors.grey),
                      ),
                      prefixIcon: Container(
                          padding:
                              const EdgeInsets.only(top: 16.0, bottom: 16.0),
                          margin: const EdgeInsets.only(right: 4),
                          decoration: BoxDecoration(
                              color: Colors.transparent,
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(30.0),
                                  bottomLeft: Radius.circular(30.0),
                                  topRight: Radius.circular(30.0),
                                  bottomRight: Radius.circular(10.0))),
                          child: Icon(
                            Icons.home,
                            color: Colors.red.shade300,
                          )),
                      hintText: "Avenue",
                      hintStyle: TextStyle(color: null),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30.0),
                          borderSide: BorderSide.none),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.1),
                    ),
                  ),
                ),
              ),
              ////////////////////////////////////////////////////////////////////////////////////////
              ////////////////////////////////////////////////////////////////////////////////////////
              SizedBox(
                height: 1,
              ),
              Padding(
                padding: const EdgeInsets.all(4),
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(10.0)),
                  child: TextField(
                    keyboardType: TextInputType.number,
                    controller: numeroavenu,
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(16.0),
                      suffixIcon: Text(
                        'N° de l\'avenue',
                        style: TextStyle(color: Colors.grey),
                      ),
                      prefixIcon: Container(
                          padding:
                              const EdgeInsets.only(top: 16.0, bottom: 16.0),
                          margin: const EdgeInsets.only(right: 4),
                          decoration: BoxDecoration(
                              color: Colors.transparent,
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(30.0),
                                  bottomLeft: Radius.circular(30.0),
                                  topRight: Radius.circular(30.0),
                                  bottomRight: Radius.circular(10.0))),
                          child: Icon(
                            Icons.location_searching_sharp,
                            color: Colors.red.shade300,
                          )),
                      hintText: "N° de l\'avenue",
                      hintStyle: TextStyle(color: null),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30.0),
                          borderSide: BorderSide.none),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.1),
                    ),
                  ),
                ),
              ),
              ///////////////////////////////////////////////////////////////////////////////////////
              SizedBox(
                height: 1,
              ),
              Padding(
                padding: const EdgeInsets.all(4),
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(10.0)),
                  child: TextField(
                    controller: ref,
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(16.0),
                      suffixIcon: Text(
                        'Référence',
                        style: TextStyle(color: Colors.grey),
                      ),
                      prefixIcon: Container(
                          padding:
                              const EdgeInsets.only(top: 16.0, bottom: 16.0),
                          margin: const EdgeInsets.only(right: 4),
                          decoration: BoxDecoration(
                              color: Colors.transparent,
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(30.0),
                                  bottomLeft: Radius.circular(30.0),
                                  topRight: Radius.circular(30.0),
                                  bottomRight: Radius.circular(10.0))),
                          child: Icon(
                            Icons.location_city,
                            color: Colors.red.shade300,
                          )),
                      hintText: "Référence",
                      hintStyle: TextStyle(color: null),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30.0),
                          borderSide: BorderSide.none),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.1),
                    ),
                  ),
                ),
              ),
              ////////////////////////////////////////////////////////////////////////////
              Padding(
                padding: const EdgeInsets.all(4),
                child: InkWell(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (_) {
                        return StatefulBuilder(builder:
                            (BuildContext context, StateSetter mystate) {
                          return SimpleDialog(
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10.0))),
                            // contentPadding: EdgeInsets.only(top: 10.0),
                            children: [
                              commune('Ngaliema', () {
                                setState(() {
                                  comm = 'Ngaliema';
                                  _livraison = '3';
                                  print(comm);
                                  pop(context);
                                });
                              }),
                              commune('Limete', () {
                                setState(() {
                                  comm = 'Limete';
                                  _livraison = '3';

                                  print(comm);
                                  pop(context);
                                });
                              }),
                              commune('Selembao', () {
                                setState(() {
                                  comm = 'Selembao';
                                  _livraison = '3';

                                  pop(context);
                                });
                              }),
                              commune('Gombe', () {
                                setState(() {
                                  comm = 'Gombe';
                                  _livraison = '3';

                                  pop(context);
                                });
                              }),
                              commune('Kintambo', () {
                                setState(() {
                                  comm = 'Kintambo';
                                  _livraison = '3';

                                  pop(context);
                                });
                              }),
                              commune('Bandalungwa', () {
                                setState(() {
                                  comm = 'Bandalungwa';
                                  _livraison = '3';

                                  pop(context);
                                });
                              }),
                              commune('Kinshasa', () {
                                setState(() {
                                  comm = 'Kinshasa';
                                  _livraison = '3';

                                  pop(context);
                                });
                              }),
                              commune('Kasavubu', () {
                                setState(() {
                                  comm = 'Kasavubu';
                                  _livraison = '3';
                                  pop(context);
                                });
                              }),
                              commune('Mont Ngafula', () {
                                setState(() {
                                  comm = 'Mont Ngafula';
                                  _livraison = '5';

                                  pop(context);
                                });
                              }),
                              commune('Masina', () {
                                setState(() {
                                  comm = 'Masina';
                                  _livraison = '5';

                                  pop(context);
                                });
                              }),
                              commune('Ndjili', () {
                                setState(() {
                                  comm = 'Ndjili';
                                  _livraison = '5';

                                  pop(context);
                                });
                              }),
                            ],
                          );
                        });
                      },
                      //////////////////////////////////////////////////////////////////////////////////:
                    );
                  },
                  child: Container(
                    alignment: Alignment.centerLeft,
                    height: 40,
                    width: getwidth(context) / 1.05,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Icon(Icons.pin_drop),
                          Text(
                            ' Commune: ' + comm.toString(),
                            style: TextStyle(color: null),
                          ),
                          Container(),
                          Container(),
                          Container(),
                          Text(
                            'Modifier',
                            style: TextStyle(color: Colors.white),
                          )
                        ],
                      ),
                    ),
                    decoration: BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
/////////////////////////////////////////////////////////////////////////////////////////////////:
              SizedBox(
                height: 40,
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(
                    'Coût de livraison',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Container(),
                  Container(),
                  Container(),
                  Container(),
                  Container(),
                  Text(
                    _livraison == null ? '...' : _livraison.toString() + '\$',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(
                height: 60,
              ),
              InkWell(
                onTap: () async {
                  if (quartier.text.isNotEmpty &&
                      ref.text.isNotEmpty &&
                      avenue.text.isNotEmpty &&
                      numeroavenu.text.isNotEmpty &&
                      comm.isNotEmpty &&
                      _livraison.isNotEmpty) {
                    widget.map2infopanier['statut'] = 'Traitement...';
                    widget.map2infopanier['supprimerfromclient'] = 'false';
                    widget.map2infopanier['supprimerfromVistal'] = 'false';
                    widget.map2infopanier['commune'] = comm;
                    widget.map2infopanier['phonetocall'] = '';
                    widget.map2infopanier['quartier'] = quartier.text;
                    widget.map2infopanier['numeroavenue'] = numeroavenu.text;
                    widget.map2infopanier['avenue'] = avenue.text;
                    widget.map2infopanier['ref'] = ref.text;
                    widget.map2infopanier['userlongitude'] =
                        _currentPositions!.longitude.toString();
                    widget.map2infopanier['userlatitude'] =
                        _currentPositions!.latitude.toString();
                    widget.map2infopanier['codeConfClient'] = '';
                    widget.map2infopanier['codeConfVendeur'] = '';
                    widget.map2infopanier['paye_vistal'] = 'Non payé';
                    widget.map2infopanier['paye_coursier'] = 'Non payé';
                    widget.map2infopanier['CodeClient'] =
                        (randomclient1.toString() + randomclient2.toString())
                            .toString();
                    widget.map2infopanier['CodeVendeur'] =
                        (randomvendeur1.toString() + randomvendeur2.toString())
                            .toString();
                    widget.map2infopanier['livraison'] = _livraison.toString();
                    widget.map2infopanier['userphone'] = shareget('phone');
                    widget.map2infopanier['etabTocken'] = tockens;
/////////////////////////////////////////////////////////////////////
                    Vistal_SIMPLEUSER.child(shareget('phone')).update({
                      'quartier': quartier.text,
                      'avenue': avenue.text,
                      'ref': ref.text,
                      'numeroavenue': numeroavenu.text
                    });
//////////////////////////////////////////////////////////////////////////////
                    await showDialogs(context, 4, 'Chargement');
                    push(context,
                        ComptePayement(infopanier: widget.map2infopanier));
                    setState(() {
                      quartier.text = '';
                      ref.text = '';
                      comm = '';
                      _livraison = '';
                      avenue.text = '';
                      numeroavenu.text = '';
                    });
                  } else {
                    showDialog(
                      context: context,
                      builder: (_) {
                        return StatefulBuilder(builder:
                            (BuildContext context, StateSetter mystate) {
                          return SimpleDialog(
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20.0))),
                            // contentPadding: EdgeInsets.only(top: 10.0),
                            title: Text(
                              'Informations incomplètes',
                              style: TextStyle(
                                  color: Colors.red,
                                  fontWeight: FontWeight.w400),
                            ),
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(14),
                                child: Text(
                                    'Veuillez fournir votre adresse complète de livraison pour continuer'),
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Container(),
                                  Container(),
                                  Container(),
                                  Container(),
                                  Container(),
                                  Container(),
                                  InkWell(
                                    onTap: () {
                                      pop(context);
                                    },
                                    child: Text(
                                      'Ok',
                                      style: TextStyle(
                                          color: Colors.red,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ],
                              )
                            ],
                          );
                        });
                      },
                      //////////////////////////////////////////////////////////////////////////////////:
                    );
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.all(4),
                  child: Container(
                    alignment: Alignment.center,
                    height: 40,
                    width: getwidth(context) / 1.2,
                    child: Text(
                      'Valider la commande',
                      style: TextStyle(color: Colors.white),
                    ),
                    decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(20)),
                  ),
                ),
              ),
/////////////////////////////////////////////////////////////////////////////////////////////////:

              Container(
                height: 10,
                width: getwidth(context),
                decoration: BoxDecoration(color: Colors.grey),
              ),
              // getrow()
            ],
          ),
        ));
  }

///////////////////////////////////////////////////////////////////////////////////////////////////////:::
///////////////////////////////////////////////////////////////////////////////////////////////////////:::
///////////////////////////////////////////////////////////////////////////////////////////////////////:::
///////////////////////////////////////////////////////////////////////////////////////////////////////:::
  ///
  getrow() {
    return Card(
      elevation: 0.5,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Column(
            children: [
              Text(
                'Panier(s)',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                '1',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          Container(
            height: 20,
            width: 1,
            color: Colors.blueGrey,
          ),
          Column(
            children: [
              Text(
                'Article(s)',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                '${listtaille(widget.map2infopanier['listprods'])}',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          Container(
            height: 20,
            width: 1,
            color: Colors.blueGrey,
          ),
          Column(
            children: [
              Text(
                'Total',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                '${sumoflist(widget.map2infopanier['listprods'])}\$',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ],
      ),
    );
  }

  commune(commune, ontap) {
    return Card(child: ListTile(onTap: ontap, title: Text(commune)));
  }
}
