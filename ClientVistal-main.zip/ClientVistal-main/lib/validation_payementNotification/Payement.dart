import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Facture_pdf/api/pdf_api.dart';
import 'package:vistalapp/Facture_pdf/api/pdf_invoice_api.dart';
import 'package:vistalapp/Facture_pdf/model/customer.dart';
import 'package:vistalapp/Facture_pdf/model/invoice.dart';
import 'package:vistalapp/Facture_pdf/model/supplier.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Searchsclasses/SearchAllProd.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/Facture_pdf/api/pdf_api.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:vistalapp/validation_payementNotification/LastVerification.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';

class ComptePayement extends StatefulWidget {
  final infopanier;
  ComptePayement({@required this.infopanier});
  //{ 1. nbr article
  // 2. total
  // 3. key commnde
  //
  //}
  // const ComptePayement({ Key? key }) : super(key: key);

  @override
  _ComptePayementState createState() => _ComptePayementState();
}

class _ComptePayementState extends State<ComptePayement> {
  List<Map> panier = [];
  List<Map> allpod = [];
  Map etabnme = {};
  Map urlpro = {};
  Map points = {};
  var eve;

  TextEditingController adresse = TextEditingController();
  TextEditingController ref = TextEditingController();
//////////////////////////////////////////////////////////////////////
  String _moyenpayement = '';
  String paye = '';
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_panier.onChildRemoved.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = panier.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'],
          orElse: () {
            return eve;
          },
        );
        setState(() {
          if (old != eve) {}
          panier.remove(old);
        });
      }
    });
    //////////////////////////////////////////// end commande ///////////////////////////////////
    Vistal_Produits.onChildAdded.listen((event) {
      setState(() {
        allpod.add({
          'nom': event.snapshot.value['nom'],
          'idcat': event.snapshot.value['idcat'],
          'idetab': event.snapshot.value['idetab'],
          'desc': event.snapshot.value['desc'],
          'prix': event.snapshot.value['prix'],
          'visible': event.snapshot.value['visible'],
        });
      });
    });

    ///////////////////////////////////////////// Etab name ///////////////////////////
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        etabnme[event.snapshot.key] = event.snapshot.value['etabname'];
      });
    });
    ////////////////////////// prod url //////////////////////////////////////
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      setState(() {
        if (!urlpro.containsKey(event.snapshot.value['idprod'])) {
          urlpro[event.snapshot.value['idprod']] = event.snapshot.value['url'];
        }
      });
    });
    ///////////////////////////////////////////////////////////////////////////
    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      if (shareget('phone') == event.snapshot.key) {
        setState(() {
          points['pointgagne'] = event.snapshot.value['pointgagne'];
          points['pointutilise'] = event.snapshot.value['pointutilise'];
        });
      }
    });
    Vistal_SIMPLEUSER.onChildChanged.listen((event) {
      if (shareget('phone') == event.snapshot.key) {
        setState(() {
          points['pointgagne'] = event.snapshot.value['pointgagne'];
          points['pointutilise'] = event.snapshot.value['pointutilise'];
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Régler ma commande',
          style: TextStyle(fontSize: 14),
        ),
        centerTitle: true,
        backgroundColor: Colors.red,
        elevation: 0,
        actions: [
          IconButton(
              icon: Icon(Icons.inventory_outlined),
              onPressed: () {
                push(context, CallerCouserEtCommande());
              }),
          Stack(
            children: [
              Stack(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 5.0, left: 2, right: 4),
                    child: IconButton(
                        icon: Icon(Icons.local_grocery_store),
                        onPressed: panier.length != 0
                            ? () {
                                push(
                                    context,
                                    Homepage(
                                        index: 3, page: 3, toseecat: null));
                              }
                            : () {}),
                  ),
                  panier.length != 0
                      ? Positioned(
                          top: 5,
                          left: 30,
                          child: Container(
                            alignment: Alignment.center,
                            child: Text(
                              '${panier.length}',
                              style: TextStyle(color: Colors.white),
                            ),
                            height: 20,
                            width: 20,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.black),
                          ),
                        )
                      : Container()
                ],
              )
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            InkWell(
              onTap: () {
                showSearch(
                    context: context,
                    delegate: DataserachALLProd(
                        list: allpod, etabname: etabnme, urlprod: urlpro));
              },
              child: Container(
                alignment: Alignment.center,
                child: Container(
                  height: 29,
                  width: getwidth(context) * 0.96,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 10,
                      ),
                      Icon(
                        Icons.search,
                        color: Colors.red,
                      ),
                      Text(
                        'Rechercher un produit',
                        style: TextStyle(color: Colors.grey),
                      )
                    ],
                  ),
                ),
                height: 50,
                width: getwidth(context),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        colors: [Colors.red, Colors.redAccent, Colors.red])),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              children: [
                SizedBox(
                  width: 7,
                ),
                Icon(Icons.mobile_friendly_sharp),
                SizedBox(
                  width: 5,
                ),
                Text(
                  'Mode de paiement',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(28.0),
              child: Text(
                'Selectionner le moyen de paiement',
                style: TextStyle(
                    fontWeight: FontWeight.w600, color: Colors.blueGrey),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                child: ListTile(
                  leading: Radio(
                      activeColor: Colors.red,
                      value: 'CASH',
                      groupValue: _moyenpayement,
                      onChanged: (val) {
                        setState(() {
                          _moyenpayement = val.toString();
                        });
                      }),
                  title: Text('Cash à la livraison'),
                  trailing: Image(
                    image: AssetImage('assets/logos/location.png'),
                    height: 30,
                    width: 30,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                child: ListTile(
                  leading: Radio(
                      activeColor: Colors.red,
                      value: 'PORTEFEUILLE',
                      groupValue: _moyenpayement,
                      onChanged: (val) {
                        setState(() {
                          _moyenpayement = val.toString();
                        });
                      }),
                  title: Text('Portefeuille Vistal', style: TextStyle()),
                  trailing: Image(
                    image: AssetImage('assets/logos/wallet.png'),
                    height: 30,
                    width: 30,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                child: ListTile(
                  leading: Radio(
                      activeColor: Colors.red,
                      value: 'MPESA',
                      groupValue: _moyenpayement,
                      onChanged: (val) {
                        setState(() {
                          _moyenpayement = val.toString();
                        });
                      }),
                  title: Text(' M-PESA'),
                  trailing: Image(
                    image: AssetImage('assets/logos/mpsa.PNG'),
                    height: 30,
                    width: 30,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                child: ListTile(
                  leading: Radio(
                      activeColor: Colors.red,
                      value: 'VISA',
                      groupValue: _moyenpayement,
                      onChanged: (val) {
                        setState(() {
                          _moyenpayement = val.toString();
                        });
                      }),
                  title: Text('Visa, MasterCard'),
                  trailing: Image(
                    image: AssetImage('assets/logos/visa.png'),
                    height: 30,
                    width: 30,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      /////////////////////////////////////////////////////////////////////////////////////////////////////////
      /////////////////////////////////////////////////////////////////////////////////////////////////////////
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.red,
        onPressed: () async {
          if (_moyenpayement.isNotEmpty) {
            if (_moyenpayement == 'CASH' || _moyenpayement == 'PORTEFEUILLE') {
              if (_moyenpayement == 'PORTEFEUILLE') {
                if ((points['pointgagne'] - points['pointutilise']) < 10) {
                  // si le portefuille n'est pas suffisant
                  showDialog(
                    context: context,
                    builder: (_) {
                      return StatefulBuilder(
                          builder: (BuildContext context, StateSetter mystate) {
                        return SimpleDialog(
                          shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(20.0))),
                          // contentPadding: EdgeInsets.only(top: 10.0),
                          title: Text(
                            'Solde insuffisant',
                            style: TextStyle(
                                color: Colors.red, fontWeight: FontWeight.w400),
                          ),
                          children: [
                            Padding(
                                padding: const EdgeInsets.all(14),
                                child: Text(
                                  'Votre solde  n\'est pas suffisant pour cette commande. Vous disposez de ${(points['pointgagne'] - points['pointutilise']).toString()} point(s). Il vous faut au moins 10 points pour une livraison gratuite.',
                                )),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Container(),
                                Container(),
                                Container(),
                                Container(),
                                Container(),
                                Container(),
                                InkWell(
                                  onTap: () {
                                    pop(context);
                                  },
                                  child: Text(
                                    'Ok',
                                    style: TextStyle(
                                        color: Colors.red,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ],
                            )
                          ],
                        );
                      });
                    },
                    //////////////////////////////////////////////////////////////////////////////////:
                  );
                } else {
                  // portefeuille plein
                  widget.infopanier['payement'] = _moyenpayement;
                  widget.infopanier['livraison'] = '0';
                  widget.infopanier['date'] = DateTime.now().toString();
                  await showDialogs(context, 4, 'Chargement');
                  push(
                      context,
                      LastVerification(
                        map: widget.infopanier,
                      ));
                }
              }
              //////////////////////////////////////// si paaiement est en cash
              if (_moyenpayement == 'CASH') {
                print(points['pointutilise']);
                widget.infopanier['payement'] = _moyenpayement;
                widget.infopanier['date'] = DateTime.now().toString();
                await showDialogs(context, 4, 'Chargement');
                push(
                    context,
                    LastVerification(
                      map: widget.infopanier,
                    ));
              }
            } else {
              // voie electronique
            }
          } else {
            showDialog(
              context: context,
              builder: (_) {
                return StatefulBuilder(
                    builder: (BuildContext context, StateSetter mystate) {
                  return SimpleDialog(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(20.0))),
                    // contentPadding: EdgeInsets.only(top: 10.0),
                    title: Text(
                      'Aucun moyen de payemet choisi',
                      style: TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(18.0),
                        child: Text(
                            'Selectionnez un moyen de payement et réessayer'),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Container(),
                          Container(),
                          Container(),
                          Container(),
                          Container(),
                          Container(),
                          InkWell(
                            onTap: () {
                              pop(context);
                            },
                            child: Text(
                              'Ok',
                              style: TextStyle(
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      )
                    ],
                  );
                });
              },
              //////////////////////////////////////////////////////////////////////////////////:
            );
          }
        },
        child: Icon(Icons.check),
      ),
    );
  }
}
