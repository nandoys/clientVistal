import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';


class DetailCommande extends StatefulWidget {
  final list;
  DetailCommande({@required this.list});
  @override
  _DetailCommandeState createState() => _DetailCommandeState();
}

class _DetailCommandeState extends State<DetailCommande> {
  List<Event> commandes = [];
  Map urlvendeur = {};
  Map namevendeur = {};
  Map namecoursiers = {};
  Map urlprod = {};
  Map nomprod = {};
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Vistal_vendeur_profil_photo.onChildAdded.listen((event) {
      setState(() {
        urlvendeur[event.snapshot.key] = event.snapshot.value['url'];
      });
    });
    Vistal_Vendeur.onChildAdded.listen((event) {
      setState(() {
        namevendeur[event.snapshot.key] = event.snapshot.value['nom'];
      });
    });
    //////////////////////////////////////////////////////////////////////////////////////////
    Vistal_Commandes.onChildAdded.listen((event) {
      if (event.snapshot.value['date'].toString().substring(0, 10) ==
              DateTime.now().toString().substring(0, 10) &&
          event.snapshot.value['idetab'] == shareget('username') &&
          event.snapshot.value['statut'] != 'Livré') {
        setState(() {
          commandes.add(event);
        });
      }
    });
    Vistal_Commandes.onChildChanged.listen((event) {
      // if (event.snapshot.value['date'].toString().substring(0, 10) ==
      //         DateTime.now().toString().substring(0, 10) &&
      //     event.snapshot.value['idcoursier'] == shareget('username')) {
      //   setState(() {
      //     if (event.snapshot.value['statut'] != 'Livré') {
      //       statutcoursier = 'Occupé';
      //     }
      //     if (event.snapshot.value['statut'] != 'Livré') {
      //       statutcoursier = 'Libre';
      //     }
      //   });
      // }
      setState(() {
        Event eve = event;
        var old = commandes.firstWhere(
          (element) => element.snapshot.key == event.snapshot.key,
          orElse: () {
            return eve;
          },
        );
        if (old != eve) {
          commandes.remove(old);
          commandes.add(event);
        }
      });
    });
    Vistal_coursier.onChildAdded.listen((event) {
      setState(() {
        namecoursiers[event.snapshot.key] =
            event.snapshot.value['prenom'] + ' ' + event.snapshot.value['nom'];
      });
    });
    //////////////////////////////////////////////////////////////////////////////////////////
    Vistal_ImageOfProduits.onChildAdded.listen((event) {
      setState(() {
        if (!urlprod.containsKey(
            '${event.snapshot.value['idprod'] + event.snapshot.value['idetab']}'
                .trim())) {
          urlprod[event.snapshot.value['idprod'].toString() +
                  event.snapshot.value['idetab'].toString().trim()] =
              event.snapshot.value['url'];
        }
      });
    });
    Vistal_Produits.onChildAdded.listen((event) {
      setState(() {
        nomprod[event.snapshot.value['nom'] + event.snapshot.value['idetab']] =
            event.snapshot.value['nom'];
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        elevation: 0,
        title: Text(
          'Liste de produits de la comande',
          style: TextStyle(fontSize: 12),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 40,
              width: getwidth(context),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Liste de produits de la commande',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              alignment: Alignment.centerLeft,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(0), color: Colors.black),
            ),
            Divider(),
            for (final prod in widget.list)
              Card(
                child: ListTile(
                  leading: Container(
                    height: 50.0,
                    width: 50.0,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: urlprod[prod['idprod'] + prod['idetab']] != null
                          ? CachedNetworkImage(
                              filterQuality: FilterQuality.medium,
                              fit: BoxFit.fill,
                              imageUrl: urlprod[prod['idprod'] + prod['idetab']]
                                  .toString(),
                              placeholder: (BuildContext context, String url) {
                                return Center(
                                  child: SkeletonContainer.rounded(
                                    height: 50.0,
                                    width: 50.0,
                                  ),
                                );
                              },
                            )
                          : Container(),
                    ),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.pink, width: 1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  title: Text('${nomprod[prod['idprod'] + prod['idetab']]}'),
                  subtitle: Text(' Quantité: ${prod['qt']}'),
                  trailing: Text(' Total: ${prod['prix_total']}\$'),
                ),
              ),
            Container(
              height: 50,
              width: getwidth(context),
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Total: ${sumoflist(widget.list)}\$',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              decoration: BoxDecoration(
                color: Colors.black,
              ),
            )
          ],
        ),
      ),
    );
  }
}
