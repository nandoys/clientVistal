// @dart=2.9
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/Two_of_staggered.dart';
import 'Auth_splash/Beforelog/Splash.dart';
import 'Dashboard/You_searchepalce/lib/states/app_state.dart';
import 'Settings_Routine/Settings.dart';
import 'package:firebase_phone_auth_handler/firebase_phone_auth_handler.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
// import 'package:flutter_progress_dialog/flutter_progress_dialog.dart';
import 'package:get_storage/get_storage.dart';
import 'package:vistalapp/connectivity/connectivity_service.dart';
import 'package:provider/provider.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/two_separete.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/detail_prod_ui.dart';
import 'dart:math';
import 'package:vistalapp/validation_payementNotification/M-Pesa/PayementMpesa.dart';

main(List<String> args) async {
  intuserandfirebase();
  await GetStorage.init();
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(
        value: AppState(),
      ),
      // ChangeNotifierProvider(
      //   create: (context) => ApplicationBloc(),
      // ),
      ///////////////////////////////////////////////////////////////
      StreamProvider<ConnectivityStatus>.value(
        value: ConnectivityService().connectionStatusController.stream,
        initialData: ConnectivityStatus.Offline,
      )
    ],
    child: FirebasePhoneAuthProvider(
      child: GetMaterialApp(
        debugShowCheckedModeBanner: false,
        // theme: dark ? ThemeData.dark() : ThemeData.light(),
        home: Splash(),
        // home: MpesaPayement(),
        // home: MyHomePage(),
        // home: HomeScreen(),
        // home: TestMpesa(),
      ),
    ),
  ));
}

//AIzaSyAi04dhThv5DBboLvTe3ysSNradOoZka4g :  new
//AIzaSyDWfxmdMmsD-ge5NLCGKCVJ4CCJAbwiNjw : old
///////////////////////////////////////////////////////////////////////////////////////////////////::
///////////////////////////////////////////////////////////////////////////////////////////////////::
///////////////////////////////////////////////////////////////////////////////////////////////////::
///////////////////////////////////////////////////////////////////////////////////////////////////::
///////////////////////////////////////////////////////////////////////////////////////////////////::
///////////////////////////////////////////////////////////////////////////////////////////////////::
///////////////////////////////////////////////////////////////////////////////////////////////////::
///////////////////////////////////////////////////////////////////////////////////////////////////::
///////////////////////////////////////////////////////////////////////////////////////////////////::
///////////////////////////////////////////////////////////////////////////////////////////////////::
///////////////////////////////////////////////////////////////////////////////////////////////////::

