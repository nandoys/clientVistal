import 'package:flutter/material.dart';
import 'package:vistalapp/Dashboard/CallerDash.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/SeemoreProd.dart';
import 'package:vistalapp/Dashboard/articles/Poduct_ui/ui_list_prod.dart';
import 'package:vistalapp/ListCommadeETcourse/Caller.dart';
import 'package:vistalapp/Settings_Routine/Dialogs_push.dart';
import 'package:vistalapp/Settings_Routine/Settings.dart';
import 'package:vistalapp/upload_image/firebase_storage_services.dart';
import 'package:vistalapp/upload_image/skeleton_like_shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:vistalapp/ListCommadeETcourse/ListeCommandes.dart';

class UserProfil extends StatefulWidget {
  // const UserProfil({ Key? key }) : super(key: key);

  @override
  _UserProfilState createState() => _UserProfilState();
}

class _UserProfilState extends State<UserProfil> {
  bool _saving = false;
  String urlprof = eve, urlcouv = eve;
  Map infouser = {};
  TextEditingController nom = TextEditingController();
  TextEditingController prenom = TextEditingController();
  List<Map> panier = [];
  List<Map> allfav = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Image_profil_vistal.onChildAdded.listen((event) {
      if (event.snapshot.key == shareget('phone')) {
        print('profil vu');
        setState(() {
          urlprof = event.snapshot.value['url'];
        });
      }
    });
    Image_profil_vistal.onChildChanged.listen((event) {
      if (event.snapshot.key == shareget('phone')) {
        print('profil vu');
        setState(() {
          urlprof = event.snapshot.value['url'];
        });
      }
    });
    ////////////////////////////////////////////////////////////////////
    Image_couverture_vistal.onChildAdded.listen((event) {
      if (event.snapshot.key == shareget('phone')) {
        print('couve vu');
        setState(() {
          urlcouv = event.snapshot.value['url'];
        });
      }
    });
    ///////////////////////////////////////
    Image_couverture_vistal.onChildChanged.listen((event) {
      if (event.snapshot.key == shareget('phone')) {
        print('couve vu');
        setState(() {
          urlcouv = event.snapshot.value['url'];
        });
      }
    });
    //////////////////////////////////////////////
    Vistal_SIMPLEUSER.onChildAdded.listen((event) {
      if (event.snapshot.key == shareget('phone')) {
        setState(() {
          infouser = {
            'nom': event.snapshot.value['nom'],
            'prenom': event.snapshot.value['prenom'],
          };
        });
      }
    });
    Vistal_SIMPLEUSER.onChildChanged.listen((event) {
      if (event.snapshot.key == shareget('phone')) {
        setState(() {
          infouser = {
            'nom': event.snapshot.value['nom'],
            'prenom': event.snapshot.value['prenom'],
          };
        });
      }
    });

    ////////////////////////////////////////////:panier::::///////////////////////////////////////////////////
    Vistal_panier.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          panier.add({
            'phone': event.snapshot.value['phone'],
            'idprod': event.snapshot.value['idprod'],
            'idetab': event.snapshot.value['idetab']
          });
        });
      }
    });
    /////////////////////////////////////////////////////////////////////////////////////////////
    Vistal_panier.onChildRemoved.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        var old = panier.firstWhere(
          (element) =>
              element['phone'] == event.snapshot.value['phone'] &&
              element['idprod'] == event.snapshot.value['idprod'],
          orElse: () {
            return eve;
          },
        );
        setState(() {
          if (old != eve) {}
          panier.remove(old);
        });
      }
    });
    //////////////////////////////////////////// end commande ///////////////////////////////////

    Vistal_Favorits_produits.onChildAdded.listen((event) {
      if (event.snapshot.value['phone'] == shareget('phone')) {
        setState(() {
          allfav.add({
            'idetab': event.snapshot.value['idetab'],
            'idprod': event.snapshot.value['idprod'],
            'phone': event.snapshot.value['phone'],
          });
        });
      }
    });
    Vistal_Favorits_produits.onChildRemoved.listen((event) {
      var old = allfav.firstWhere(
        (element) =>
            element['phone'] == event.snapshot.value['phone'] &&
            element['idprod'] == event.snapshot.value['idprod'] &&
            element['idetab'] == event.snapshot.value['idetab'],
        orElse: () {
          return eve;
        },
      );
      if (old != null) {
        setState(() {
          allfav.remove(old);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.red,
          elevation: 0,
          title: Text('Mon profil'),
          actions: [
            IconButton(
                icon: Icon(Icons.inventory_outlined),
                onPressed: () {
                  push(context, CallerCouserEtCommande());
                }),
            Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 5.0, left: 2, right: 4),
                  child: IconButton(
                      icon: Icon(Icons.local_grocery_store),
                      onPressed: () {
                        push(context,
                            Homepage(index: 3, page: 3, toseecat: null));
                      }),
                ),
                panier.length != 0
                    ? Positioned(
                        top: 5,
                        left: 30,
                        child: Container(
                          alignment: Alignment.center,
                          child: Text(
                            '${panier.length}',
                            style: TextStyle(color: Colors.white),
                          ),
                          height: 20,
                          width: 20,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.black),
                        ),
                      )
                    : Container()
              ],
            ),
          ]),
      body: infouser.isNotEmpty
          ? ModalProgressHUD(
              inAsyncCall: _saving,
              progressIndicator: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
              ),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: 5,
                    ),
                    /////////////////////////// couverture .////////////////////////////////////////////////////
                    Stack(
                      overflow: Overflow.visible,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            height: 150,
                            width: getwidth(context),
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.grey, width: 0.4),
                                color: Colors.transparent,
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(10),
                                    topRight: Radius.circular(10))),
                            child: ClipRRect(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20)),
                                child: urlcouv != eve
                                    ? CachedNetworkImage(
                                        filterQuality: FilterQuality.medium,
                                        fit: BoxFit.fill,
                                        imageUrl: urlcouv,
                                        placeholder:
                                            (BuildContext context, String url) {
                                          return Center(
                                            child: SkeletonContainer.rounded(
                                              height: getheight(context) * 0.3,
                                              width: double.infinity,
                                            ),
                                          );
                                        },
                                      )
                                    : Container(
                                        height: 150,
                                        width: getwidth(context),
                                        color: Colors.grey,
                                      )),
                          ),
                        ),
                        ///////////////// camera couverture
                        Positioned(
                            top: 110,
                            left: 300,
                            child: Container(
                              alignment: Alignment.center,
                              height: 39,
                              width: 39,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                      color: Colors.red.shade300, width: 1)),
                              child: IconButton(
                                  icon: Icon(
                                    Icons.photo_camera,
                                    // size: 70,
                                    color: Colors.black,
                                  ),
                                  onPressed: () async {
                                    var image;
                                    var url;
                                    image =
                                        await pickImageandcompress(1, context);
                                    if (image != null) {
                                      setState(() {
                                        _saving = true;
                                      });
                                      url = await sendimage(
                                          image, 'UserCouverture');
                                      Image_couverture_vistal.child(
                                              shareget('phone'))
                                          .update({
                                        'url': url.toString(),
                                        'filename': image.toString(),
                                        'date': DateTime.now().toString()
                                      }).then((value) {
                                        setState(() {
                                          _saving = false;
                                        });
                                      });
                                    }
                                  }),
                            )),
                        //////////////////////////////////: profil .//////////////////////////////////////////
                        Container(
                          child: Stack(
                            overflow: Overflow.visible,
                            children: [
                              Positioned(
                                top: getheight(context) / 7.4,
                                left: getwidth(context) / 2.5,
                                child: Stack(
                                  overflow: Overflow.visible,
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        print('pick here');
                                        var image;
                                        var url;
                                        image = await pickImageandcompress(
                                            1, context);
                                        if (image != null) {
                                          setState(() {
                                            _saving = true;
                                          });
                                          url = await sendimage(
                                              image, 'UserProfils');
                                          Image_profil_vistal.child(
                                                  shareget('phone'))
                                              .update({
                                            'url': url.toString(),
                                            'filename': image.toString(),
                                            'date': DateTime.now().toString()
                                          }).then((value) {
                                            setState(() {
                                              _saving = false;
                                            });
                                          });
                                        }
                                      },
                                      child: Container(
                                        height: 100.0,
                                        width: 100.0,
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: urlprof != eve
                                              ? CachedNetworkImage(
                                                  filterQuality:
                                                      FilterQuality.medium,
                                                  fit: BoxFit.fill,
                                                  imageUrl: urlprof,
                                                  placeholder:
                                                      (BuildContext context,
                                                          String url) {
                                                    return Center(
                                                      child: SkeletonContainer
                                                          .rounded(
                                                        height: 100.0,
                                                        width: 100.0,
                                                      ),
                                                    );
                                                  },
                                                )
                                              : Icon(
                                                  Icons.person,
                                                  color: Colors.red,
                                                  size: 60,
                                                ),
                                        ),
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                              color: Colors.black, width: 1),
                                          borderRadius:
                                              BorderRadius.circular(60),
                                        ),
                                      ),
                                    ),
                                    //////////////////////////////////////////////////// camera////////////////////////
                                    Positioned(
                                        top: 70,
                                        left: 60,
                                        child: Container(
                                          alignment: Alignment.center,
                                          height: 39,
                                          width: 39,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              border: Border.all(
                                                  color: Colors.red.shade300,
                                                  width: 1)),
                                          child: IconButton(
                                              icon: Icon(
                                                Icons.photo_camera,
                                                // size: 70,
                                                color: Colors.red,
                                              ),
                                              onPressed: () async {
                                                print('pick here');
                                              }),
                                        ))
                                  ],
                                ),
                              ),
                              ///////////////////////////////////////////////////////::://///////////////////////////////////////////////
                            ],
                          ),
                          height: 170,
                          width: getwidth(context),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 60,
                    ),
                    Card(
                      child: ListTile(
                        title: Row(
                          children: [
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              infouser['prenom'] + ' ' + infouser['nom'],
                              style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 20,
                                  letterSpacing: 1),
                            ),
                          ],
                        ),
                        leading: IconButton(
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (_) {
                                  return StatefulBuilder(builder:
                                      (BuildContext context,
                                          StateSetter mystate) {
                                    return SimpleDialog(
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(10.0))),
                                      // contentPadding: EdgeInsets.only(top: 10.0),
                                      title: Column(
                                        children: [
                                          Text(
                                            'Nouvelle appelation',
                                            style: TextStyle(
                                                color: Colors.grey,
                                                fontSize: 20),
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                            'Modifiez que le champ concerné',
                                            style: TextStyle(
                                                color: Colors.blue,
                                                fontSize: 12),
                                          ),
                                        ],
                                      ),
                                      children: [
                                        ///://////////////////////////////////////////////////:::
                                        Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: Container(
                                            height: 40,
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                border: Border.all(
                                                    // color: Colors.grey,
                                                    width: 0.5)),
                                            child: TextField(
                                              keyboardType:
                                                  TextInputType.multiline,
                                              // maxLengthEnforced: true,
                                              // maxLength: 10,
                                              controller: prenom,
                                              decoration: InputDecoration(
                                                labelText: 'Nouveau prénom',
                                                fillColor: Colors.white,
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                5))),
                                              ),
                                            ),
                                          ),
                                        ),
                                        // ////////////////////////////////////////////////////////////////////////////////
                                        Column(
                                          children: [
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(4.0),
                                              child: Container(
                                                height: 40,
                                                alignment: Alignment.center,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    border: Border.all(
                                                        // color: Colors.grey,
                                                        width: 0.5)),
                                                child: TextField(
                                                  keyboardType:
                                                      TextInputType.multiline,
                                                  // maxLengthEnforced: true,
                                                  // maxLength: 15,
                                                  controller: nom,
                                                  decoration: InputDecoration(
                                                    labelText: 'Nouveau nom',
                                                    fillColor: Colors.white,
                                                    border: OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius.all(
                                                                Radius.circular(
                                                                    5))),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            InkWell(
                                                onTap: () {
                                                  if (nom.text.isEmpty &&
                                                      prenom.text.isEmpty) {
                                                    toast(
                                                        'Veuillez remplir au moins un champ',
                                                        Colors.red,
                                                        Colors.white);
                                                  } else {
                                                    mystate(() {
                                                      _saving = true;
                                                    });
                                                    Vistal_SIMPLEUSER.child(
                                                            shareget('phone'))
                                                        .update({
                                                      'nom': nom.text.isNotEmpty
                                                          ? nom.text
                                                          : infouser['nom'],
                                                      'prenom': prenom
                                                              .text.isNotEmpty
                                                          ? prenom.text
                                                          : infouser['prenom']
                                                    }).then((value) {
                                                      toast(
                                                          'Informations mises à jour avec succès',
                                                          Colors.red,
                                                          Colors.white);

                                                      setState(() {
                                                        _saving = false;
                                                        nom.text = '';
                                                        prenom.text = '';
                                                      });
                                                      pop(context);
                                                    });
                                                  }
                                                },
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Container(
                                                      alignment:
                                                          Alignment.center,
                                                      height: 50,
                                                      width: 200,
                                                      decoration: BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(20),
                                                          color: Colors.red),
                                                      child: Text(
                                                        'Valider',
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      )),
                                                ))
                                          ],
                                        )
                                      ],
                                    );
                                  });
                                },
                                //////////////////////////////////////////////////////////////////////////////////:
                              );
                            },
                            icon: Icon(
                              Icons.create,
                              color: Colors.pink,
                            )),
                      ),
                    ),

                    allfav.isNotEmpty
                        ? Row(
                            children: [
                              SizedBox(
                                width: 10,
                              ),
                              Icon(Icons.favorite_border),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                'Mes favorits',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          )
                        : Padding(
                            padding: const EdgeInsets.only(top: 200.0),
                            child: Center(
                              child: Text('Aucun favorit'),
                            ),
                          ),
                    SizedBox(
                      width: 10,
                    ),
                    SingleChildScrollView(
                      child: Column(
                        children: [
                          for (final fav in allfav)
                            ProductList(
                              map: {
                                'idprod': fav['idprod'],
                                'idetab': fav['idetab'],
                              },
                            )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            )
          : Center(
              child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
            )),
    );
  }
}
